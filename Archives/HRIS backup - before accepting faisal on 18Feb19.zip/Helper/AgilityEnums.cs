﻿namespace HRIS.Helper
{
    public class AgilityEnums
    {
      
        public const string myFormPath = "../Common/MyForms";
        public const string mainMenuPath = "../Common/Common/Index";
        public enum formMode : short { Add = 1, Edit = 2, Recall = 3, ReadOnly = 4, Initialize = 5, Review = 6, };

        public enum ListItemState
        {
            UnChanged = 0,
            Added = 1,
            Edited = 2,
            Deleted = 3,
        }

        public enum UserValidation
        {
            Successful = 1,
            InvalidUserId = 2,
            InvalidPassword = 3,
            ForcePasswordChange = 4,
            UserIdDisabled = 5,
        }

        public enum CalledForm : short { MyForm = 2, Menu = 3 };




    }
}