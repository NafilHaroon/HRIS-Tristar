﻿//agGrid.initialiseAgGridWithAngular1(angular);
//var searchApp = angular.module('HRIS1', ["ui.bootstrap", "agGrid"]);

app.controller('SearchController', function ($scope, $rootScope, $http) {
    function valueSelected(row) {
        try {
            $rootScope.SelectedRow = row.data;
            $scope.modalInstance.close('ok');
        }
        catch (exception) { alert(exception.Message); }
    }

    try {
        $http({
            type: "Get",
            url: baseURL + "Search"
        }).then(result => {
            if (!result.data.success) {
                alert(result.data.Message);
                $scope.modalInstance.close('ok');
            }
            else {
                $scope.gridOptions.api.setColumnDefs(result.data.columnDefs);
                $scope.gridOptions.api.setRowData(result.data.rowData);//JSON.parse(JSON.stringify(
                $scope.gridOptions.api.sizeColumnsToFit();
            }
        }, errorMsg => {
            alert(errorMsg);
        });

        $scope.gridOptions = {
            headerHeight: 25,
            rowHeight: 32,
            //enableFilter: true,
            animateRows: true,
            floatingFilter: true,
            enableSorting: true,
            multiSortKey: 'ctrl',
            rowSelection: 'single',
            rowDeselection: true,
            enableColResize: true,
            suppressCellSelection: true,
            onRowDoubleClicked: valueSelected,
            overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
            overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>'
        };
    }
    catch (exception) {
        alert(exception.Message);
    }
});