﻿/// <reference path="modernizr-2.6.2.js" />
/// <reference path="jquery-ui-1.12.1.js" />
/// <reference path="jquery-3.0.0.js" />
/// <reference path="jQuery/jquery.validate.js" />
/// <reference path="jQuery/jquery.validate.unobtrusive.js" />
///// <reference path="knockout-2.2.0.debug.js" />
