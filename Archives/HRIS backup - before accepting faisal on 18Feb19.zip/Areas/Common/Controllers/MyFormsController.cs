﻿using HRIS.Areas.Common.Models;
using HRIS.Helper;
using System.Collections.Generic;
using System.Data;
using System.Web.Mvc;

namespace HRIS.Areas.Common.Controllers
{
    [NoCache]
    [Authorize]
    public class MyFormsController : Controller
    {
        // GET: /Common/MyDocuments/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MainLayout()
        {
            return View();
        }

        /// <summary>
        /// Sets view bag Search Selection to be used in Search window to give option of wildcard search to end user
        /// </summary>
        public void fillSearchType()
        {
            List<string> SearchSelection = new List<string>();
            SearchSelection.Add("Search for Text Start with");
            SearchSelection.Add("Search for exact word");
            SearchSelection.Add("Search for word any where");
            ViewBag.SearchSelection = new SelectList(SearchSelection);
        }

        /// <summary>
        /// Returns search header dropdown values and initial list to display in search result grid;
        /// Typically used only for the first time when search window is opened, subsequent filters are returned using SearchResult action method below
        /// </summary>
        /// <param name="sModel"></param>
        /// <returns></returns>
        public ActionResult Search(SearchModel sModel)
        {
            SearchModel r = new SearchModel();
            if (sModel.SearchData == null)
            {
                r = (SearchModel)TempData["searchdata"];
                TempData["searchdata"] = null;
                Session["SearchList"] = r.dtSearch;
            }
            r.dtSearch = (DataTable)Session["SearchList"];

            List<SelectListItem> lstSearchBy = new List<SelectListItem>();
            foreach (DataColumn dc in r.dtSearch.Columns)
            {
                lstSearchBy.Add(new SelectListItem { Text = dc.Caption, Value = dc.ColumnName });
            }
            ViewBag.SearchBy = new SelectList(lstSearchBy, "Value", "Text", Session["SearchKey"].ToString());
            fillSearchType();

            if (sModel.SearchData != null && sModel.SearchSelection != null && sModel.SearchBy != " ")
            {
                string strExpression = string.Empty;
                if (sModel.SearchSelection == "Search for Text Start with")
                {
                    strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') LIKE '" + sModel.SearchData + "%'";
                }
                if (sModel.SearchSelection == "Search for exact word")
                {
                    strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') = '" + sModel.SearchData + "'";
                }
                if (sModel.SearchSelection == "Search for word any where")
                {
                    strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') LIKE '%" + sModel.SearchData + "%'";
                }

                DataView dv = new DataView(r.dtSearch);
                dv.RowFilter = strExpression;
                dv.RowStateFilter = DataViewRowState.CurrentRows;
                r.dtSearch = dv.ToTable();
                r.ControllerPath = sModel.ControllerPath;
                r.dtSearch = dv.ToTable();
            }
            else
            {
                if (sModel.SearchBy != null)
                {
                    ModelState.AddModelError("SearchError", "Please enter value in Search Text or select any valid search by column");
                }
                if (sModel.SearchBy == "Select")
                {
                    ModelState.AddModelError("SearchError", "Please select valid value for look in Paramter");
                }
            }
            return PartialView("Search", r);
        }

        // [HttpGet]
        //public ActionResult Search()
        //{
        //    SearchModel r = new SearchModel();
        //    SearchModel sModel = new SearchModel();
        //    //if (sModel.SearchData == null)
        //    //{
        //    string userid = Session["UserId"].ToString();
        //    SearchModel userid1 = (SearchModel)Session["searchdata"];
        //    r = (SearchModel)Session["searchdata"];
        //    Session["searchdata"] = null;
        //    Session["SearchList"] = r.dtSearch;
        //    //}
        //    r.dtSearch = (DataTable)Session["SearchList"];

        //    List<SelectListItem> lstSearchBy = new List<SelectListItem>();
        //    foreach (DataColumn dc in r.dtSearch.Columns)
        //    {
        //        lstSearchBy.Add(new SelectListItem { Text = dc.Caption, Value = dc.ColumnName });
        //    }
        //    ViewBag.SearchBy = new SelectList(lstSearchBy, "Value", "Text", Session["SearchKey"].ToString());
        //    fillSearchType();

        //    if (sModel.SearchData != null && sModel.SearchSelection != null && sModel.SearchBy != " ")
        //    {
        //        string strExpression = string.Empty;
        //        if (sModel.SearchSelection == "Search for Text Start with")
        //        {
        //            strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') LIKE '" + sModel.SearchData + "%'";
        //        }
        //        if (sModel.SearchSelection == "Search for exact word")
        //        {
        //            strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') = '" + sModel.SearchData + "'";
        //        }
        //        if (sModel.SearchSelection == "Search for word any where")
        //        {
        //            strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') LIKE '%" + sModel.SearchData + "%'";
        //        }

        //        DataView dv = new DataView(r.dtSearch);
        //        dv.RowFilter = strExpression;
        //        dv.RowStateFilter = DataViewRowState.CurrentRows;
        //        r.dtSearch = dv.ToTable();
        //        r.ControllerPath = sModel.ControllerPath;
        //        r.dtSearch = dv.ToTable();
        //    }
        //    else
        //    {
        //        if (sModel.SearchBy != null)
        //        {
        //            ModelState.AddModelError("SearchError", "Please enter value in Search Text or select any valid search by column");
        //        }
        //        if (sModel.SearchBy == "Select")
        //        {
        //            ModelState.AddModelError("SearchError", "Please select valid value for look in Paramter");
        //        }
        //    }
        //   // return View(r);
        //    return PartialView("Search", r);
        //}

        /// <summary>
        /// Returns only Search result set without returning dropdown and other stuff of Search window header; 
        /// Typically used for returning search results after initial full load of search window through Search Action above
        /// </summary>
        /// <param name="rmodel"></param>
        /// <returns></returns>
        public ActionResult SearchResult(SearchModel sModel)
        {
            SearchModel r = new SearchModel();
            if (sModel.SearchData == null)
                sModel.SearchData = "";

            r.dtSearch = (DataTable)Session["SearchList"];

            if (sModel.SearchData != null && sModel.SearchSelection != null && sModel.SearchBy != null)
            {
                string strExpression = string.Empty;
                if (sModel.SearchSelection == "Search for Text Start with")
                {
                    strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') LIKE '" + sModel.SearchData + "%'";
                }
                if (sModel.SearchSelection == "Search for exact word")
                {
                    strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') = '" + sModel.SearchData + "'";
                }
                if (sModel.SearchSelection == "Search for word any where")
                {
                    strExpression = "Convert(" + sModel.SearchBy + ", 'System.String') LIKE '%" + sModel.SearchData + "%'";
                }

                DataView dv = new DataView(r.dtSearch);
                dv.RowFilter = strExpression;
                dv.RowStateFilter = DataViewRowState.CurrentRows;
                r.dtSearch = dv.ToTable();
                r.ControllerPath = sModel.ControllerPath;
                r.dtSearch = dv.ToTable();
            }
            else
            {
                if (sModel.SearchBy == null)
                {
                    ModelState.AddModelError("Search Error", "Please select valid value from Look In drop down");
                }
            }
            return PartialView("_SearchResult", r);
        }
    }
}
