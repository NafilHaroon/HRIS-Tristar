﻿using HRIS.Areas.Common.Models;
using HRIS.Helper;
using System.Collections.Generic;
using System.Web.Mvc;

namespace HRIS.Areas.Common.Controllers
{
    [NoCache]
    [Authorize]
    public class CommonController : Controller
    {
        public CommonController()
        {

        }

        public ActionResult Index()
        {
            if (Session["MainMenu"] == null)
            {
                if (Session["UserId"] == null)
                    RedirectToActionPermanent("Login", "User");
                else
                    Session["MainMenu"] = Menu.Get(Session["UserId"].ToString());
            }
            ViewBag.Menu = (List<Menu>)Session["MainMenu"];
            return View();
        }

        public ActionResult Close()
        {
            return View();
        }
    }
}
