﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Web.Mvc;
using System.Web.Security;

namespace HRIS.Areas.Common.Controllers
{
    [NoCache]
    public class UserController : Controller
    {
        //UserProfile us = new UserProfile();

        //[AllowAnonymous]
        public ActionResult LogIn()
        {
            TempData["alertMessage"] = null;
            return View();
        }

        //[HttpGet]
        //[AllowAnonymous]
        public JsonResult ValidateUser(UserProfile u)
        {
            if (ModelState.IsValid) // this is check validity
            {
                UserProfile user = new UserProfile();
                user.UserId = u.UserId.ToLower();
                user.Password =u.Password;
                AgilityEnums.UserValidation uv = user.AuthenticateUser();

                switch (uv)
                {
                    case AgilityEnums.UserValidation.InvalidUserId:
                        throw new Exception("The user id you have entered is invalid");
                    case AgilityEnums.UserValidation.InvalidPassword:
                        throw new Exception("The Password you have entered is invalid");
                    case AgilityEnums.UserValidation.UserIdDisabled:
                        throw new Exception("The user id you have entered has been disabled. Please contact your System Admin for further details");
                    case AgilityEnums.UserValidation.ForcePasswordChange:
                        Session["UserId"] = user.UserId;
                        Session["Password"] = user.Password;
                        return Json(new { url = Url.Action("ChangePassword", "User") }, JsonRequestBehavior.AllowGet);
                    case AgilityEnums.UserValidation.Successful:
                        Session["UserId"] = user.UserId.ToLower();
                        Session["UserRole"] = user.UserRoleId.ToString();
                        Session["UserName"] = user.UserName;
                        Session["BranchCode"] = user.BranchCode;
                        Session["DepartmentId"] = user.DepartmentId;
                        Session["UserLevel"] = user.UserLevel;
                        Session["AccessOption"] = UserProfile.GetAccess(user.UserId);
                        
                        Config con = Config.Get();
                        Session["AbsentDeductionId"] = con.AbsentDeductionId;
                        Session["BasicSalaryId"] = con.BasicSalaryId;
                        Session["ProvidentFundId"] = con.ProvidentFundId;
                        Session["CurrentMonth"] = con.CurrentMonth;
                        Session["CurrentYear"] = con.CurrentYear;
                        Session["CompanyId"] = 6;
                        
                        FormsAuthentication.SetAuthCookie(user.UserId, false);
                        string returnURL = Request.UrlReferrer.ToString();
                        if (returnURL.IndexOf("ReturnUrl=") > -1)
                        {
                            returnURL = returnURL.Substring(returnURL.IndexOf("ReturnUrl=") + 10);
                            return Json(new { url = returnURL }, JsonRequestBehavior.AllowGet);

                        }
                        else
                        {
                            return Json(new { url = Url.Action("Index", "Common") }, JsonRequestBehavior.AllowGet);
                        }
                }
            }
            return Json(new { url = Url.Action("Login", "User") }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            Session.Clear();
            return RedirectToAction("LogIn", "User");
        }

        [HttpGet]
        [AllowAnonymous]
        public EmptyResult SendPassword(string _userId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_userId))
                    throw new Exception("Please enter valid user id and then press forgot password to receive your password on email");
                else
                {
                    string strResult = UserProfile.SendPassword(_userId);
                    if (strResult != "Successful")
                        throw new Exception(strResult);
                }
                return new EmptyResult();
            }
            catch (Exception)
            { throw; }
        }

        [HttpGet]
        public ActionResult Search()
        {
            SearchModel cp = new SearchModel();
            // return PartialView("test", cp);
            return View(cp);
        }

        public ActionResult ApplyNewPassword(string command, string _oldPassword, string _newPassword, string _confirmPassword)
        {
            try
            {
                if (!AgilityHelper.isComplex(_newPassword))
                {
                    throw new Exception("Password must contain combination of Capital & Small Alphabet, Number and Special Character " +
                   "e.g. 20-Dec-79 or AqT-607 Description of Failure: Your Password doesn't contain Number (Valid values are 0-9)" +
                   "Capital Alphabet (Valid values are A-Z) Small Alphabet (Valid values are a-z)" +
                   "Special characters (Valid values are any character other than Alphabet and Number)" + "Please try new password using above mentioned criteria" + "," + "Weak Password");
                }
                else
                {
                    try
                    {
                        UserProfile.ChangePassword(Session["UserId"].ToString(), AgilityHelper.MaskPassword(_oldPassword, true), AgilityHelper.MaskPassword(_newPassword, true));
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                }
                return RedirectToAction("Index", "Common");

            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
