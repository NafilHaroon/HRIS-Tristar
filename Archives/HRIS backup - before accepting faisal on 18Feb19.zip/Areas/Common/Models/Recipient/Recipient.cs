﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Collections.Generic;

namespace HRIS.Areas.Common.Models
{
    public class Recipient
    {
        #region prviate properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public string RecipientId { get; set; }
        public string RecipientName { get; set; }
        public List<Recipient> RecipientList { get; set; }
        #endregion

        #region constructor
        public Recipient()
        {
        }

        public Recipient(string _recipientId, string _recipientName)
        {
            RecipientId = _recipientId;
            RecipientName = _recipientName;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}
