﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HRIS.Areas.Common.Models
{
    public class Footer
    {
        [Display(Name="Created By")]
        public string CreatedBy { get; set; }
        [Display(Name = "Created On")]
        public DateTime? CreatedOn { get; set; }
        [Display(Name = "Last Edited By")]
        public string UpdatedBy { get; set; }
        [Display(Name = "Last Edited Date")]
        public DateTime? UpdatedOn { get; set; }

        public Footer()
        {
            CreatedOn = DateTime.Now;
        }
    }
}