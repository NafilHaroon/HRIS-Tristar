﻿using HRIS.Areas.Master.Models;
using System.Web;

namespace HRIS.Areas.Common.Models
{
    public class ServerSession
    {
        private UserProfile _loggedInUser = new UserProfile();

        public UserProfile LoggedInUser
        {
            get { return _loggedInUser; }
            set { _loggedInUser = value; }
        }

        internal static void CreateServerSession(UserProfile loggedInUser)
        {
            ServerSession ServerSession = new ServerSession();
            ServerSession.LoggedInUser = loggedInUser;
            
            HttpContext.Current.Session["ServerSession"] = ServerSession;
        }

        internal static void ClearServerSession()
        {
            HttpContext.Current.Session.Clear();
        }

        internal static ServerSession GetServerSession()
        {
            return HttpContext.Current.Session["ServerSession"] as ServerSession;
        }
    }
}
