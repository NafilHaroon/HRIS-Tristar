﻿baseURL = "/HRIS/Common/User/";
var app = angular.module('HRIS', []);
$('#txtUserId').focus();
app.controller("UserController", function ($scope, $http, $window) {

    $scope.login = function () {

        var userId = $scope.UserProfile.UserId;
        var passWord = $scope.UserProfile.Password;

        var isValid = validParameters(userId, passWord, "Login");
        if (isValid == true) {
            $.ajax({
                //url: '/User/ValidateUser',
                url: baseURL + 'ValidateUser',
                type: "GET",
                data: $scope.UserProfile,
                //data: { _userId: userId, _passWord: passWord },
                beforeSend: function () {
                    $("#dialog-alert").dialog('open');
                },
                success: function (result) {
                    if (result.url.indexOf("ChangePassword") > -1) {
                        $("#dialog-changePwd").dialog('open');
                    }
                    else {
                        window.location.href = result.url;
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    var tempDiv = document.createElement('div');
                    tempDiv.innerHTML = xhr.responseText;
                    alert(tempDiv.childNodes[1].innerHTML);
                    $('#txtUserId').focus();
                },
                complete: function () {
                    $("#dialog-alert").dialog('close');
                    $('#txtUserId').focus();
                }
            });
        }
    };

    $scope.SendPassword = function () {

        var userId = document.getElementById("txtUserId").value;
        var isValid = validParameters(userId, "", "Forgot");
        if (Boolean(isValid)) {
            $.ajax({
                url: baseURL + "SendPassword",
                type: "GET",
                data: { _userId: userId },
                beforeSend: function () {
                    $("#dialog-alert").dialog('open');
                },
                success: function (result) {
                    alert("Password was successfully sent to email Id configured on user profile!");
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    var tempDiv = document.createElement('div');
                    tempDiv.innerHTML = xhr.responseText;
                    alert(tempDiv.childNodes[1].innerHTML);
                    $('#txtUserId').focus();
                },
                complete: function () {
                    $("#dialog-alert").dialog('close');
                }
            });
        }
    };

    $("#dialog-alert").dialog({
        autoOpen: false,
        resizable: false,
        height: 420,
        width: 420,
        title: "Appreciate your patience",
        show: { effect: 'drop', direction: "up" },
        modal: true,
        draggable: false,
        overlapEmbedObjects: true,
        zindex: 1000,
        open: function (event, ui) {
            $(".ui-dialog-titlebar-close").hide(),
            $(".ui-dialog-titlebar").hide();
        }
    });

    var wWidth = $(window).width();
    var dWidth = wWidth * 0.5;
    var wHeight = $(window).height();
    var dHeight = wHeight * 0.7;

    $("#dialog-changePwd").dialog({
        autoOpen: false,
        resizable: false,
        height: dHeight,
        width: dWidth,
        title: "It's time to Change Password....",
        show: { effect: 'drop', direction: "down" },
        modal: true,
        draggable: false,
        overlapEmbedObjects: true,
        zindex: 1000,
        open: function (event, ui) {
            $(".ui-dialog-titlebar").show();
            $(this).load('/HRIS/Common/User/ChangePassword');
        }
    });
});

function validParameters(userId, password, processName) {
    if (processName == "Login" && (userId.trim() == "" || password.trim() == "")) {
        alert("Please enter valid User Id & Password before proceeding with Login process!");
        $('#txtUserId').focus();
        return false;
    }
    else if (processName == "Forgot" && userId.trim() == "") {
        alert("Please enter User Id before using Forgot Password option!");
        $('#txtUserId').focus();
        return false;
    }
    else
        return true;
}