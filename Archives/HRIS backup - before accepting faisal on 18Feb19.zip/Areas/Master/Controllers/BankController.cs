﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class BankController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                Bank _b = new Bank();
                ModelState.Clear();
                return Json(new { success = true, bank = _b, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch(Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(Bank _b)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_b);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Bank.Save(_b, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new { success = false, message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString() };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                Bank _b = Bank.Get(_keyId, Session["UserId"].ToString());
                if (_b == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Bank Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, bank = _b, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new { success = true, columnDefs = ColumnDefinition.getColDef(new BankList()),
                    rowData = BankList.Get(Session["UserId"].ToString(), false) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetLookups()
        {
            return Json(CompanyList.Get(Session["UserId"].ToString(), true), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Bank'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(Bank _b)
        {
            if (string.IsNullOrEmpty(_b.BankName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Bank Name"));

            if (!_b.CompanyId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Code"));

            if (string.IsNullOrEmpty(_b.AccountNo))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Account #"));

            if (string.IsNullOrEmpty(_b.Address))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Address"));

            if (string.IsNullOrEmpty(_b.ContactPerson))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("ContactPerson"));
        }
        #endregion
    }
}
