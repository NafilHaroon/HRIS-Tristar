﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class UserProfileController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save(UserProfile _up)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_up);
                #endregion

                #region save to db
                if (ModelState.IsValid)
                {
                    if (UserProfile.Save(_up, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        msg = new { success = true, message = Success, session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                if (!ModelState.IsValid)
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(string _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                UserProfile _up = UserProfile.Get(_keyId);
                if (_up == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The User Id entered doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, UserProfile = _up, session = _formMode.ToString() };
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new UserList()),
                    rowData = UserList.Get(false)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'User Management'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(UserProfile _up)
        {
            if (_up.Options.Where(x => !x.AllowAccess && (x.AllowAdd || x.AllowEdit)).Any())
                ModelState.AddModelError("Validation", "=> Please put check on Allow access when you request Allow Add or Allow Edit else remove check from Allow Add / Edit where Allow access is not turned on");
        }
        #endregion
    }
}