﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class AttachmentTypeController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                AttachmentType _at = new AttachmentType();
                ModelState.Clear();
                Session["FormMode"] = AgilityEnums.formMode.Add;
                return Json(new { success = true, attachmentType = _at, session = Session["FormMode"].ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    success = false,
                    errorMsg = ex.Message
                }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(AttachmentType _at)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_at);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (AttachmentType.Save(_at, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;
                        msg = new { success = true, message = Success, session = Session["FormMode"].ToString() };
                    }
                }
                else
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, message = ex.Message, session = Session["FormMode"].ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {
                AttachmentType _at = AttachmentType.Get(_keyId);
                if (_at == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The attachment type doesn't exist or you donot have permission to access it");
                }
                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, attachmentType = _at, session = Session["FormMode"].ToString() };
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = Session["FormMode"].ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                _data = new { success = true, columnDefs = ColumnDefinition.getColDef(new AttachmentTypeList()), rowData = AttachmentTypeList.Get(false) };
                return Json(_data, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                _data = new { success = false, Message = ex.Message };
                return Json(_data, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region private methods           
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Attachment Type'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(AttachmentType dat)
        {
            if (string.IsNullOrEmpty(dat.AttachmentTypeName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Attachment Type Name"));

        }
        #endregion
    }
}
