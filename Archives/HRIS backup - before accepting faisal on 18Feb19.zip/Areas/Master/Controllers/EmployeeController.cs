﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class EmployeeController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                Employee _e = new Employee();
                ModelState.Clear();
                Session["FormMode"] = AgilityEnums.formMode.Add;
                return Json(new { success = true, employee = _e, session = Session["FormMode"].ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch(Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(Employee _emp)
        {
            var msg = new Object();
            try
            {
                //if (emp.ProfileImage != null)
                //{
                //    string imageBase64Data = Convert.ToBase64String(emp.ProfileImage);
                //    emp.image = imageBase64Data;
                //}

                #region Validation  //to be reviewed in detail later
                if (Session["DocAttachment"] != null)
                    _emp.Attachments = (List<EmpAttachment>)Session["DocAttachment"];
                else
                    _emp.Attachments = new List<EmpAttachment>();

                validate(_emp);
                #endregion

                #region save to db
                if (ModelState.IsValid)
                {
                    if (Employee.Save(_emp, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;
                        msg = new { success = true, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }
                else
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(string _keyId)
        {
            var msg = new Object();
            try
            {
                Employee _emp = Employee.Get(_keyId);
                //if (cn.ProfileImage != null)
                //{
                //    string imageBase64Data = Convert.ToBase64String(cn.ProfileImage);
                //    cn.image = imageBase64Data;
                //    cn.ProfileImage = null;
                //}

                if (_emp == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Employee Code doesn't exist or you donot have permission to access it");
                }                
                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = _emp, Session = Session["FormMode"].ToString() };
                Session["DocAttachment"] = _emp.Attachments;
            }
            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        //to be done later
        public JsonResult Delete(string _keyId)
        {
            try
            {
                if (Convert.ToBoolean(Session["AllowDelete"]))
                {
                    if (Employee.Delete(_keyId))
                    {
                        TempData["alertMessage"] = "Employee Id " + _keyId + " deleted successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    }
                }
                return Json(new { success = true, errorMsg = string.Empty }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                _data = new { success = true, columnDefs = ColumnDefinition.getColDef(new EmployeeList()), rowData = EmployeeList.Get(Session["UserId"], Session["CompanyId"]) };
                return Json(_data, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                _data = new { success = false, Message = ex.Message };
                return Json(_data, JsonRequestBehavior.AllowGet);
            }
        }

        //public JsonResult GetLookups()
        //{

        //}

        #endregion

        #region Json Method
        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    success = true,
                    lstCompany = CompanyList.Get(Session["UserId"].ToString(), true),
                    lstBranch = BranchList.Get(Session["UserId"].ToString(), true),
                    lstDepartment = DepartmentList.Get(true),
                    lstSupervisor = EmployeeList.Get(Session["UserId"], Session["CompanyId"]),
                    lstReplacement = EmployeeList.GetNotReplaced(Session["UserId"], Session["CompanyId"]),
                    lstEmployeeStatus = EmpStatus.Get(),
                    lstJobNature = JobNature.Get(),
                    lstMaritalStatus = MaritalStatus.Get(),
                    lstGrade = GradeList.Get(true, Session["UserId"].ToString()),
                    lstQualification = Qualification.Get(),
                    lstPaymentMode = PaymentModeList.Get(),
                    lstBank = BankList.Get(Session["UserId"].ToString(), true),
                    //lstLeaveType = LeaveTypeList.Get(true),
                    lstAssetType = AssetTypeList.Get(),
                    lstRelation = Relation.Get(),
                    lstMedicalPlan = MedicalPlan.Get(),
                    lstSalaryHead = SalaryHeadList.Get(true),
                    lstAttachmentType = AttachmentTypeList.Get(true),
                    lstAllocTemplate = AllocationTemplateList.Get(true),
                    lstWorkerType = WorkerType.Get()
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        //public JsonResult GetBranch()
        //{
        //    return Json((List<BranchList>)Session["lstBranch"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetDepartment()
        //{
        //    return Json((List<DepartmentList>)Session["lstDepartment"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetEmployees()
        //{
        //    return Json((List<EmployeeList>)Session["lstSupervisor"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetInActiveEmployee()
        //{
        //    return Json((List<EmployeeList>)Session["lstReplaceEmployee"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetEmployeeStatus()
        //{
        //    return Json((List<EmpStatus>)Session["lstEmployeeStatus"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetJobNature()
        //{
        //    return Json((List<JobNature>)Session["lstJobNature"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetMaritalStatus()
        //{
        //    return Json((List<MaritalStatus>)Session["lstMaritalStatus"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetGrade()
        //{
        //    return Json((List<GradeList>)Session["lstGrade"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetQualification()
        //{
        //    return Json((List<QualificationList>)Session["lstQualification"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetPaymentMode()
        //{
        //    return Json((List<PaymentModeList>)Session["lstPaymentMode"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetBank()
        //{
        //    return Json((List<BankList>)Session["lstBank"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetLeave()
        //{
        //    return Json((List<LeaveTypeList>)Session["lstLeave"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetAsset()
        //{
        //    return Json((List<AssetTypeList>)Session["lstAsset"], JsonRequestBehavior.AllowGet);
        //}


        //public JsonResult GetRelation()
        //{
        //    return Json((List<RelationList>)Session["lstRelation"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetMedicalPlan()
        //{
        //    return Json((List<MedicalPlanList>)Session["lstMedicalPlan"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetSalaryHead()
        //{
        //    return Json((List<SalaryHeadList>)Session["lstSalaryHead"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetAttachmentType()
        //{
        //    return Json((List<AttachmentTypeList>)Session["lstAttachment"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetAllocationTemplate()
        //{
        //    return Json((List<AllocationTemplateList>)Session["lstATemplate"], JsonRequestBehavior.AllowGet);
        //}

        //public JsonResult GetWorkerTypes()
        //{
        //    return Json((List<WorkerTypeList>)Session["lstWorkerType"], JsonRequestBehavior.AllowGet);
        //}
        #endregion


        //public JsonResult GetCompany()
        //{            
        //    return Json(getCompanyList(), JsonRequestBehavior.AllowGet);
        //}

        #region private methods

        //private void clearSessions()
        //{
        //    Session.Remove("lstCompany");
        //    Session.Remove("lstDepartment");
        //    Session.Remove("lstBranch");
        //    Session.Remove("lstSupervisor");
        //    Session.Remove("lstReplaceEmployee");
        //    Session.Remove("lstEmployeeStatus");
        //    Session.Remove("lstJobNature");
        //    Session.Remove("lstMaritalStatus");
        //    Session.Remove("lstGrade");
        //    Session.Remove("lstQualification");
        //    Session.Remove("lstPaymentMode");
        //    Session.Remove("lstBank");
        //    Session.Remove("lstLeave");
        //    Session.Remove("lstRelation");
        //    Session.Remove("lstMedicalPlan");
        //    Session.Remove("lstSalaryHead");
        //    Session.Remove("lstAttachment");
        //    Session.Remove("lstATemplate");
        //    Session.Remove("DocAttachment");
        //    Session.Remove("lstWorkerType");
        //}

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Employee'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            //populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            Employee e = new Employee();
            //e.BSSession = Convert.ToInt16(Session["BasicSalaryId"]);
            //e.PFSession = Convert.ToInt16(Session["ProvidentFundId"]);
            return View();
        }   

        private void validate(Employee e)
        {
            if (string.IsNullOrEmpty(e.EmployeeName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Employee Name"));

            if (string.IsNullOrEmpty(e.BranchCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Branch"));

            if (string.IsNullOrEmpty(e.DepartmentCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Department"));

            if (!e.GradeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Grade"));

            if (string.IsNullOrEmpty(e.Designation))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Designation"));

            //if (e.image == null)
            //    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("ProfileImage"));


            if (string.IsNullOrEmpty(e.HeadName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Father/Husband Name"));

            if (!e.SupervisorId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Supervisor"));

            if (!e.WorkerTypeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Worker Type"));

            if (!e.StatusId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Status"));

            if (!e.JobNatureId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Job Nature"));


            if (e.HiringTypeId == 2 && !e.ReplacementEmployeeId.HasValue)
                ModelState.AddModelError("Validation", "Please select valid employee name from drop down against which this replacement is hired");

            if (e.HiringTypeId == 3 && !e.ReplacementEmployeeId.HasValue)
                ModelState.AddModelError("Validation", "Please select valid employee name from drop down against which this replacement is hired");

            if (e.JoiningDate.Value > e.ConfirmationDueDate.Value)
            {
                ModelState.AddModelError("Validation", "The Confirmation Due Date can't be older than Joining Date");
            }

            if (e.IsConfirmed)
            {
                if (e.JoiningDate.Value > e.ConfirmationDate.Value)
                {
                    ModelState.AddModelError("Validation", "The confirmation data can't be older than joining date");

                }
                //else if (e.EmpEmergencyContactDetails.Count == 0)
                //{
                //    ModelState.AddModelError("Validation", "Next of Kin Name and Relation ship is mandatory to be saved for confirmed Employee. Please provide valid data before proceeding");
                //    return;
                //}
            }

            //if (e.LifeInsuranceCost <= 0)
            //    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Life Insurance"));

            if (!e.EmpPersonalInfo.MaritalStatusId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Marital Status"));

            if (!e.EmpPersonalInfo.GenderId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Gender"));

            if (string.IsNullOrEmpty(e.EmpPersonalInfo.FamilyNo))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Family #"));


            if (string.IsNullOrEmpty(e.EmpPersonalInfo.PermanentAddress))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Permanent Address"));

            if (string.IsNullOrEmpty(e.EmpPersonalInfo.ResidentialAddress))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Residential Address"));

            if (!string.IsNullOrWhiteSpace(e.EmpPersonalInfo.Email))
            {
                string emailFormat = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
                if (!Regex.IsMatch(e.EmpPersonalInfo.Email, emailFormat))
                    ModelState.AddModelError("Validation", AgilityHelper.EmailFormat("Email Address"));
            }

            if (string.IsNullOrWhiteSpace(e.EmpPersonalInfo.CellNo))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Mobile #"));
            else if (!Regex.IsMatch(e.EmpPersonalInfo.CellNo, @"^\(?([0-9]{4})\)?[-]?([0-9]{7})$"))
                ModelState.AddModelError("Validation", AgilityHelper.CallFormat("Mobile #"));

            if (!e.EmpPersonalInfo.WorkingSince.HasValue)
            {
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Working Since Date"));
            }

            if (!string.IsNullOrWhiteSpace(e.EmpPersonalInfo.PhoneNo))
            {
                if (!Regex.IsMatch(e.EmpPersonalInfo.PhoneNo, @"^\(?([0-9]{3,4})\)?[-]?([0-9]{6,7})$"))
                    ModelState.AddModelError("Validation", AgilityHelper.CallFormat("Phone #"));
            }

            if (string.IsNullOrWhiteSpace(e.EmpPersonalInfo.CNICNo))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("CNIC #"));
            else if (!string.IsNullOrWhiteSpace(e.EmpPersonalInfo.CNICNo) && !Regex.IsMatch(e.EmpPersonalInfo.CNICNo, @"^\(?([0-9]{5})\)?[-]?([0-9]{7})?[-]?([0-9]{1})$"))
                ModelState.AddModelError("Validation", "=> Please enter CNIC # in valid format like xxxxx-xxxxxxx-x");


            //if (e.LeaveEntitlement.Count > 0)
            //{
            //    if (e.LeaveEntitlement.Where(x => !x.DueDate.HasValue).Any())
            //        ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("DueDate"));

            //    if (e.LeaveEntitlement.Where(x => x.AllowedDays <= 0).Any())
            //        ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Allowed Days"));

            //    if (e.LeaveEntitlement.GroupBy(x => x.LeaveTypeId).Any(grp => grp.Count() > 1))
            //        ModelState.AddModelError("Validation", "=> Leave used in Employee Leave must be unique");

            //}

            if (e.Assets.Count > 0)
            {
                if (e.Assets.Where(x => !x.AssetTypeId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Asset"));

                if (e.Assets.Where(x => string.IsNullOrEmpty(x.RegistrationNo)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Registration #"));

                if (e.Assets.Where(x => string.IsNullOrEmpty(x.Model)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Model"));

                if (e.Assets.Where(x => x.BaseValue <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("BaseValue"));

                if (e.Assets.Where(x => x.Limit <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Limit"));

                if (e.Assets.GroupBy(x => new { x.AssetTypeId,x.RegistrationNo}).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Asset and Reg # used in Employee Asset must be unique");

            }

            if (e.Attachments.Count > 0)
            {
                if (e.Attachments.Where(x => !x.AttachmentTypeId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Attachment Type"));

                //if (e.EmpAttachmentDetails.GroupBy(x => x.AttachmentTypeId ).Any(grp => grp.Count() > 1))
                //    ModelState.AddModelError("Validation", "=> Doc Attachment used in Employee Doc must be unique");

               
                if (e.Attachments.Where(x => x.ExpiryDate.HasValue).Where(z => z.ExpiryDate.Value.Date < DateTime.Now.Date).Count() > 0)
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtCurrent("Expiry Date"));

                ValidateAttachments(e.Attachments, (List<AttachmentTypeList>)Session["lstAttachment"]);
            }

            if (e.CostAllocations.Count > 0)
            {
                if (e.CostAllocations.Where(x => string.IsNullOrEmpty(x.BranchCode)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Branch"));

                if (e.CostAllocations.Where(x => !x.TemplateId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Template"));

                 if (e.CostAllocations.Where(x => x.Rate <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Percentage"));

                  var SumP = e.CostAllocations.Sum(x => x.Rate);
                 if (SumP > 100)
                ModelState.AddModelError("Validation", "=> The  Percentage  must not exceed 100% to save the record. ");

                if (e.CostAllocations.GroupBy(x => new { x.BranchCode, x.TemplateId }).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Branch & Template used in Employee Cost Allocation must be unique");
            }

            //if (e.EmergencyContacts.Count > 0)
            //{
            //    if (e.EmergencyContacts.Where(x => string.IsNullOrEmpty(x.NoKContactNo)).Any())
            //        ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("NoKContactNo"));

            //    if (e.EmergencyContacts.Where(x => string.IsNullOrEmpty(x.NoKName)).Any())
            //        ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("NoKName"));

            //    if (e.EmergencyContacts.Where(x => !x.RelationId.HasValue).Any())
            //        ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Relation"));


            //    if (e.EmergencyContacts.Where(x => !string.IsNullOrEmpty(x.NoKContactNo)).Any())
            //    {
            //        if (e.EmergencyContacts.Where(x => !Regex.IsMatch(x.NoKContactNo, @"^\(?([0-9]{3,4})\)?[-]?([0-9]{6,7})$")).Any())
            //            ModelState.AddModelError("Validation", AgilityHelper.CallFormat("Phone #"));
            //    }

            //    if (e.EmergencyContacts.GroupBy(x => new { x.RelationId, x.NoKContactNo }).Any(grp => grp.Count() > 1))
            //        ModelState.AddModelError("Validation", "=> Relation and Contact # used in Employee Emergency Conatct must be unique");
            //}

            if (e.Family.Count > 0)
            {
                if (e.Family.Where(x => string.IsNullOrEmpty(x.MemberName)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Family Member Name"));
                
                 //if (e.Family.Where(x => !x.MedicalPlanId.HasValue).Any())
                 //    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("MedicalPlan"));

                if (e.Family.Where(x => !x.RelationId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Relation"));

                //if (e.Family.Where(x => x.MedicalCost <= 0).Any())
                //    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Medical Cost"));

                if (e.Family.Where(x => !x.DoB.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Date of Birth"));

                if (e.Family.Where(x => x.EmergencyContact && string.IsNullOrWhiteSpace(x.ContactNo)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Emergency Contact #"));

                if (e.Family.Where(x => !string.IsNullOrEmpty(x.ContactNo)).Any())
                {
                    if (e.Family.Where(x => !Regex.IsMatch(x.ContactNo, @"^\(?([0-9]{3,4})\)?[-]?([0-9]{6,7})$")).Any())
                        ModelState.AddModelError("Validation", AgilityHelper.CallFormat("Emergency Contact Phone #"));
                }

                //if (e.EmpFamilyMemberDetails.GroupBy(x => new { x.RelationId, x.MedicalPlanId }).Any(grp => grp.Count() > 1))
                //    ModelState.AddModelError("Validation", "=> Relation  & Medical Plan used in Employee Fmaily Member must be unique");
            }

            if (e.Salary.Count == 0)
                ModelState.AddModelError("Validation", "=> At Least One Row should be added in Monthly Salary Grid before saving");

            if (e.Salary.Count > 0)
            {
                if (e.Salary.Where(x => !x.HeadId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Salary Head"));

                if (e.Salary.Where(x => x.Amount <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Amount"));

                if (e.Salary.GroupBy(x => x.HeadId).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Salary Head used in Employee Monthly Salary must be unique");

                //if (e.Salary.Where(x => x.TotalSalary <= 0).Any())
                //    ModelState.AddModelError("Validation", "=> Sum of Total Salary cannot be Zero or less then zero ");
            }
        }

        internal static bool ValidateAttachments(List<EmpAttachment> _attachments,
           List<AttachmentTypeList> _wfat, bool _includeNewLine = true)
        {
            try
            {
                if (_wfat != null && _wfat.Count() > 0)
                {
                    IEnumerable<object> _result = (IEnumerable<object>)
                        (from dox in _wfat
                         join supporting in _attachments.Where(a => !a.IsDeleted) on
                         dox.AttachmentTypeId equals supporting.AttachmentTypeId
                         into ps
                         from supporting in ps.DefaultIfEmpty()
                         select new
                         {
                             AttachmentTypeName = dox.AttachmentTypeName,
                             Mandatory = dox.Mandatory,
                             FileName = supporting == null ? "(No File)" : supporting.AttachmentName
                         }).Where(a => a.Mandatory && a.FileName == "(No File)");

                    if (_result.Count() > 0)
                    {
                        string missingDox = "";
                        foreach (dynamic item in _result)
                        {
                            missingDox += "'" + item.AttachmentTypeName + "', ";
                        }
                        throw new Exception("Mandatory attachment(s) are missing, Please enclose following missing attachment(s) and try again" +
                            (_includeNewLine ? Environment.NewLine : " ") + missingDox);
                    }

                }
                return true;
            }
            catch (Exception)
            { throw; }
        }

        [HttpPost]
        public ActionResult SaveAttachment()
        {
            var msg = new Object();

            EmpAttachment ead = new EmpAttachment();
            List<EmpAttachment> lstDetail = new List<EmpAttachment>();
            lstDetail = (List<EmpAttachment>)Session["DocAttachment"];
            if (Request.Form["DExpiryDate"] != "")
            ead.ExpiryDate = Convert.ToDateTime(Request.Form["DExpiryDate"]);
            ead.AttachmentTypeId = Convert.ToInt16(Request.Form["AttachmentTypeId"]);
            ead.IsNew = true;
            ead.IsDeleted = false;

            HttpPostedFileBase file = Request.Files["UploadedFile"];

            if (file.ContentLength / 1000 > 1024)
            {
                throw new Exception("Upload File size exceed the maximum file size allowed for which is 1024 KB ");
            }

            if ((file != null) && (file.ContentLength > 0) && !string.IsNullOrEmpty(file.FileName))
            {
                ead.AttachmentContentType = file.ContentType;
                ead.AttachmentContent = new byte[file.ContentLength];
                ead.AttachmentName = Path.GetFileName(file.FileName);
               
                file.InputStream.Read(ead.AttachmentContent, 0, file.ContentLength);
            }

            else
                throw new Exception("File is mandatory for Employee ");

            lstDetail.Add(ead);           
            Session["DocAttachment"] = lstDetail;


            msg = new { success = true, data = lstDetail.Where(a => !a.IsDeleted).ToList() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

         [HttpPost]
        public ActionResult DeleteAttachment(int _keyId)
        {
            var msg = new Object();
            List<EmpAttachment> lstDetail = new List<EmpAttachment>();
            try
            {               
               
                lstDetail = (List<EmpAttachment>)Session["DocAttachment"];
                EmpAttachment _att = lstDetail.Where(m => m.AttachmentTypeId == _keyId).FirstOrDefault();
                //if (lstDetail != null)
                //{
                //    lstDetail.Remove(_att);
                //    Session["DocAttachment"] = lstDetail;
                //}

                if (_att != null)
                {
                    if (_att.IsNew)
                        lstDetail.Remove(_att);
                    else
                    {
                        _att.IsDeleted = true;
                        _att.AttachmentContent = null;
                    }
                    Session["DocAttachment"] = lstDetail;
                }
                msg = new { success = true, data = lstDetail.Where(a => !a.IsDeleted).ToList() };
              
            }
            catch (Exception ex)
            {
                msg = new { success = false, data = lstDetail.Where(a => !a.IsDeleted).ToList(), Message = ex.Message };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        //public ActionResult ViewAttachment(int id)
        //{
        //    EmpAttachmentDetail att = new EmpAttachmentDetail();

        //    List<EmpAttachmentDetail> lstDetail = new List<EmpAttachmentDetail>();
        //    lstDetail = (List<EmpAttachmentDetail>)Session["DocAttachment"];
        //    if (lstDetail != null)
        //    {
        //        EmpAttachmentDetail _att = lstDetail.Where(m => m.AttachmentTypeId == id && !m.IsDeleted).FirstOrDefault();
        //        if (_att != null)
        //        {
        //            MemoryStream ms = new MemoryStream();
        //            ms.Write(_att.AttachmentContent, 0, _att.AttachmentContent.Length);
        //            ms.Position = 0;
        //            Response.AddHeader("Content-Disposition", "attachment; filename=" + _att.AttachmentName);
        //            return new FileStreamResult(ms, _att.AttachmentContentType);
        //        }
        //        throw new Exception("Required file not found!");
        //    }
        //    else
        //        throw new Exception("No file exist in Attachment list for this request");
        //}

         
        public ActionResult ViewAttachment(int _KeyId)
        {
            List<EmpAttachment> lstDetail = new List<EmpAttachment>();
            lstDetail = (List<EmpAttachment>)Session["DocAttachment"];
            if (lstDetail != null)
            {
                EmpAttachment att = lstDetail.Where(m => m.AttachmentTypeId == _KeyId && !m.IsDeleted).FirstOrDefault();
                if (att != null)
                {
                    MemoryStream ms = new MemoryStream();
               
                    ms.Write(att.AttachmentContent, 0, att.AttachmentContent.Length);
                    ms.Position = 0;
                    Response.AddHeader("Content-Disposition", "attachment; filename=" + att.AttachmentName);
           
                    return new FileStreamResult(ms, att.AttachmentContentType);
                }
                throw new Exception("Required file not found!");
            }
            else
                throw new Exception("No file exist in Attachment list for this request");
        }

        public ActionResult EmpDetail()
        {
            return PartialView("_EmpPersonalDetail");
        }
        #endregion

        //public JsonResult Recall()
        //{
        //    var msg = new Object();
        //    Session["FormMode"] = AgilityEnums.formMode.Recall;
        //    msg = new { success = true, Session = Session["FormMode"].ToString() };
        //    return Json(msg, JsonRequestBehavior.AllowGet);
        //}

        //public ActionResult GetId(string _keyId)
        //{
        //    Employee _as = new Employee();
        //    _as.EmployeeCode = _keyId;
        //    //_as.BSSession = Convert.ToInt16(Session["BasicSalaryId"]);
        //    //_as.PFSession = Convert.ToInt16(Session["ProvidentFundId"]);
        //    Session["FormMode"] = AgilityEnums.formMode.Initialize;
        //    return View("DataForm", _as);
        //}
    }
}
