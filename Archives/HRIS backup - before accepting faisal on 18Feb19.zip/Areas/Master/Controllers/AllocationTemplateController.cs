﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class AllocationTemplateController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                AllocationTemplate _at = new AllocationTemplate();
                ModelState.Clear();
                return Json(new { success = true, AllocationTemplate = _at, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(AllocationTemplate _at)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_at);
                #endregion

                #region save to db
                if (ModelState.IsValid)
                {
                    if (AllocationTemplate.Save(_at, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        msg = new { success = true, message = Success, session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                if (!ModelState.IsValid)
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                AllocationTemplate _at = AllocationTemplate.Get(_keyId);
                if (_at == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Allocation Template Id entered doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, AllocationTemplate = _at, session = _formMode.ToString() };
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new AllocationTemplateList()),
                    rowData = AllocationTemplateList.Get(false)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Json Method
        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    lstDepartment = DepartmentList.Get(true),
                  
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Allocation Template'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(AllocationTemplate _at)
        {
            if (string.IsNullOrEmpty(_at.TemplateDesc))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Template Desc"));

            if (_at.Details.Count == 0)
            {
                ModelState.AddModelError("Validation", "=> Atleast one Division must exist in Template to perform save operation");
            }

            else if (_at.Details.Where(x => string.IsNullOrEmpty(x.DepartmentCode)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Department"));

            else if (_at.Details.GroupBy(x => x.DepartmentCode).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Department used in Template must be unique");

            else if (_at.Details.Where(x => x.Rate <= 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Rate"));

            var SumP = _at.Details.Sum(x => x.Rate);
            if (SumP != 100)
                ModelState.AddModelError("Validation", "=> The Department Rate total must be 100% to save the record. Please complete the division allocation before saving");
        }
        #endregion
    }
}



