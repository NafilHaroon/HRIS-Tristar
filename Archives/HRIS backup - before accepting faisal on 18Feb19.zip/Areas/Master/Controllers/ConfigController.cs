﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class ConfigController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save(Config _C)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_C);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Config.Save(_C, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        msg = new { success = true, message = Success, session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                if (!ModelState.IsValid)
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get()
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                Config _cn = Config.Get();
                if (_cn == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Config  doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, Config = _cn, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Json Method
        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    success = true,
                    lstLoan = getSalaryHead(3),
                    lstAbsent = getSalaryHead(4),

                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public List<SalaryHeadList> getSalaryHead(short _CompanyId)
        {
            List<SalaryHeadList> c = SalaryHeadList.Get(true).Where(x => x.HeadTypeId == _CompanyId).ToList();
            return c;
        }
        //}
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName =  'Config'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(Config _c)
        {
            if (!_c.AbsentDeductionId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Absent Deduction"));

            if (!_c.AdvanceDeductionId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Advance Deduction"));

            if (!_c.LoanDeductionId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Loan Deduction"));
        }
        #endregion
    }
}