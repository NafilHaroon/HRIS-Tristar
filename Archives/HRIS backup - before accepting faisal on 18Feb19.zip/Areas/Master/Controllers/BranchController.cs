﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class BranchController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save(Branch _b)
        {
            var msg = new Object();
            try
            {
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Branch.Save(_b, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        msg = new { success = true, message = Success, session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                if (!ModelState.IsValid)
                {
                    msg = new { success = false, message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString() };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(string _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                Branch _b = Branch.Get(_keyId);
                if (_b == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Branch Code entered doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, branch = _b, Session = _formMode.ToString()};
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new { success = true, columnDefs = ColumnDefinition.getColDef(new BranchList()),
                    rowData = BranchList.Get(Session["UserId"].ToString(), false) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Branch'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }
        #endregion
    }
}