﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class SalaryHeadController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                SalaryHead _sh = new SalaryHead();
                ModelState.Clear();
                return Json(new { success = true, SalaryHead = _sh, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(SalaryHead _sh)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_sh);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (SalaryHead.Save(_sh, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                SalaryHead _sh = SalaryHead.Get(_keyId);
                if (_sh == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Salary Head Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, SalaryHead = _sh, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new SalaryHeadList()),
                    rowData = SalaryHeadList.Get(false)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    lstHeadType = HeadTypeList.Get(),
                    lstWorkerType = WorkerType.Get()
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Salary Head'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(SalaryHead _sh)
        {
            if (string.IsNullOrEmpty(_sh.HeadName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Head Name"));

            if (!_sh.HeadTypeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("HeadTypeId"));
            
            if (_sh.DefaultAmount <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Default Amount"));

            if (_sh.Details.Count == 0)
            {
                ModelState.AddModelError("Validation", "=> Atleast one Worker Type must exist in Salary Head to perform save operation");
            }

            if (_sh.Details.Where(x => !x.WorkerTypeId.HasValue).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Worker Type"));

            if (_sh.Details.GroupBy(x => x.WorkerTypeId).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Worker Type must be specified only once in specific Salary Head ");

            if (_sh.Details.Where(x => string.IsNullOrWhiteSpace(x.S21NegativeAccount)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("S21NegativeAccount"));

            if (_sh.Details.Where(x => string.IsNullOrWhiteSpace(x.S21PositiveAccount)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("S21PositiveAccount"));
        }
        #endregion
    }
}
