﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.ProvidentFund.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class CompanyController : Controller
    {
        
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                Company _c = new Company();
                ModelState.Clear();
                return Json(new { success = true, Company = _c, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(Company _c)
        {
            var msg = new Object();
            try
            {
                if (_c.CompanyLogo != null)
                {
                    string imageBase64Data = Convert.ToBase64String(_c.CompanyLogo);
                    _c.image = imageBase64Data;
                }

                #region Validation
                validate(_c);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Company.Save(_c, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                Company _c = Company.Get(_keyId);
                if (_c.CompanyLogo != null)
                {
                    string imageBase64Data = Convert.ToBase64String(_c.CompanyLogo);
                    _c.image = imageBase64Data;
                    _c.CompanyLogo = null;
                }
                if (_c == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Company Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, Company = _c, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new CompanyList()),
                    rowData = CompanyList.Get(Session["UserId"].ToString(), false)
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Json Method
        [HttpGet]
        public JsonResult GetLookups()
        {            try
            {
                return Json(new
                {
                    lstPFAccount = getPFAccounts(Convert.ToInt16(Session["CompanyId"])),

                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        
        public List<CoAList> getPFAccounts(short _CompanyId)
        {
            List<CoAList> co = CoAList.getCOAsList(Session["UserId"].ToString()).Where(x => x.CompanyId == _CompanyId && x.BankAccount == false
            && x.AccountTypeId == 1).ToList();
            return co;
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Company'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(Company _c)
        {
            if (string.IsNullOrEmpty(_c.CompanyName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Name"));

            if (string.IsNullOrEmpty(_c.CompanyCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Code"));

            if (string.IsNullOrEmpty(_c.CompanyNameOnPayslip))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Name On Payslip"));

            if (string.IsNullOrEmpty(_c.CompanyAddress))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Address"));

            if (string.IsNullOrEmpty(_c.NTN))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("NTN"));

            if (string.IsNullOrEmpty(_c.EOBIRegistrationNumber))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("EOBI Registration #"));
        }
        #endregion
    }
}
