﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class MonthlyCalendarController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, MonthlyCalendar b, FormCollection formCollection)
        {
            return View();
        }


        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            MonthlyCalendar _as = new  MonthlyCalendar();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = _as, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(MonthlyCalendar e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (MonthlyCalendar.Save(e))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = e, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(), Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short monthnum, int year)
        {
            var msg = new Object();
            try
            {
                MonthlyCalendar cn = MonthlyCalendar.Get(monthnum, year);

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        #endregion


        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstMonthYear"] = MonthlyCalendarList.getMonthlyCalendarList();

        }
        #endregion

        #region Json Method
        public JsonResult GetMonth()
        {
            return Json((List<MonthlyCalendarList>)Session["lstMonthYear"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetYear()
        {
            List<MonthlyCalendarList> mcDetails = new List<MonthlyCalendarList>();
            mcDetails = (List<MonthlyCalendarList>)Session["lstMonthYear"];
            

            var result = mcDetails.GroupBy(test => test.Year)
                   .Select(grp => grp.First())
                   .ToList();

            return Json((List<MonthlyCalendarList>)result, JsonRequestBehavior.AllowGet);
        }

        #endregion


        #region private methods

        private void clearSessions()
        {
            Session.Remove("lstMonthYear");
        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Monthly Calendar'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        private void validate(MonthlyCalendar at)
        {           

            if (at.Details.Where(x =>  x.Holiday==true && string.IsNullOrEmpty(x.Reason)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Please Enter Reason for those where Holiday is marked"));                       

        }

      
        #endregion
    }
}
