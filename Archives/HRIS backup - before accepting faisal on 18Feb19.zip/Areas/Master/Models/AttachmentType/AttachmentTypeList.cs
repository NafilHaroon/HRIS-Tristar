﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class AttachmentTypeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Type Id", Order = 0)]
        public short AttachmentTypeId { get; set; }
        [Display(Name = "Attachment Type Name", Order = 1)]
        public string AttachmentTypeName { get; set; }
        [Display(Name = "Mandatory", Order = 2)]
        public bool Mandatory { get; set; }
        [Display(Name = "Expiry Date Required", Order = 3)]
        public bool Expires { get; set; }
        [Display(Name = "Active?", Order = 4)]
        public bool IsActive { get; set; }
        #endregion

        #region constructor
        public AttachmentTypeList() { }
        public AttachmentTypeList(short _typeId, string _typeName, bool _mandatory, bool _expires, bool _isActive = true)
        {
            AttachmentTypeId = _typeId;
            AttachmentTypeName = _typeName;
            Mandatory = _mandatory;
            Expires = _expires;
            IsActive = _isActive;
        }
        #endregion

        #region internal methods
        internal static List<AttachmentTypeList> Get(bool _isActive = true)
        {
            List<AttachmentTypeList> lstAT = new List<AttachmentTypeList>();

            DbCommand dbCommand = db.GetStoredProcCommand("getAttachmentTypes");
            db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _isActive);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstAT.Add(new AttachmentTypeList(
                             Convert.ToInt16(dr["AttachmentTypeId"]),
                                dr["AttachmentTypeName"].ToString(),
                                Convert.ToBoolean(dr["Mandatory"]),
                                Convert.ToBoolean(dr["Expires"]),
                                Convert.ToBoolean(dr["IsActive"])));
                    }
                }
            }
            return lstAT;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}
