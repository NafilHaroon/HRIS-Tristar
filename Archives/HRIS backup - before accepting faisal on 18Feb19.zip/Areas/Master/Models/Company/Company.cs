﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Company : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Company Id")]
        public short CompanyId { get; set; }
        [Display(Name = "Company Code")]
        public string CompanyCode { get; set; }
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }
        [Display(Name = "Payslip Company Name")]
        public string CompanyNameOnPayslip { get; set; }
        [Display(Name = "Company Address")]
        public string CompanyAddress { get; set; }
        [Display(Name = "NTN")]
        public string NTN { get; set; }
        [Display(Name = "PF Title")]
        public string PFTitle { get; set; }
        [Display(Name = "PF Receivable ")]
        public short? PFReceivableId { get; set; }
        [Display(Name = "EOBI Contribution")]
        public double  EOBIContribution { get; set; }
        [Display(Name = "EOBI Registration #")]
        public string EOBIRegistrationNumber { get; set; }
        //[Display(Name = "Financial Company")]
        //public string FinancialCompanyCode { get; set; }
        [Display(Name = "Logo On PaySlip")]
        public bool CompanyLogoOnPaySlip { get; set; }
        public byte[] CompanyLogo { get; set; }
        public string image { get; set; }
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public Company()
        {
            IsActive = true;
            AuditTrail = new Footer();
        }
        #endregion

        #region internal methods
        internal static Company Get(short _companyid)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetCompanyByCode"))
            {
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _companyid);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (Company _co = new Company())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _co.CompanyId = _companyid;
                            _co.CompanyCode = dr["CompanyCode"].ToString();
                            _co.CompanyName = dr["CompanyName"].ToString();
                            _co.CompanyNameOnPayslip = dr["CompanyNameOnPayslip"].ToString();
                            _co.CompanyAddress = dr["CompanyAddress"].ToString();
                            _co.NTN = dr["NTN"].ToString();
                            _co.PFTitle = dr["PFTitle"].ToString();
                            _co.PFReceivableId = Convert.ToInt16(dr["PFReceivableId"]);
                            _co.EOBIContribution = Convert.ToDouble(dr["EOBIContribution"]);
                            _co.EOBIRegistrationNumber = dr["EOBIRegistrationNumber"].ToString();
                            _co.CompanyLogoOnPaySlip =  Convert.ToBoolean(dr["CompanyLogoOnPaySlip"]);
                            if (dr["CompanyLogo"] != DBNull.Value)
                                _co.CompanyLogo = (byte[])(dr["CompanyLogo"]);
                            
                            _co.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _co.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _co.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _co.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _co.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                         
                            return _co;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(Company _co, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveCompany"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _co.CompanyId);
                    db.AddInParameter(dbCommand, "CompanyCode", SqlDbType.VarChar, _co.CompanyCode);
                    db.AddInParameter(dbCommand, "CompanyName", SqlDbType.VarChar, _co.CompanyName);
                    db.AddInParameter(dbCommand, "CompanyNameOnPayslip", SqlDbType.VarChar, _co.CompanyNameOnPayslip);
                    db.AddInParameter(dbCommand, "CompanyAddress", SqlDbType.VarChar, _co.CompanyAddress);
                    db.AddInParameter(dbCommand, "NTN", SqlDbType.VarChar, _co.NTN);
                    db.AddInParameter(dbCommand, "PFTitle", SqlDbType.VarChar, _co.PFTitle);
                    db.AddInParameter(dbCommand, "EOBIContribution", SqlDbType.Float, _co.EOBIContribution);
                    db.AddInParameter(dbCommand, "EOBIRegistrationNumber", SqlDbType.VarChar, _co.EOBIRegistrationNumber);
                    db.AddInParameter(dbCommand, "PFReceivableId", SqlDbType.SmallInt, _co.PFReceivableId);
                    db.AddInParameter(dbCommand, "CompanyLogoOnPaySlip", SqlDbType.Bit, _co.CompanyLogoOnPaySlip);
                    db.AddInParameter(dbCommand, "CompanyLogo", SqlDbType.VarBinary, _co.CompanyLogo);
                    db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _co.IsActive);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _co.AuditTrail.UpdatedOn);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
