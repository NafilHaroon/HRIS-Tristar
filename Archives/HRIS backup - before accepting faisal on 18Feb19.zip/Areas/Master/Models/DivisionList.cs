﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class DivisionList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short DivisionId { get; set; }
        public string DivisionName { get; set; }

        #endregion

        #region constructor
        public DivisionList()
        {
        }

        public DivisionList(short _DivisionId, string _DivisionName)
        {
            DivisionId = _DivisionId;
            DivisionName = _DivisionName;

        }
        #endregion

        #region internal methods
        internal static List<DivisionList> Get()
        {
            return getDivisions();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getDivisions());
        }
        #endregion

        #region private methods
        private static List<DivisionList> getDivisions()
        {
            List<DivisionList> lstDivision = new List<DivisionList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getDivisionList"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstDivision.Add(new DivisionList(
                             Convert.ToInt16(dr["DivisionId"]),
                                dr["DivisionName"].ToString()));
                        }
                    }
                }
            }
            return lstDivision;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}