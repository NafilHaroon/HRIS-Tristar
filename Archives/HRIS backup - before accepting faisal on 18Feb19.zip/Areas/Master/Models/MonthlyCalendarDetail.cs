﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;



namespace HRIS.Areas.Master.Models
{
    public class MonthlyCalendarDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        [Display(Name = "CalendarDate")]
        public DateTime? CalendarDate { get; set; }
        [Display(Name = "Day")]
        public string Day { get; set; }
        [Display(Name = "Holiday")]
        public bool Holiday { get; set; }
        public string Reason { get; set; }
        public string Status { get; set; }
        #endregion

        #region constructor
        public MonthlyCalendarDetail()
        {
            DetailId = 0;
            Status = "Added";
        }

        public MonthlyCalendarDetail(int _detailId, DateTime _CalendarDate,
            string _Day, bool _Holiday, string _Reason,
            string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            CalendarDate = _CalendarDate;
            Day = _Day;
            Holiday = _Holiday;
            Reason = _Reason;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<MonthlyCalendarDetail> getDetailbyId(short _monthnumber, int _year)
        {
            try
            {
                List<MonthlyCalendarDetail> adjList = new List<MonthlyCalendarDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetMonthlyCalendar"))
                {
                    db.AddInParameter(dbCommand, "MonthNumber", SqlDbType.SmallInt, _monthnumber);
                    db.AddInParameter(dbCommand, "Year", SqlDbType.Int, _year);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                adjList.Add(new MonthlyCalendarDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToDateTime(dr["CalendarDate"]),
                                    dr["Day"].ToString(),                                   
                                    Convert.ToBoolean(dr["Holiday"]),
                                     dr["Reason"].ToString()));
                            }
                        }
                    }
                }
                return adjList;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(List<MonthlyCalendarDetail> _details,
            List<MonthlyCalendarDetail> _originalDetails, DbTransaction _transaction)
        {
            try
            {
                foreach (MonthlyCalendarDetail _cdd in getCDDetailChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveMonthlyCalendar"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, _cdd.DetailId);
                        //db.AddInParameter(dbCommand, "CalendarDate", SqlDbType.DateTime, _cdd.CalendarDate);
                        db.AddInParameter(dbCommand, "Reason", SqlDbType.VarChar, _cdd.Reason);
                        db.AddInParameter(dbCommand, "Holiday", SqlDbType.Bit, _cdd.Holiday);
                        //db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                        //_cdd.Status == "Added" ? "I" : (
                        //_cdd.Status == "Deleted" ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<MonthlyCalendarDetail> getCDDetailChanges(List<MonthlyCalendarDetail> details,
            List<MonthlyCalendarDetail> originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<MonthlyCalendarDetail> editedItems = (IEnumerable<MonthlyCalendarDetail>)
                    (from actualItem in details
                     where AgilityHelper.InList(actualItem.Status,
                        "Edited", "Added")
                     select actualItem).Union(
                        from actualItem in originalDetails
                        where !
                        (from newItem in details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<MonthlyCalendarDetail>();
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion


    }
}