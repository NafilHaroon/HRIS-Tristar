﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class DepartmentList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public string DepartmentCode { get; set; }
        public string DepartmentName { get; set; }
  
        #endregion

        #region constructor
        public DepartmentList()
        {
        }

        public DepartmentList(string _DepartmentCode, string _DepartmentName)
        {           
                DepartmentCode = _DepartmentCode;
                DepartmentName = _DepartmentName;
           
        }
        #endregion



        #region internal methods
        internal static List<DepartmentList> Get(bool _activeOnly)
        {
            return getDepartmentList(_activeOnly);
        }

        internal static DataTable GetDT(bool _activeOnly)
        {
            return AgilityHelper.ListToDataTable(getDepartmentList(_activeOnly));
        }
        #endregion

        #region private methods
        private static List<DepartmentList> getDepartmentList(bool _activeOnly)
        {
            List<DepartmentList> lstDepartment = new List<DepartmentList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getDepartmentList"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _activeOnly);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstDepartment.Add(new DepartmentList(
                                dr["DepartmentCode"].ToString(),
                                dr["DepartmentName"].ToString()));
                        }
                    }
                }
            }
            return lstDepartment;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}