﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Department : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Department Code")]
        public string DepartmentCode { get; set; }
        [Display(Name = "Department Name")]
        public string DepartmentName { get; set; }
        [Display(Name = "S21 Department Code")]
        public string S21DepartmentCode { get; set; }
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public Department()
        {
            AuditTrail = new Footer();
            IsActive = true;
        }
        #endregion

        #region internal methods
        internal static Department Get(string _departmentCode)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetDepartmentByCode"))
            {
                db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, _departmentCode);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (Department _bran = new Department())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _bran.DepartmentCode = dr["DepartmentCode"].ToString();
                            _bran.DepartmentName = dr["DepartmentName"].ToString();
                            _bran.S21DepartmentCode = dr["S21DepartmentCode"].ToString();
                            _bran.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _bran.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _bran.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _bran.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _bran.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                         
                            return _bran;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(Department _dept, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveDepartment"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, _dept.DepartmentCode);
                    db.AddInParameter(dbCommand, "S21DepartmentCode", SqlDbType.VarChar, _dept.S21DepartmentCode);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _dept.AuditTrail.UpdatedOn);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
