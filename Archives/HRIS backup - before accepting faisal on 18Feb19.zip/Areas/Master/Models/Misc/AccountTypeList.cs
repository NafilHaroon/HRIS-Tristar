﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class AccountTypeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short AccountTypeId { get; set; }
        public string AccountTypeName { get; set; }

        #endregion

        #region constructor
        public AccountTypeList()
        {
        }

        public AccountTypeList(short _AccountTypeId, string _AccountTypeName)
        {
            AccountTypeId = _AccountTypeId;
            AccountTypeName = _AccountTypeName;

        }
        #endregion

        #region internal methods
        internal static List<AccountTypeList> Get()
        {
            return getAccountTypes();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getAccountTypes());
        }
        #endregion

        #region private methods
        private static List<AccountTypeList> getAccountTypes()
        {
            List<AccountTypeList> lstAccountType = new List<AccountTypeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getAccountTypeList"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstAccountType.Add(new AccountTypeList(
                             Convert.ToInt16(dr["AccountTypeId"]),
                                dr["AccountTypeName"].ToString()));
                        }
                    }
                }
            }
            return lstAccountType;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}