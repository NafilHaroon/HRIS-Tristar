﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class AssetTypeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short AssetTypeId { get; set; }
        public string AssetTypeName { get; set; }

        #endregion

        #region constructor
        public AssetTypeList()
        {
        }

        public AssetTypeList(short _assetTypeId, string _assetTypeName)
        {
            AssetTypeId = _assetTypeId;
            AssetTypeName = _assetTypeName;

        }
        #endregion

        #region internal methods
        internal static List<AssetTypeList> Get()
        {
            List<AssetTypeList> lstAsset = new List<AssetTypeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getAssetTypes"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstAsset.Add(new AssetTypeList(
                             Convert.ToInt16(dr["AssetTypeId"]),
                                dr["AssetTypeName"].ToString()));
                        }
                    }
                }
            }
            return lstAsset;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}