﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class JobNature : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short JobNatureId { get; set; }
        public string JobNatureName { get; set; }

        #endregion

        #region constructor
        public JobNature()
        {
        }

        public JobNature(short _JobNatureId, string _JobNatureName)
        {
            JobNatureId = _JobNatureId;
            JobNatureName = _JobNatureName;

        }
        #endregion

        #region internal methods
        internal static List<JobNature> Get()
        {
            List<JobNature> lstJobNature = new List<JobNature>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getJobNatureList"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstJobNature.Add(new JobNature(
                                Convert.ToInt16(dr["JobNatureId"]),
                                dr["JobNatureDescription"].ToString()));
                        }
                    }
                }
            }
            return lstJobNature;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}