﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    [DataContract]
    public class MonthlyCalendarList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short MonthNumber { get; set; }
        public string MonthName { get; set; }
        public int Year { get; set; }

        #endregion

        #region constructor
        public MonthlyCalendarList()
        {
        }

        public MonthlyCalendarList(short _MonthNumber, string _MonthName, int _Year)
        {
            MonthNumber = _MonthNumber;
            MonthName = _MonthName;
            Year = _Year;

        }
        #endregion

        #region internal methods
        internal static List<MonthlyCalendarList> getMonthlyCalendars()
        {
            return getMonthlyCalendarList();
        }

        internal static DataTable GetDTMonthlyCalendars()
        {
            return AgilityHelper.ListToDataTable(getMonthlyCalendarList());
        }
        #endregion

        #region internal methods
        internal static List<MonthlyCalendarList> getMonthlyCalendarList()
        {
            List<MonthlyCalendarList> lstMonthlyCalendar = new List<MonthlyCalendarList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetMonthYear"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstMonthlyCalendar.Add(new MonthlyCalendarList(
                             Convert.ToInt16(dr["MonthNumber"]),
                                dr["MonthName"].ToString(),
                                Convert.ToInt32(dr["Year"])));
                        }
                    }
                }
            }
            return lstMonthlyCalendar;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}