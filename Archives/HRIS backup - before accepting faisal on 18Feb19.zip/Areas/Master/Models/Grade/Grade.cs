﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Grade : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Grade Id")]
        public short GradeId { get; set; }
        [Display(Name = "Grade No")]
        public string GradeNo { get; set; }
        [Display(Name = "Grade Name")]
        public string GradeName { get; set; }
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public Grade()
        {
            AuditTrail = new Footer();
            IsActive = true;
        }
        #endregion

        #region internal methods
        internal static Grade Get(string _userId, short _gradeId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("getGradeById"))
            {
                db.AddInParameter(dbCommand, "GradeId", SqlDbType.SmallInt, _gradeId);
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (Grade _grd = new Grade())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _grd.GradeId = Convert.ToInt16(dr["GradeId"]);
                            _grd.GradeNo = dr["GradeNo"].ToString();
                            _grd.GradeName = dr["GradeName"].ToString();
                            _grd.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _grd.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _grd.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _grd.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _grd.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);


                            return _grd;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(Grade _grd, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveGrade"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "GradeId", SqlDbType.TinyInt, _grd.GradeId);
                    db.AddInParameter(dbCommand, "GradeNo", SqlDbType.VarChar, _grd.GradeNo);
                    db.AddInParameter(dbCommand, "GradeName", SqlDbType.VarChar, _grd.GradeName);
                    db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _grd.IsActive);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _grd.AuditTrail.UpdatedOn);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
