﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class GradeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Grade Id")]
        public short GradeId { get; set; }
        [DataMember(Order = 0)]
        [Display(Name = "Grade Name")]
        public string GradeName { get; set; }
        [DataMember(Order = 3)]
        public bool IsActive { get; set; }

        #endregion

        #region constructor
        public GradeList()
        {
        }

        public GradeList(short _GradeId, string _GradeName, bool _isActive = true)
        {
            GradeId = _GradeId;
            GradeName = _GradeName;
            IsActive = _isActive;

        }
        #endregion

        #region internal methods
        internal static List<GradeList> Get(bool _isActive, string _userId)
        {
            return getGrades(_isActive, _userId);
        }

        //internal static DataTable GetDT(bool _isActive)
        //{
        //    return AgilityHelper.ListToDataTable(getGrades(_isActive));
        //}
        #endregion

        #region private methods
        private static List<GradeList> getGrades(bool _isActive, string _userId = null)
        {
            List<GradeList> lstGrade = new List<GradeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand(string.IsNullOrWhiteSpace(_userId)? "getGrades" : "getUserGrades"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _isActive);
                if (!string.IsNullOrWhiteSpace(_userId))
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstGrade.Add(new GradeList(
                             Convert.ToInt16(dr["GradeId"]),
                                dr["GradeName"].ToString(),
                                 Convert.ToBoolean(dr["IsActive"])));
                        }
                    }
                }
            }
            return lstGrade;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}