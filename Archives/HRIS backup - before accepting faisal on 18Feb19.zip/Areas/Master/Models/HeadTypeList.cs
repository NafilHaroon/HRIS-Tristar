﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class HeadTypeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short HeadTypeId { get; set; }
        public string HeadTypeName { get; set; }

        #endregion

        #region constructor
        public HeadTypeList()
        {
        }

        public HeadTypeList(short _HeadTypeId, string _HeadTypeName)
        {
            HeadTypeId = _HeadTypeId;
            HeadTypeName = _HeadTypeName;

        }
        #endregion

        #region internal methods
        internal static List<HeadTypeList> Get()
        {
            return getHeadTypes();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getHeadTypes());
        }
        #endregion

        #region private methods
        private static List<HeadTypeList> getHeadTypes()
        {
            List<HeadTypeList> lstHeadType = new List<HeadTypeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getHeadTypeList"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstHeadType.Add(new HeadTypeList(
                             Convert.ToInt16(dr["HeadTypeId"]),
                                dr["HeadTypeName"].ToString()));
                        }
                    }
                }
            }
            return lstHeadType;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}