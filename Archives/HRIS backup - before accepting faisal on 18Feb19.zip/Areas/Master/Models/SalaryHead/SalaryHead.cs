﻿using HRIS.Areas.Common.Models;
using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class SalaryHead : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Head Id")]
        public short? HeadId { get; set; }
        [Display(Name = "Head Name")]
        public string HeadName { get; set; }
        [Display(Name = "Head Type ")]
        public short? HeadTypeId { get; set; }
        [Display(Name = "Default Amount")]
        public double DefaultAmount { get; set; }
        [Display(Name = "IncludeInSalarySheet")]
        public bool IncludeInSalarySheet { get; set; }
        [Display(Name = "AbsentDeduction")]
        public bool AbsentDeduction { get; set; }
        [Display(Name = "Arrears")]
        public bool Arrears { get; set; }
        //[Display(Name = "S21 Positive Account")]
        //public string S21PositiveAccount { get; set; }
        //[Display(Name = "S21 Negative Account")]
        //public string S21NegativeAccount { get; set; }
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        public List<SalaryHeadDetail> Details { get; set; }
        #endregion

        #region Constructor
        public SalaryHead()
        {
            IsActive = true;
            AuditTrail = new Footer();
            Details = new List<SalaryHeadDetail>();
        }
        #endregion

        #region internal methods
        internal static SalaryHead Get(short _headId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetSalaryHeadByCode"))
            {
                db.AddInParameter(dbCommand, "HeadId", SqlDbType.SmallInt, _headId);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (SalaryHead _sh = new SalaryHead())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _sh.HeadId = Convert.ToInt16(dr["HeadId"]);
                            _sh.HeadName = dr["HeadName"].ToString();
                            _sh.HeadTypeId = Convert.ToInt16(dr["HeadTypeId"]);
                            _sh.DefaultAmount = Convert.ToDouble(dr["DefaultAmount"]);
                            _sh.IncludeInSalarySheet = Convert.ToBoolean(dr["IncludeInSalarySheet"]);
                            _sh.AbsentDeduction = Convert.ToBoolean(dr["AbsentDeduction"]);
                            _sh.Arrears = Convert.ToBoolean(dr["Arrears"]);
                            _sh.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _sh.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _sh.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _sh.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _sh.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                            _sh.Details = SalaryHeadDetail.Get(_sh.HeadId.Value);
                            return _sh;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(SalaryHead _sh, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveSalaryHead"))
            {
                    db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, _sh.HeadId);
                    db.AddInParameter(dbCommand, "HeadName", SqlDbType.VarChar, _sh.HeadName);
                    db.AddInParameter(dbCommand, "HeadTypeId", SqlDbType.TinyInt, _sh.HeadTypeId);
                    db.AddInParameter(dbCommand, "DefaultAmount", SqlDbType.Float, _sh.DefaultAmount);
                    db.AddInParameter(dbCommand, "IncludeInSalarySheet", SqlDbType.Bit, _sh.IncludeInSalarySheet);
                    db.AddInParameter(dbCommand, "AbsentDeduction", SqlDbType.Bit, _sh.AbsentDeduction);
                    db.AddInParameter(dbCommand, "Arrears", SqlDbType.Bit, _sh.Arrears);
                    db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _sh.IsActive);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddOutParameter(dbCommand, "newHeadId", SqlDbType.SmallInt, 32);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _sh.AuditTrail.UpdatedOn);
                                  
                    using (DbConnection dbconnection = db.CreateConnection())
                    {
                        dbconnection.Open();
                        DbTransaction transaction = dbconnection.BeginTransaction();
                        try
                        {
                            db.ExecuteNonQuery(dbCommand, transaction);
                            _sh.HeadId = Convert.ToInt16(dbCommand.Parameters["@newHeadId"].Value);
                            SalaryHeadDetail.Save(_sh.HeadId.Value, _sh.Details, _userId, transaction);
                            transaction.Commit();
                            return true;
                        }
                        catch (Exception)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
            }            
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
