﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;


namespace HRIS.Areas.Master.Models
{
    public class SalaryHeadDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Head Id")]
        public short HeadId { get; set; }
        [Display(Name = "Worker Type")]
        public short? WorkerTypeId { get; set; }
        [Display(Name = "S21 Positive Account")]
        public string S21PositiveAccount { get; set; }
        [Display(Name = "S21 Negative Account")]
        public string S21NegativeAccount { get; set; }
        public int DetailId { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        #endregion

        #region constructor
        public SalaryHeadDetail()
        {
            DetailId = -1;
            Add = true; Edit = false; Delete = false;
        }
        public SalaryHeadDetail(int _detailId, short _workerTypeId, string _s21PositiveAccount, string _s21NegativeAccount)
        {
            
            DetailId = _detailId;
            WorkerTypeId = _workerTypeId;
            S21PositiveAccount = _s21PositiveAccount;
            S21NegativeAccount = _s21NegativeAccount;
            Add = false; Edit = false; Delete = false;
        }
        #endregion

        #region internal methods

        internal static List<SalaryHeadDetail> Get(short _HeadId)
        {
            try
            {
                List<SalaryHeadDetail> lstATD = new List<SalaryHeadDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getSalaryHeadDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "HeadId", SqlDbType.SmallInt, _HeadId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                           
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstATD.Add(new SalaryHeadDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["WorkerTypeId"]),
                                         dr["S21PositiveAccount"].ToString(),
                                         dr["S21NegativeAccount"].ToString()));
                            }
                        }
                    }                  
                }
                return lstATD;
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Save(short _HeadId, List<SalaryHeadDetail> _details, 
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (SalaryHeadDetail SHD in getChanges(_details))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveSalaryHeadDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, SHD.DetailId);
                        db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, _HeadId);
                        db.AddInParameter(dbCommand, "WorkerTypeId", SqlDbType.SmallInt, SHD.WorkerTypeId);
                        db.AddInParameter(dbCommand, "S21PositiveAccount", SqlDbType.VarChar, SHD.S21PositiveAccount);
                        db.AddInParameter(dbCommand, "S21NegativeAccount", SqlDbType.VarChar, SHD.S21NegativeAccount);

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                           SHD.Add ? "I" : (SHD.Delete ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
       
      
        #endregion

        #region private methods
        private static IEnumerable<SalaryHeadDetail> getChanges(List<SalaryHeadDetail> _details)//,List<EmpAsset> _originalDetails)
        {
            return (_details.Where(x => (x.Add && !x.Delete) || (x.Edit && !x.Delete) || x.Delete));
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}