﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class PaymentModeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short PaymentModeId { get; set; }
        public string PaymentModeName { get; set; }

        #endregion

        #region constructor
        public PaymentModeList()
        {
        }

        public PaymentModeList(short _PaymentModeId, string _PaymentModeName)
        {
            PaymentModeId = _PaymentModeId;
            PaymentModeName = _PaymentModeName;

        }
        #endregion

        #region internal methods
        internal static List<PaymentModeList> Get()
        {
            return getPaymentModes();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getPaymentModes());
        }
        #endregion

        #region internal methods
        private static List<PaymentModeList> getPaymentModes()
        {
            List<PaymentModeList> lstPaymentMode = new List<PaymentModeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getPaymentModeList"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstPaymentMode.Add(new PaymentModeList(
                             Convert.ToInt16(dr["PaymentModeId"]),
                                dr["PaymentModeName"].ToString()));
                        }
                    }
                }
            }
            return lstPaymentMode;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}