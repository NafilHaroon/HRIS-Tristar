﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class UserOption : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short SerialNo { get; set; }
        public short? UserOptionId { get; set; }
        public short OptionId { get; set; }
        public string OptionName { get; set; }
        public bool AllowAccess { get; set; }
        public bool AllowAdd { get; set; }
        public bool AllowEdit { get; set; }
        public AgilityEnums.ListItemState Status { get; set; }
        #endregion

        #region Constructors
        public UserOption()
        {

        }

        public UserOption(short _serialNo, object _userOptionId, short _optionId, string _optionName,
            bool _allowAccess, bool _allowAdd, bool _allowEdit,
            AgilityEnums.ListItemState itemState = AgilityEnums.ListItemState.UnChanged)
        {
            SerialNo = _serialNo;
            if (_userOptionId != DBNull.Value)
                UserOptionId = Convert.ToInt16(_userOptionId);
            OptionId = _optionId;
            OptionName = _optionName;
            AllowAccess = _allowAccess;
            AllowAdd = _allowAdd;
            AllowEdit = _allowEdit;
            Status = itemState;
        }
        #endregion

        #region intenral methods
        internal static List<UserOption> getOptionsByUserId(string pUserId)
        {
            List<UserOption> lstOption = new List<UserOption>();
            try
            {
                DbCommand dbCommandDetail = db.GetStoredProcCommand("getUserAccessById");
                db.AddInParameter(dbCommandDetail, "UserId", SqlDbType.VarChar, pUserId);
                using (DataSet ds = db.ExecuteDataSet(dbCommandDetail))
                {
                    if (ds.Tables.Count > 0)
                    {
                        short _serialNo = 1;
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            lstOption.Add(new UserOption(
                                _serialNo++,
                                dr["OptionId"],
                                Convert.ToInt16(dr["OptionId"]),
                                dr["OptionName"].ToString(),
                                Convert.ToBoolean(dr["IsVisible"]),
                                Convert.ToBoolean(dr["CanAdd"]),
                                Convert.ToBoolean(dr["CanEdit"])));
                        }
                    }
                }
                return lstOption;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region IDisposable Member
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}
