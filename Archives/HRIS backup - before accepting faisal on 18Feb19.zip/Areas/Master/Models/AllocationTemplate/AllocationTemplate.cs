﻿using HRIS.Areas.Common.Models;
using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class AllocationTemplate : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Template Id")]
        public short? TemplateId { get; set; }
        [Display(Name = "Template Desc")]
        public string TemplateDesc { get; set; }
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }

        public Footer AuditTrail { get; set; }
        public List<AllocationTemplateDetail> Details { get; set; }


        #endregion

        #region Constructor
        public AllocationTemplate()
        {
            IsActive = true;
            Details = new List<AllocationTemplateDetail>();
            AuditTrail = new Footer();
        }
        #endregion

        #region internal methods
        internal static AllocationTemplate Get(short TemplateId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetAllocationTemplateById"))
            {
                db.AddInParameter(dbCommand, "TemplateId", SqlDbType.SmallInt, TemplateId);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (AllocationTemplate _at = new AllocationTemplate())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _at.TemplateId = TemplateId;
                            _at.TemplateDesc = dr["TemplateDescription"].ToString();
                            _at.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _at.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _at.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _at.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _at.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);

                            _at.Details = AllocationTemplateDetail.Get(_at.TemplateId.Value);                            

                            return _at;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(AllocationTemplate _at, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveAllocationTemplate"))
            {

                db.AddInParameter(dbCommand, "TemplateId", SqlDbType.SmallInt, _at.TemplateId);
                db.AddInParameter(dbCommand, "TemplateDescription", SqlDbType.VarChar, _at.TemplateDesc);
                db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _at.IsActive);

                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddOutParameter(dbCommand, "newTemplateId", SqlDbType.SmallInt, 32);
                db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _at.AuditTrail.UpdatedOn);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        _at.TemplateId = Convert.ToInt16(dbCommand.Parameters["@newTemplateId"].Value);

                        AllocationTemplateDetail.Save(_at.TemplateId.Value, _at.Details, _userId, transaction);

                        transaction.Commit();
                        return true;
                    }

                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }            
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}