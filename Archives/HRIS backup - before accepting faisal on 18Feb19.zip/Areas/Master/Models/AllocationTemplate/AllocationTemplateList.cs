﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class AllocationTemplateList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         [DataMember(Order = 0)]
         [Display(Name = "Template Id")]
         public short TemplateId { get; set; }
         [DataMember(Order = 1)]
         [Display(Name = "TemplateName")]
         public string TemplateName { get; set; }
         [DataMember(Order = 2)]
         public bool IsActive { get; set; }
         
        #endregion

        #region constructor
        public AllocationTemplateList()
        {
        }

        public AllocationTemplateList(short _TemplateId, string _TemplateName, bool _isActive = true)
        {
            TemplateId = _TemplateId;
            TemplateName = _TemplateName;
            IsActive = _isActive;
           
        }
        #endregion

        #region internal methods
        internal static List<AllocationTemplateList> Get(bool isActive)
        {
            List<AllocationTemplateList> lstAT = new List<AllocationTemplateList>();
            DbCommand dbCommand = db.GetStoredProcCommand("getAllocationTemplates");
            db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, isActive);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstAT.Add(new AllocationTemplateList(
                            Convert.ToInt16(dr["TemplateId"]),
                            dr["TemplateDescription"].ToString(),
                            Convert.ToBoolean(dr["IsActive"])));
                    }
                }
            }
            return lstAT;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}