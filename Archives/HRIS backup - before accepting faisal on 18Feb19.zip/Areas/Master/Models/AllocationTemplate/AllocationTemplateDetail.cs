﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class AllocationTemplateDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Template Id")]
        public short TemplateId { get; set; }
        [Display(Name = "Division")]
        public string  DepartmentCode { get; set; }
        [Range(0, 100)]
        [Display(Name = "Rate")]
        public double Rate { get; set; }
        public int DetailId { get; set; }

        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }

        #endregion

        #region constructor
        public AllocationTemplateDetail()
        {
            DetailId = -1;
            Rate = 0;
            Add = true; Edit = false; Delete = false;
        }
        public AllocationTemplateDetail(int _detailId, string  _DepartmentCode, double _Rate)
        {

            DetailId = _detailId;
            DepartmentCode = _DepartmentCode;
            Rate = _Rate;
            Add = false; Edit = false; Delete = false;
        }
        #endregion

        #region internal methods
        internal static List<AllocationTemplateDetail> Get(short _templateid)
        {
            try
            {
                List<AllocationTemplateDetail> lstATD = new List<AllocationTemplateDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getAllocationTemplateDetailById"))
                {
                    db.AddInParameter(dbCommand, "TemplateId", SqlDbType.SmallInt, _templateid);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstATD.Add(new AllocationTemplateDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    dr["DepartmentCode"].ToString(),
                                         Convert.ToDouble(dr["Rate"])));
                            }
                        }
                    }
                }
                return lstATD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _templateid, List<AllocationTemplateDetail> _details,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (AllocationTemplateDetail ATD in getChanges(_details))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveAllocationTemplateDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, ATD.DetailId);
                        db.AddInParameter(dbCommand, "TemplateId", SqlDbType.SmallInt, _templateid);
                        db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, ATD.DepartmentCode);
                        db.AddInParameter(dbCommand, "Rate", SqlDbType.Float, ATD.Rate);


                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                           ATD.Add ? "I" : (ATD.Delete ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<AllocationTemplateDetail> getChanges(List<AllocationTemplateDetail> _details)
        {
            return (_details.Where(x => (x.Add && !x.Delete) || (x.Edit && !x.Delete) || x.Delete));
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}