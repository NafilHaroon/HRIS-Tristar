﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpSalary : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        public short? HeadId { get; set; }
        public double Amount { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        //public string Status { get; set; }
        //public double TotalSalary { get; set; }
        #endregion

        #region constructor
        public EmpSalary()
        {
            DetailId = -1;
            Add = true; Edit = false; Delete = false;
            //Status = "Added";
        }
        public EmpSalary(int _detailId, short _headId, double _amount)//,string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            HeadId = _headId;
            //HeadName = _headName;
            Amount = _amount;
            Add = false; Edit = false; Delete = false;
            //Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<EmpSalary> Get(short _empId)
        {
            try
            {
                List<EmpSalary> lstSalary = new List<EmpSalary>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetEmployeeSalaryById"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstSalary.Add(new EmpSalary(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["HeadId"]),
                                    //dr["HeadName"].ToString(),
                                    Convert.ToDouble(dr["Amount"])));
                            }
                        }
                    }
                }
                return lstSalary;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpSalary> _details, //List<EmpSalary> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpSalary _es in getChanges(_details))//, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeSalaryDetail"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, _es.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, _es.HeadId);
                        db.AddInParameter(dbCommand, "Amount", SqlDbType.Float, _es.Amount);

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            _es.Add ? "I" : (_es.Delete ? "D" : "U")));
                            //eld.Status == "Added" ? "I" : (
                            //eld.Status == "Deleted" ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpSalary> getChanges(List<EmpSalary> _details)//,List<Salary> _originalDetails)
        {
            return (_details.Where(x => x.Add || x.Edit || x.Delete));
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            //_originalDetails.ForEach(o => o.Status = "Deleted");

            ////extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            ////items that were part of initial list but not present in current list
            //IEnumerable<Salary> editedItems = (IEnumerable<Salary>)
            //        (from actualItem in _details
            //         where (actualItem.Status == "Edited" ||
            //         actualItem.Status == "Added")
            //         select actualItem).Union(
            //            from actualItem in _originalDetails
            //            where !
            //            (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
            //            select actualItem);
            //return editedItems.ToList<Salary>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}