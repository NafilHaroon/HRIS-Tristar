﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class EmpStatus : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short StatusId { get; set; }
        public string StatusName { get; set; }
        #endregion

        #region constructor
        public EmpStatus()
        {
        }

        public EmpStatus(short _StatusCode, string _StatusName)
        {
            StatusId = _StatusCode;
            StatusName = _StatusName;

        }
        #endregion

        #region internal methods
        internal static List<EmpStatus> Get()
        {
            List<EmpStatus> lstStatus = new List<EmpStatus>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeStatuses"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstStatus.Add(new EmpStatus(
                                Convert.ToInt16(dr["StatusId"]),
                                dr["StatusName"].ToString()));
                        }
                    }
                }
            }
            return lstStatus;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}