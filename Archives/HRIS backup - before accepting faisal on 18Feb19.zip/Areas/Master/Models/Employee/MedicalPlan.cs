﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class MedicalPlan : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short MedicalPlanId { get; set; }
        public string MedicalPlanName { get; set; }

        #endregion

        #region constructor
        public MedicalPlan()
        {
        }

        public MedicalPlan(short _MedicalPlanId, string _MedicalPlanName)
        {
            MedicalPlanId = _MedicalPlanId;
            MedicalPlanName = _MedicalPlanName;

        }
        #endregion

        #region internal methods
        internal static List<MedicalPlan> Get()
        {
            List<MedicalPlan> lstMedicalPlan = new List<MedicalPlan>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getMedicalPlans"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstMedicalPlan.Add(new MedicalPlan(
                             Convert.ToInt16(dr["MedicalPlanId"]),
                                dr["MedicalPlanName"].ToString()));
                        }
                    }
                }
            }
            return lstMedicalPlan;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}