﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpFamily : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        //[Display(Name = "Relation")]
        public short? RelationId { get; set; }
        //[Display(Name = "Person Name")]
        public string MemberName { get; set; }
        //[Display(Name = "Medical Plan")]
        //public short? MedicalPlanId { get; set; }
        //[Display(Name = "Medical Cost")]
        //public double MedicalCost { get; set; }
        //[Display(Name = "DOB")]
        public DateTime? DoB { get; set; }
        //[Display(Name = "EffectiveDate")]
        //public DateTime? EffectiveDate { get; set; }
        public bool EmergencyContact { get; set; }
        public string ContactNo { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        //        public string Status { get; set; }
        #endregion

        #region constructor
        public EmpFamily()
        {
            DetailId = 1;
            DoB = DateTime.Now.AddYears(-18);
            Add = true; Edit = false; Delete = false;
            //Status ="Added";
        }
        public EmpFamily(int _detailId, short _relationId, string _memberName, //short _MedicalPlanId, double _MedicalCost, 
            DateTime _doB, bool _emergencyContact, string _contactNo)//DateTime _effectiveDate, string  _itemState = "UnChanged")
        {
            DetailId = _detailId;
            RelationId = _relationId;
            MemberName = _memberName;
            //MedicalPlanId = _MedicalPlanId;
            //MedicalCost = _MedicalCost;
            DoB = _doB;
            EmergencyContact = _emergencyContact;
            ContactNo = _contactNo;
            //EffectiveDate = _effectiveDate;
            Add = false; Edit = false; Delete = false;
            //Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<EmpFamily> Get(short _empId)
        {
            try
            {
                List<EmpFamily> lstFM = new List<EmpFamily>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeFamilyById"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstFM.Add(new EmpFamily(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["RelationId"]),
                                    dr["MemberName"].ToString(),
                                    //Convert.ToInt16(dr["MedicalPlanId"]),
                                    //Convert.ToDouble(dr["MedicalCost"]),
                                    Convert.ToDateTime(dr["BirthDate"]),
                                    //Convert.ToDateTime(dr["EffectiveDate"])
                                    Convert.ToBoolean(dr["EmergencyContact"]),
                                    dr["ContactNo"].ToString()));
                            }
                        }
                    }                  
                }
                return lstFM;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpFamily> _details, string _userId, DbTransaction _transaction)//, List<EmpFamilyMember> _originalDetails
        {
            try
            {
                foreach (EmpFamily _efm in getChanges(_details))//, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeFamilyDetail"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, _efm.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "RelationId", SqlDbType.TinyInt, _efm.RelationId);
                        db.AddInParameter(dbCommand, "MemberName", SqlDbType.VarChar, _efm.MemberName);
                        //db.AddInParameter(dbCommand, "MedicalPlanId", SqlDbType.TinyInt, eld.MedicalPlanId);
                        //db.AddInParameter(dbCommand, "MedicalCost", SqlDbType.Float, eld.MedicalCost);
                        db.AddInParameter(dbCommand, "BirthDate", SqlDbType.SmallDateTime, _efm.DoB);
                        //db.AddInParameter(dbCommand, "EffectiveDate", SqlDbType.SmallDateTime, _efm.EffectiveDate);
                        db.AddInParameter(dbCommand, "EmergencyContact", SqlDbType.Bit, _efm.EmergencyContact);
                        db.AddInParameter(dbCommand, "ContactNo", SqlDbType.VarChar, _efm.ContactNo);
                        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "Action", SqlDbType.Char, (
                            _efm.Add ? "I" : (_efm.Delete ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpFamily> getChanges(List<EmpFamily> _details)//,List<EmpFamilyMember> _originalDetails)
        {
            return (_details.Where(x => x.Add || x.Edit || x.Delete));
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            //_originalDetails.ForEach(o => o.Status = "Deleted");

            ////extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            ////items that were part of initial list but not present in current list
            //IEnumerable<EmpFamilyMember> editedItems = (IEnumerable<EmpFamilyMember>)
            //        (from actualItem in _details
            //         where (actualItem.Status == "Edited" ||
            //         actualItem.Status == "Added")
            //         select actualItem).Union(
            //            from actualItem in _originalDetails
            //            where !
            //            (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
            //            select actualItem);
            //return editedItems.ToList<EmpFamilyMember>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}