﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class EmployeeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Name = "Employee Code", Order = 0)]
        public string EmployeeCode { get; set; }
        [DataMember(Name = "Employee Id", Order = 1)]
        public short EmployeeId { get; set; }
        [DataMember(Name = "Employee Name", Order = 2)]
        public string EmployeeName { get; set; }
        [DataMember(Name = "Branch Name", Order = 3)]
        public string BranchName { get; set; }
        [DataMember(Name = "Department Name", Order = 4)]
        public string DepartmentName { get; set; }
        #endregion

        #region constructor
        public EmployeeList()
        {
        }

        public EmployeeList(string _employeeCode, string _employeeName)
        {
            EmployeeCode = _employeeCode;
            EmployeeName = _employeeName;
        }

        public EmployeeList(short _employeeId, string _employeeName)
        {
            EmployeeId = _employeeId;
            EmployeeName = _employeeName;
        }

        public EmployeeList(string _employeeCode, short _employeeId, string _employeeName)
        {
            EmployeeCode = _employeeCode;
            EmployeeId = _employeeId;
            EmployeeName = _employeeName;
        }

        public EmployeeList(string _employeeCode, short _employeeId, string _employeeName, string _branchName, string _departmentName)
        {
            EmployeeCode = _employeeCode;
            EmployeeId = _employeeId;
            EmployeeName = _employeeName;
            BranchName = _branchName;
            DepartmentName = _departmentName;
        }
        #endregion

        #region internal methods
        internal static List<EmployeeList> Get(object _userId, object _companyId)
        {
            List<EmployeeList> lstEmployeeList = new List<EmployeeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployees"))
            {
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.SmallInt, _companyId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstEmployeeList.Add(new EmployeeList(
                                dr["EmployeeCode"].ToString(),
                                Convert.ToInt16(dr["EmployeeId"]),
                                dr["EmployeeName"].ToString(),
                                dr["BranchName"].ToString(),
                                dr["DepartmentName"].ToString()));
                        }
                    }
                }
            }
            return lstEmployeeList;
        }

        internal static List<EmployeeList> GetNotReplaced(object _userId, object _companyId)
        {
            List<EmployeeList> lstEmployeeList = new List<EmployeeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetEmployeesNotReplaced"))
            {
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.SmallInt, _companyId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstEmployeeList.Add(new EmployeeList(
                                Convert.ToInt16(dr["EmployeeId"]),
                                dr["EmployeeName"].ToString()));
                        }
                    }
                }
            }
            return lstEmployeeList;
        }

        internal static List<EmployeeList> GetShortInfo(object _userId, object _companyId)
        {
            List<EmployeeList> lstEmployeeList = new List<EmployeeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeesShortInfo"))
            {
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId.ToString());
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.SmallInt, Convert.ToInt16(_companyId));
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstEmployeeList.Add(new EmployeeList(
                                dr["EmployeeName"].ToString(),
                                Convert.ToInt16(dr["EmployeeId"]),
                                dr["EmployeeCode"].ToString()));
                        }
                    }
                }
            }
            return lstEmployeeList;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}