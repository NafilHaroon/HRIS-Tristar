﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class MaritalStatus : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short MaritalStatusId { get; set; }
        public string MaritalStatusName { get; set; }
  
        #endregion

        #region constructor
        public MaritalStatus()
        {
        }

        public MaritalStatus(short _MaritalStatusId, string _MaritalStatusName)
        {           
                MaritalStatusId = _MaritalStatusId;
                MaritalStatusName = _MaritalStatusName;
           
        }
        #endregion

        #region internal methods
        internal static List<MaritalStatus> Get()
        {
            List<MaritalStatus> lstMaritalStatus = new List<MaritalStatus>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getMaritalStatuses"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstMaritalStatus.Add(new MaritalStatus(
                                Convert.ToInt16(dr["MaritalStatusId"]),
                                dr["MaritalStatusDesc"].ToString()));
                        }
                    }
                }
            }
            return lstMaritalStatus;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}