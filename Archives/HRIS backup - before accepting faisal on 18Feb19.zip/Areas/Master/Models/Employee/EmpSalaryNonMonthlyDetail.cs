﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;
namespace HRIS.Areas.Master.Models
{
    public class EmpSalaryNonMonthlyDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }
        [Display(Name = "Head")]
        public short? HeadId { get; set; }
        [Display(Name = "Unit")]
        public short Unit { get; set; }
        [Display(Name = "Rate")]
        public double Rate { get; set; }
        [Display(Name = "Entitlement")]
        public double Entitlement { get; set; }   
        public int DetailId { get; set; }
        public string  Status { get; set; }
       

        #endregion

        #region constructor
        public EmpSalaryNonMonthlyDetail()
        {
            DetailId = 1;
            Unit = 0;
            Rate = 0;
            Entitlement = 0;
            Status = "Added";
        }
        public EmpSalaryNonMonthlyDetail(int _detailId, short _HeadId, short _Unit, double _Rate, double _Entitlement,
           string  _itemState = "UnChanged")
        {
            
            DetailId = _detailId;
            HeadId = _HeadId;
            Unit = _Unit;
            Rate = _Rate;
            Entitlement = _Entitlement;
            Status = _itemState;
        }
        #endregion

        #region internal methods
 
       internal static List<EmpSalaryNonMonthlyDetail> Get(string _Empcode)
        {
            try
            {
                List<EmpSalaryNonMonthlyDetail> lstESMD = new List<EmpSalaryNonMonthlyDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeNonSalaryEntitlementByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _Empcode);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                           
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstESMD.Add(new EmpSalaryNonMonthlyDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["HeadId"]),
                                         Convert.ToInt16(dr["Unit"]),
                                         Convert.ToInt16(dr["Rate"]),
                                         Convert.ToInt16(dr["Entitlement"])));
                            }
                        }
                    }                  
                }
                return lstESMD;
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Save(string _empcode, List<EmpSalaryNonMonthlyDetail> _details, List<EmpSalaryNonMonthlyDetail> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpSalaryNonMonthlyDetail eld in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeNonSalaryEntitlement"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _empcode);
                        db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, eld.HeadId);
                        db.AddInParameter(dbCommand, "Unit", SqlDbType.TinyInt, eld.Unit);
                        db.AddInParameter(dbCommand, "Rate", SqlDbType.Float, eld.Rate);
                        db.AddInParameter(dbCommand, "Entitlement", SqlDbType.Float, eld.Entitlement);   

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            eld.Status == "Added" ? "I" : (
                            eld.Status == "Deleted"? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
       
      
        #endregion

        #region private methods
        private static IEnumerable<EmpSalaryNonMonthlyDetail> getChanges(List<EmpSalaryNonMonthlyDetail> _details,
         List<EmpSalaryNonMonthlyDetail> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmpSalaryNonMonthlyDetail> editedItems = (IEnumerable<EmpSalaryNonMonthlyDetail>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmpSalaryNonMonthlyDetail>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}