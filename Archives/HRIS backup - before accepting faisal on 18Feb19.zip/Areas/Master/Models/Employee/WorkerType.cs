﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class WorkerType : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short WorkerTypeId { get; set; }
        public string WorkerTypeName { get; set; }

        #endregion

        #region constructor
        public WorkerType()
        {
        }

        public WorkerType(short _workerTypeId, string _workerTypeName)
        {
            WorkerTypeId = _workerTypeId;
            WorkerTypeName = _workerTypeName;

        }
        #endregion

        #region internal methods
        internal static List<WorkerType> Get()
        {
            List<WorkerType> lstWorkerType = new List<WorkerType>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getWorkerTypes"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstWorkerType.Add(new WorkerType(
                             Convert.ToInt16(dr["WorkerTypeId"]),
                                dr["WorkerTypeName"].ToString()));
                        }
                    }
                }
            }
            return lstWorkerType;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}