﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpCostAllocation : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        public short? TemplateId { get; set; }
        public string BranchCode { get; set; }
        public double Rate { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        //public string Status { get; set; }
        #endregion

        #region constructor
        public EmpCostAllocation()
        {
            DetailId = 1;
            Add = true; Edit = false; Delete = false;
            //Status = "Added";
        }
        public EmpCostAllocation(int _detailId, short _templateId, string _branchCode, double _rate)//,string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            TemplateId = _templateId;
            BranchCode = _branchCode;
            Rate = _rate;
            //Status = _itemState;
            Add = false; Edit = false; Delete = false;
        }
        #endregion

        #region internal methods
        internal static List<EmpCostAllocation> Get(short _empId)
        {
            try
            {
                List<EmpCostAllocation> lstECA = new List<EmpCostAllocation>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeCostAllocationById"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstECA.Add(new EmpCostAllocation(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["TemplateId"]),
                                    dr["BranchCode"].ToString(),
                                    Convert.ToDouble(dr["Rate"])));
                            }
                        }
                    }
                }
                return lstECA;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpCostAllocation> _details, string _userId, DbTransaction _transaction)//, List<EmpCostAllocation> _originalDetails
        {
            try
            {
                foreach (EmpCostAllocation _eca in getChanges(_details))//, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeCostAllocation"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, _eca.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _eca.BranchCode);
                        db.AddInParameter(dbCommand, "TemplateId", SqlDbType.TinyInt, _eca.TemplateId);
                        db.AddInParameter(dbCommand, "Rate", SqlDbType.Float, _eca.Rate);
                        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "Action", SqlDbType.Char, (
                            _eca.Add ? "I" : (_eca.Delete ? "D" : "U")));
                        //db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                        //    _eca.Status == "Added" ? "I" : (
                        //    _eca.Status == "Deleted" ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpCostAllocation> getChanges(List<EmpCostAllocation> _details)//,List<EmpCostAllocation> _originalDetails)
        {
            return (_details.Where(x => x.Add || x.Edit || x.Delete));
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            //_originalDetails.ForEach(o => o.Status = "Deleted");

            ////extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            ////items that were part of initial list but not present in current list
            //IEnumerable<EmpCostAllocation> editedItems = (IEnumerable<EmpCostAllocation>)
            //        (from actualItem in _details
            //         where (actualItem.Status == "Edited" ||
            //         actualItem.Status == "Added")
            //         select actualItem).Union(
            //            from actualItem in _originalDetails
            //            where !
            //            (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
            //            select actualItem);
            //return editedItems.ToList<EmpCostAllocation>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}