﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Relation : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short RelationId { get; set; }
        public string RelationName { get; set; }

        #endregion

        #region constructor
        public Relation()
        {
        }

        public Relation(short _RelationId, string _RelationName)
        {
            RelationId = _RelationId;
            RelationName = _RelationName;

        }
        #endregion

        #region internal methods
        internal static List<Relation> Get()
        {
            return getRelations();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getRelations());
        }
        #endregion

        #region private methods
        private static List<Relation> getRelations()
        {
            List<Relation> lstRelation = new List<Relation>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getRelationList"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstRelation.Add(new Relation(
                             Convert.ToInt16(dr["RelationId"]),
                                dr["RelationName"].ToString()));
                        }
                    }
                }
            }
            return lstRelation;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}