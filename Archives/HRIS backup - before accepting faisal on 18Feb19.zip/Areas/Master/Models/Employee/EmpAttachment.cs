﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpAttachment : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Id")]
        public short? EmployeeId { get; set; }
        [Display(Name = "Attachment Type")]
        public short? AttachmentTypeId { get; set; }
        [Display(Name = "Expiry Date")]
        public DateTime? ExpiryDate { get; set; }
        public string AttachmentName { get; set; }
        public string AttachmentContentType { get; set; }
        public byte[] AttachmentContent { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }
        public bool IsNew { get; set; }
        public bool IsDeleted { get; set; }
        public int fileLenght { get; set; }
        #endregion

        #region constructor
        public EmpAttachment()
        {
            DetailId = 1;
            Status = "Added";
            IsNew = false;
            IsDeleted = false;
        }
        public EmpAttachment(int _DetailId, short _EmpAttachmentTypeId, DateTime _DExpiryDate,
            string _EmpAttachmentName, string _EmpAttachmentContentType, byte[] _EmpAttachmentContent,
            string _itemState = "UnChanged")
        {

            DetailId = _DetailId;
            AttachmentTypeId = _EmpAttachmentTypeId;
            ExpiryDate = _DExpiryDate;
            AttachmentName = _EmpAttachmentName;
            AttachmentContentType = _EmpAttachmentContentType;
            AttachmentContent = _EmpAttachmentContent;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<EmpAttachment> Get(short _empId)
        {
            try
            {
                List<EmpAttachment> lstEDD = new List<EmpAttachment>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetEmployeeAttachmentsById"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstEDD.Add(new EmpAttachment(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["AttachmentTypeId"]),
                                    Convert.ToDateTime(dr["ExpiryDate"]),
                                    dr["FileName"].ToString(),
                                    dr["FileContentType"].ToString(),
                                    (byte[])(dr["FileContent"])));
                            }
                        }
                    }
                }
                return lstEDD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpAttachment> _details,
             string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpAttachment edd in _details)
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeEmpAttachmentDetail"))
                    {
                        dbCommand.Transaction = _transaction;

                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "EmpAttachmentTypeId", SqlDbType.SmallInt, edd.AttachmentTypeId);
                        db.AddInParameter(dbCommand, "ExpiryDate", SqlDbType.DateTime, edd.ExpiryDate);
                        db.AddInParameter(dbCommand, "FileName", SqlDbType.VarChar, edd.AttachmentName);
                        db.AddInParameter(dbCommand, "FileContentType", SqlDbType.VarChar, edd.AttachmentContentType);
                        db.AddInParameter(dbCommand, "FileContent", SqlDbType.VarBinary, edd.AttachmentContent);
                        db.AddInParameter(dbCommand, "IsNew", SqlDbType.Bit, edd.IsNew);
                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpAttachment> getChanges(List<EmpAttachment> _details,
         List<EmpAttachment> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmpAttachment> editedItems = (IEnumerable<EmpAttachment>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmpAttachment>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}