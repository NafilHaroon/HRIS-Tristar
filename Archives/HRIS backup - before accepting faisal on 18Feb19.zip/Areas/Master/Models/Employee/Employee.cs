﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Employee : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Id")]
        public short? EmployeeId { get; set; }
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }
        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }
        [Display(Name = "Worker Type")]
        public short? WorkerTypeId { get; set; }
        [Display(Name = "Head Name")]
        public string HeadName { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Supervisor")]
        public short? SupervisorId { get; set; }
        [Display(Name = "Branch")]
        public string BranchCode { get; set; }
        [Display(Name = "Department")]
        public string DepartmentCode { get; set; }
        [Display(Name = "Grade")]
        public short? GradeId { get; set; }
        [Display(Name = "Designation")]
        public string Designation { get; set; }
        [Display(Name = "Hiring Type")]
        public short? HiringTypeId { get; set; }
        [Display(Name = "Replacement Employee")]
        public short? ReplacementEmployeeId { get; set; }
        [Display(Name = "Job Nature")]
        public short? JobNatureId { get; set; }
        [Display(Name = "Joining Date")]
        public DateTime? JoiningDate { get; set; }
        [Display(Name = "Confirmation Due Date")]
        public DateTime? ConfirmationDueDate { get; set; }
        [Display(Name = "Confirmation Date")]
        public DateTime? ConfirmationDate { get; set; }
        [Display(Name = "Seperation Date")]
        public DateTime? SeparationDate { get; set; }    
        [Display(Name = "Employee Status")]
        public short? StatusId { get; set; }
        public string ReasonForSeperation { get; set; }
        public string ValidationError { get; set; }
        public bool IsConfirmed { get; set; }
        public short? MedicalPlanId { get; set; }
        public double MedicalCost { get; set; }
        [Display(Name = "Life Insurance")]
        public double LifeInsuranceCost { get; set; }
        //[Display(Name = "Supervisor")]
        //public short? NewSupervisorId { get; set; }
        public EmpPersonalInfo EmpPersonalInfo { get; set; }
        public List<EmpSalary> Salary { get; set; }
        public List<EmpCostAllocation> CostAllocations { get; set; }
        public List<EmpFamily> Family { get; set; }
        public List<EmpAsset> Assets { get; set; }
        public List<EmpAttachment> Attachments { get; set; }
        public byte[] ProfileImage { get; set; }
        //public string image { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region constructor
        public Employee()
        {
            AuditTrail = new Footer();
            JoiningDate = DateTime.Now;
            StatusId = 1;
            HiringTypeId = 1;
            ConfirmationDueDate = DateTime.Now.AddMonths(3);
            EmpPersonalInfo = new EmpPersonalInfo();
            Salary = new List<EmpSalary>();
            CostAllocations = new List<EmpCostAllocation>();
            Family = new List<EmpFamily>();
            Assets = new List<EmpAsset>();
            Attachments = new List<EmpAttachment>();
            ProfileImage = null;
        }
        #endregion

        #region internal methods
        internal static Employee Get(string _empCode)
        {
            try
            {
                using (DbCommand dbCommandDetail = db.GetStoredProcCommand("getEmployeeByCode"))
                {
                    db.AddInParameter(dbCommandDetail, "EmployeeCode", SqlDbType.VarChar, _empCode);
                    using (DataSet ds = db.ExecuteDataSet(dbCommandDetail))
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            using (Employee _emp = new Employee())
                            {
                                DataRow dr = ds.Tables[0].Rows[0];
                                _emp.EmployeeCode = _empCode;
                                _emp.EmployeeId = Convert.ToInt16(dr["EmployeeId"]);
                                _emp.WorkerTypeId = Convert.ToInt16(dr["WorkerTypeId"]);
                                _emp.EmployeeName = dr["EmployeeName"].ToString();
                                _emp.HeadName = dr["HeadName"].ToString();
                                _emp.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                                _emp.SupervisorId = Convert.ToInt16(dr["SupervisorId"]);
                                _emp.BranchCode = dr["BranchCode"].ToString();
                                _emp.DepartmentCode = dr["DepartmentCode"].ToString();
                                _emp.GradeId = Convert.ToInt16(dr["GradeId"]);
                                _emp.Designation = dr["Designation"].ToString();
                                _emp.HiringTypeId = Convert.ToInt16(dr["HiringTypeId"]);

                                if (_emp.HiringTypeId == 2 && dr["ReplacementEmployeeId"] != DBNull.Value)
                                    _emp.ReplacementEmployeeId = Convert.ToInt16(dr["ReplacementEmployeeId"]);

                                _emp.JobNatureId = Convert.ToInt16(dr["JobNatureId"]);
                                _emp.JoiningDate = Convert.ToDateTime(dr["JoiningDate"]);

                                if (dr["ConfirmationDueDate"] != DBNull.Value)
                                    _emp.ConfirmationDueDate = Convert.ToDateTime(dr["ConfirmationDueDate"]);

                                if (dr["ConfirmationDate"] != DBNull.Value)
                                {
                                    _emp.IsConfirmed = true;
                                    _emp.ConfirmationDate = Convert.ToDateTime(dr["ConfirmationDate"]);
                                }
                                else
                                    _emp.IsConfirmed = false;

                                _emp.StatusId = Convert.ToInt16(dr["StatusId"]);
                                if (_emp.StatusId != 1)
                                {
                                    _emp.SeparationDate = Convert.ToDateTime(dr["SeparationDate"]);
                                    _emp.ReasonForSeperation = dr["ReasonForSeparation"].ToString();
                                }

                                if (dr["MedicalPlanId"] != DBNull.Value)
                                {
                                    _emp.MedicalPlanId = Convert.ToInt16(dr["MedicalPlanId"]);
                                    _emp.MedicalCost = Convert.ToDouble(dr["MedicalCost"]);
                                }
                                _emp.LifeInsuranceCost = Convert.ToDouble(dr["LifeInsuranceCost"]);
                                
                                _emp.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                                _emp.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                                _emp.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                                if (dr["UpdatedOn"] != DBNull.Value)
                                    _emp.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);

                                _emp.EmpPersonalInfo = EmpPersonalInfo.Get(_emp.EmployeeId.Value);
                                _emp.Salary = EmpSalary.Get(_emp.EmployeeId.Value);
                                _emp.CostAllocations = EmpCostAllocation.Get(_emp.EmployeeId.Value);
                                _emp.Family = EmpFamily.Get(_emp.EmployeeId.Value); 
                                _emp.Assets = EmpAsset.Get(_emp.EmployeeId.Value); 
                                _emp.Attachments = EmpAttachment.Get(_emp.EmployeeId.Value);
                                return _emp;
                            }
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(Employee _emp, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployee"))
            {
                db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _emp.EmployeeId);
                db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _emp.EmployeeCode);
                db.AddInParameter(dbCommand, "EmployeeName", SqlDbType.VarChar, _emp.EmployeeName);
                db.AddInParameter(dbCommand, "HeadName", SqlDbType.VarChar, _emp.HeadName);
                db.AddInParameter(dbCommand, "WorkerTypeId", SqlDbType.SmallInt, _emp.WorkerTypeId);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _emp.CompanyId);
                db.AddInParameter(dbCommand, "SupervisorId", SqlDbType.SmallInt, _emp.SupervisorId);
                db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _emp.BranchCode);
                db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, _emp.DepartmentCode);
                db.AddInParameter(dbCommand, "GradeId", SqlDbType.VarChar, _emp.GradeId);
                db.AddInParameter(dbCommand, "Designation", SqlDbType.VarChar, _emp.Designation);
                db.AddInParameter(dbCommand, "HiringTypeId", SqlDbType.SmallInt, _emp.HiringTypeId);
                db.AddInParameter(dbCommand, "ReplacementEmployeeId", SqlDbType.SmallInt, _emp.ReplacementEmployeeId);
                db.AddInParameter(dbCommand, "JobNatureId", SqlDbType.SmallInt, _emp.JobNatureId);
                db.AddInParameter(dbCommand, "JoiningDate", SqlDbType.DateTime, _emp.JoiningDate);
                db.AddInParameter(dbCommand, "ConfirmationDueDate", SqlDbType.DateTime, _emp.ConfirmationDueDate);
                db.AddInParameter(dbCommand, "ConfirmationDate", SqlDbType.DateTime, _emp.ConfirmationDate);
                db.AddInParameter(dbCommand, "SeparationDate", SqlDbType.DateTime, _emp.SeparationDate);
                db.AddInParameter(dbCommand, "ReasonForSeperation", SqlDbType.DateTime, _emp.ReasonForSeperation);
                db.AddInParameter(dbCommand, "StatusCode", SqlDbType.SmallInt, _emp.StatusId);
                db.AddInParameter(dbCommand, "MedicalPlanId", SqlDbType.SmallInt, _emp.MedicalPlanId);
                db.AddInParameter(dbCommand, "MedicalCost", SqlDbType.Float, _emp.MedicalCost);
                db.AddInParameter(dbCommand, "LifeInsuranceCost", SqlDbType.Float, _emp.LifeInsuranceCost);
                db.AddInParameter(dbCommand, "ProfileImage", SqlDbType.VarBinary, _emp.ProfileImage);

                db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                db.AddOutParameter(dbCommand, "newEmployeeCode", SqlDbType.VarChar, 32);
                db.AddOutParameter(dbCommand, "newEmployeeId", SqlDbType.SmallInt, 32);
                db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _emp.AuditTrail.UpdatedOn);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        _emp.EmployeeCode = dbCommand.Parameters["@newEmployeeCode"].Value.ToString();
                        _emp.EmployeeId = Convert.ToInt16(dbCommand.Parameters["@newEmployeeId"].Value);

                        EmpPersonalInfo.Save(_emp.EmployeeId.Value, _emp.EmpPersonalInfo, _userId, transaction);
                        //EmpLeaveType.Save(_emp.EmployeeId.Value, _emp.LeaveEntitlement, _userId, transaction);//, _emp.donotUseLeaveEntitlement
                        EmpFamily.Save(_emp.EmployeeId.Value, _emp.Family, _userId, transaction);//_emp.donotUseFamily, 
                        //_legacyEmpEmergencyContact.Save(_emp.EmployeeId.Value, _emp.EmergencyContacts, _emp.donotUseEmergencyContacts, _userId, transaction);
                        EmpAsset.Save(_emp.EmployeeId.Value, _emp.Assets, _userId, transaction);//, _emp.donotUseAssets
                        EmpSalary.Save(_emp.EmployeeId.Value, _emp.Salary, _userId, transaction);//_emp.donotUseSalary, 
                        EmpCostAllocation.Save(_emp.EmployeeId.Value, _emp.CostAllocations, _userId, transaction);//, _emp.donotUseCostAllocations

                        if (_emp.Attachments.Count > 0)
                            EmpAttachment.Save(_emp.EmployeeId.Value, _emp.Attachments, _userId, transaction);

                        //_emp.LeaveEntitlement.ForEach(o => o.Status = "UnChanged");
                        //_emp.donotUseLeaveEntitlement = _emp.LeaveEntitlement.Clone();

                        //_emp.Family.ForEach(o => o.Status = "UnChanged");
                        //_emp.donotUseFamily = _emp.Family.Clone();

                        //_emp.EmergencyContacts.ForEach(o => o.Status =  "UnChanged");
                        //_emp.donotUseEmergencyContacts = _emp.EmergencyContacts.Clone();

                        //_emp.Assets.ForEach(o => o.Status = "UnChanged");
                        //_emp.donotUseAssets = _emp.Assets.Clone();

                        //_emp.Salary.ForEach(o => o.Status = "UnChanged");
                        //_emp.donotUseSalary = _emp.Salary.Clone();

                        //_emp.CostAllocations.ForEach(o => o.Status = "UnChanged");
                        //_emp.donotUseCostAllocations = _emp.CostAllocations.Clone();

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        //to method to be refactored later
        /// <summary>
        /// not final
        /// </summary>
        /// <param name="_emp"></param>
        /// <param name="_userId"></param>
        /// <returns></returns>
        internal static bool ChangeSupervisor(Employee _emp, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("ChangeSupervisor"))
                {
                    db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _emp.BranchCode);
                    db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, _emp.DepartmentCode);
                    db.AddInParameter(dbCommand, "CurrentSuperVisorId", SqlDbType.SmallInt, _emp.SupervisorId);
                    //db.AddInParameter(dbCommand, "NewSupervisorId", SqlDbType.SmallInt, _emp.SupervisorId);
                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);

                    db.ExecuteNonQuery(dbCommand);

                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Delete(string _empId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("DeleteEmployee"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.VarChar, _empId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
    }
}