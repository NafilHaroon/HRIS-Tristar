﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpAsset : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        public short? AssetTypeId { get; set; }
        public string RegistrationNo { get; set; }
        public string Model { get; set; }
        public DateTime? IssueDate { get; set; }
        public double BaseValue { get; set; }
        public double Limit { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public DateTime? ReminderDate { get; set; }
        public DateTime? DisposalDate { get; set; }
        public bool Consumable { get; set; }
        public bool Active { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        //public string Status { get; set; }
        #endregion

        #region constructor
        public EmpAsset()
        {
            DetailId = -1;
            Add = true; Edit = false; Delete = false;
            //Status = "Added";
        }
        public EmpAsset(int _detailId, short _assetId, string _registrationNo, string _model,
            DateTime _issueDate, double _baseValue, double _limit, DateTime _expiryDate,
            DateTime _reminderDate, DateTime _disposalDate, bool _consumable, bool _active)//,string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            AssetTypeId = _assetId;
            RegistrationNo = _registrationNo;
            Model = _model;
            IssueDate = _issueDate;
            BaseValue = _baseValue;
            Limit = _limit;
            Consumable = _consumable;
            Active = _active;
            ExpiryDate = _expiryDate;
            ReminderDate = _reminderDate;
            DisposalDate = _disposalDate;
            Add = false; Edit = false; Delete = false;
            //Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<EmpAsset> Get(short _empId)
        {
            try
            {
                List<EmpAsset> lstEA = new List<EmpAsset>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeAssetsById"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstEA.Add(new EmpAsset(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["AssetId"]),
                                    dr["RegistrationNo"].ToString(),
                                    dr["Model"].ToString(),
                                    Convert.ToDateTime(dr["IssueDate"]),
                                    Convert.ToDouble(dr["BaseValue"]),
                                    Convert.ToDouble(dr["Limit"]),
                                    Convert.ToDateTime(dr["ExpiryDate"]),
                                    Convert.ToDateTime(dr["ReminderDate"]),
                                    Convert.ToDateTime(dr["DisposalDate"]),
                                    Convert.ToBoolean(dr["Consumable"]),
                                    Convert.ToBoolean(dr["Active"])));
                            }
                        }
                    }
                }
                return lstEA;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpAsset> _details, //List<EmpAsset> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpAsset _ea in getChanges(_details))//, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeAsset"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, _ea.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "EmpAssetId", SqlDbType.TinyInt, _ea.AssetTypeId);
                        db.AddInParameter(dbCommand, "RegistrationNo", SqlDbType.VarChar, _ea.RegistrationNo);
                        db.AddInParameter(dbCommand, "IssueDate", SqlDbType.SmallDateTime, _ea.IssueDate);
                        db.AddInParameter(dbCommand, "Model", SqlDbType.VarChar, _ea.Model);
                        db.AddInParameter(dbCommand, "BaseValue", SqlDbType.Float, _ea.BaseValue);
                        db.AddInParameter(dbCommand, "Limit", SqlDbType.Float, _ea.Limit);
                        db.AddInParameter(dbCommand, "ExpiryDate", SqlDbType.SmallDateTime, _ea.ExpiryDate);
                        db.AddInParameter(dbCommand, "ReminderDate", SqlDbType.SmallDateTime, _ea.ReminderDate);
                        db.AddInParameter(dbCommand, "DisposalDate", SqlDbType.SmallDateTime, _ea.DisposalDate);
                        db.AddInParameter(dbCommand, "Active", SqlDbType.Bit, _ea.Active);
                        db.AddInParameter(dbCommand, "Consumable", SqlDbType.Bit, _ea.Consumable);
                        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "Action", SqlDbType.Char, (
                            _ea.Delete ? "D" : (_ea.Add ? "I" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpAsset> getChanges(List<EmpAsset> _details)//,List<EmpAsset> _originalDetails)
        {
            return (_details.Where(x => (x.Add && !x.Delete) || (x.Edit && !x.Delete) || x.Delete));
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
    }
}