﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class BankList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Bank Id")]
        public short BankId { get; set; }
        [DataMember(Order = 1)]
        [Display(Name = "Bank Name")]
        public string BankName { get; set; }
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }
        [DataMember(Order = 3)]
        public bool IsActive { get; set; }
        #endregion

        #region constructor
        public BankList()
        {
        }

        public BankList(short _bankId, string _bankName, string _companyName, bool _isActive = true)
        {
            BankId = _bankId;
            BankName = _bankName;
            CompanyName = _companyName;
            IsActive = _isActive;
        }
        #endregion

        #region internal methods
        internal static List<BankList> Get(string _userId, bool _isActive = true)
        {
            return getBanks(_userId, _isActive);
        }

        //internal static string GetJson(string _userId, bool _isActive = true)
        //{
        //    return JsonConvert.SerializeObject(getBanks(_userId, _isActive));
        //}
        #endregion

        #region private methods
        private static List<BankList> getBanks(string _userId, bool _isActive)
        {
            List<BankList> lstBank = new List<BankList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getBanks"))
            {
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _isActive);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstBank.Add(new BankList(
                              Convert.ToInt16(dr["BankId"]),
                                dr["BankName"].ToString(),
                                dr["CompanyName"].ToString(),
                                 Convert.ToBoolean(dr["IsActive"])));
                        }
                    }
                }
            }
            return lstBank;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}