﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class BranchList : IDisposable
    {
                #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         public string BranchCode { get; set; }
         public string BranchName { get; set; }
         
        #endregion

        #region constructor
        public BranchList()
        {
        }

        public BranchList(string _BranchCode, string _BranchName)
        {           
                BranchCode = _BranchCode;
                BranchName = _BranchName;
           
        }
        #endregion


        #region internal methods
        internal static List<BranchList> Get(string _userid, bool _activeOnly)
        {
            return getBranches(_userid, _activeOnly);
        }

        //internal static string GetJson(string _userId, bool _activeOnly)
        //{
        //    return JsonConvert.SerializeObject(getBranches(_userId, _activeOnly));
        //}
        //internal static DataTable GetDT(bool _activeOnly, string _userid)
        //{
        //    return AgilityHelper.ListToDataTable(getBranches(_activeOnly, _userid));
        //}
        #endregion

        #region private methods
        private static List<BranchList> getBranches(string _userId, bool _activeOnly)
        {
            List<BranchList> lstBranch = new List<BranchList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getBranches"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _activeOnly);
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstBranch.Add(new BranchList(
                                dr["BranchCode"].ToString(),
                                dr["BranchName"].ToString()));
                        }
                    }
                }
            }
            return lstBranch;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}