﻿using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class MonthlyCalendar : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Year")]
        public int Year { get; set; }
        [Display(Name = "Month")]
        public short MonthNumber { get; set; }
        public List<MonthlyCalendarDetail> Details { get; set; }
        public List<MonthlyCalendarDetail> donotUseDetails { get; set; }
        #endregion

        #region constructor
        public MonthlyCalendar()
        {
            Details = new List<MonthlyCalendarDetail>();
            donotUseDetails = new List<MonthlyCalendarDetail>();
        }

        public MonthlyCalendar(short _MonthNumber, int _Year)
        {
            MonthNumber = _MonthNumber;
            Year = _Year;
            Details = new List<MonthlyCalendarDetail>();
            donotUseDetails = new List<MonthlyCalendarDetail>();
        }
        #endregion

        #region internal methods
        internal static MonthlyCalendar Get(short _month, int _year)
        {
            try
            {
                using (MonthlyCalendar _mc = new MonthlyCalendar())
                {
                    _mc.MonthNumber = _month;
                    _mc.Year = _year;
                    _mc.donotUseDetails = MonthlyCalendarDetail.getDetailbyId(_month, _year);
                    _mc.Details = _mc.donotUseDetails.Clone();
                    return _mc;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(MonthlyCalendar _mc)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    MonthlyCalendarDetail.Save( _mc.Details, _mc.donotUseDetails, transaction);
                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}