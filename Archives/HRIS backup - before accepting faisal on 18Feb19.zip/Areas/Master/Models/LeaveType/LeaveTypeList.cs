﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class LeaveTypeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Name = "Leave Type Id")]
        public short LeaveTypeId { get; set; }
        [DataMember(Name = "Leave Type Name")]
        public string LeaveTypeName { get; set; }
        [DataMember(Name ="Is Active?")]
        public bool IsActive { get; set; }
        #endregion

        #region constructor
        public LeaveTypeList()
        {
        }

        public LeaveTypeList(short _leaveTypeId, string _leaveTypeName, bool _isActive = true)
        {
            LeaveTypeId = _leaveTypeId;
            LeaveTypeName = _leaveTypeName;
            IsActive = _isActive;
        }
        #endregion

        #region internal methods
        internal static List<LeaveTypeList> Get(bool _isActive)
        {
            List<LeaveTypeList> lstLeave = new List<LeaveTypeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetLeaveTypes"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _isActive);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstLeave.Add(new LeaveTypeList(
                               Convert.ToInt16(dr["LeaveTypeId"]),
                                dr["LeaveTypeDesc"].ToString(),
                                 Convert.ToBoolean(dr["IsActive"])));
                        }
                    }
                }
            }
            return lstLeave;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}