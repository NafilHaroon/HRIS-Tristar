﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class LeaveType : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Leave Type Id")]
        public short? LeaveTypeId { get; set; }
        [Display(Name = "Leave Type Name")]
        public string LeaveTypeName { get; set; }
        [Display(Name = "Default Days")]
        public short DefaultDays { get; set; }
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public LeaveType()
        {
            AuditTrail = new Footer();
            IsActive = true;
        }
        #endregion

        #region internal methods
        internal static LeaveType Get(short _leaveId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetLeaveTypeById"))
            {
                db.AddInParameter(dbCommand, "LeaveId", SqlDbType.SmallInt, _leaveId);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (LeaveType _lv = new LeaveType())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _lv.LeaveTypeId = Convert.ToInt16(dr["LeaveTypeId"]);
                            _lv.LeaveTypeName = dr["LeaveTypeName"].ToString();
                            _lv.DefaultDays = Convert.ToInt16(dr["DefaultDays"]);
                            _lv.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _lv.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _lv.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _lv.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _lv.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);

                            return _lv;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(LeaveType _lv, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveLeaveType"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "LeaveTypeId", SqlDbType.TinyInt, _lv.LeaveTypeId);
                    db.AddInParameter(dbCommand, "LeaveTypeName", SqlDbType.VarChar, _lv.LeaveTypeName);
                    db.AddInParameter(dbCommand, "DefaultDays", SqlDbType.TinyInt, _lv.DefaultDays);
                    db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _lv.IsActive);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _lv.AuditTrail.UpdatedOn);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
