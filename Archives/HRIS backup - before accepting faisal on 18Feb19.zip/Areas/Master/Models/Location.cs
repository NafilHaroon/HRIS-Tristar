﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Location : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public string LocationCode { get; set; }
        public string LocationName { get; set; }

        #endregion

        #region constructor
        public Location()
        {
        }

        public Location(string _LocationCode, string _LocationName)
        {
            LocationCode = _LocationCode;
            LocationName = _LocationName;

        }
        #endregion

        #region internal methods
        internal static List<Location> GetLocations()
        {
            List<Location> lstLocation = new List<Location>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getLocationList"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstLocation.Add(new Location(
                                dr["LocationCode"].ToString(),
                                dr["LocationName"].ToString()));
                        }
                    }
                }
            }
            return lstLocation;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}