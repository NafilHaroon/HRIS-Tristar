﻿baseURL = "/HRIS/Master/Branch/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#numSSRate').focus();
    });
});

app.controller('BranchController', function ($scope, $rootScope, $http, $uibModal) { 
    //#region toolbar actions
    $scope.tbRecall = function () {
        setFormControls("Recall");
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Branch";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getBranchByCode($rootScope.SelectedRow.BranchCode);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function (res) {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.Branch
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();
            }
            setFormControls(result.data.Session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion
    
    //#region form functions
    $scope.getBranchByCode = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.Branch = result.data.branch;
                $scope.footer = $scope.Branch.AuditTrail;
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.Branch = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.Branch.AuditTrail != null) {
            $scope.Branch.AuditTrail.CreatedOn = formatDateTime($scope.Branch.AuditTrail.CreatedOn);
            if ($scope.Branch.AuditTrail.UpdatedOn != null) {
                $scope.Branch.AuditTrail.UpdatedOn = formatDateTime($scope.Branch.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion
});