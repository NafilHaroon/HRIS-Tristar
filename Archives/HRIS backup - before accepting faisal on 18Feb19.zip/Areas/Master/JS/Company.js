﻿baseURL = "/HRIS/Master/Company/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        //document.getElementById('ddPFReceivable').disabled = true;
        $('#txtCompanyName').focus();
    });
});

app.controller('CompanyController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstPFAccount = result.data.lstPFAccount;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.Company = response.data.Company;
            $scope.Footer = response.data.Company.AuditTrail;
            setFormControls(response.data.session);
            maskDates();
            $('#txtCompanyName').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtCompanyId').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Company";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getCompanyById($rootScope.SelectedRow.CompanyId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.Company
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getCompanyById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.Company = result.data.Company;
                $scope.footer = $scope.Company.AuditTrail;
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.Company = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.Company.AuditTrail != null)
            $scope.Company.AuditTrail.CreatedOn = formatDateTime($scope.Company.AuditTrail.CreatedOn);
        if ($scope.Company.AuditTrail.UpdatedOn != null)
            $scope.Company.AuditTrail.UpdatedOn = formatDateTime($scope.Company.AuditTrail.UpdatedOn);
    }
    //#endregion
});