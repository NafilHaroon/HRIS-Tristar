﻿baseURL = "/HRIS/Master/AttachmentType/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#txtAttachmentTypeName').focus();
    });
});

app.controller('AttachmentTypeController', function ($scope, $rootScope, $http, $uibModal) {
    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.AttachmentType = response.data.attachmentType;
            $scope.Footer = response.data.attachmentType.AuditTrail;
            setFormControls(response.data.session);
            maskDates();
            $('#txtAttachmentTypeName').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtAttachmentTypeId').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Attachment Type";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getAttachmentTypeById($rootScope.SelectedRow.AttachmentTypeId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function (res) {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.AttachmentType
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setFormControls("Initialize");
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getAttachmentTypeById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.AttachmentType = result.data.attachmentType;
                $scope.footer = $scope.AttachmentType.AuditTrail;
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.AttachmentType = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.AttachmentType.AuditTrail != null) {
            $scope.AttachmentType.AuditTrail.CreatedOn = formatDateTime($scope.AttachmentType.AuditTrail.CreatedOn);
            if ($scope.AttachmentType.AuditTrail.UpdatedOn != null) {
                $scope.AttachmentType.AuditTrail.UpdatedOn = formatDateTime($scope.AttachmentType.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion   
});