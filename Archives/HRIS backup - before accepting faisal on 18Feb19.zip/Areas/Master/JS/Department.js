﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});

var app = angular.module('HRIS', []);

app.controller('DepartmentController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtDId').value;
        if (id > 0)
            $scope.GetData(id);

    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/Department/Save",
            data: $scope.Department
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Department = result.data;
               
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                $scope.Department = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/Department/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.Department = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.Department = result.data; 
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/Department/Undo"
        }).success(function (result) {
            $scope.Department = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/Department/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/Department/Add"
        }).success(function (result) {
            $scope.Department = {};
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/Department/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    function ConvertDate() {

        $scope.Department.AuditTrail.CreatedOn = formattingDateTime($scope.Department.AuditTrail.CreatedOn);
        if ($scope.Department.AuditTrail.UpdatedOn != null) {
            $scope.Department.AuditTrail.UpdatedOn = formattingDateTime($scope.Department.AuditTrail.UpdatedOn);
        }
    }

   
});