﻿baseURL = "/HRIS/Master/Grade/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#txtGradeName').focus();
    });
});

app.controller('GradeController', function ($scope, $rootScope, $http, $uibModal) {


    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.Grade = response.data.Grade;
            $scope.Footer = response.data.Grade.AuditTrail;
            setFormControls(response.data.session);
            maskDates();
            $('#txtGradeName').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtGradeId').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Grade";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getGradeById($rootScope.SelectedRow.GradeId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.Grade
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getGradeById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.Grade = result.data.Grade;
                $scope.footer = $scope.Grade.AuditTrail;
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.Grade = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.Grade.AuditTrail != null) {
            $scope.Grade.AuditTrail.CreatedOn = formatDateTime($scope.Grade.AuditTrail.CreatedOn);
            if ($scope.Grade.AuditTrail.UpdatedOn != null) {
                $scope.Grade.AuditTrail.UpdatedOn = formatDateTime($scope.Grade.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion
});