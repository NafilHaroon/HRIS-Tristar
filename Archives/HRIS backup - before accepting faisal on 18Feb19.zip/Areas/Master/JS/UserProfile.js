﻿baseURL = "/HRIS/Master/UserProfile/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#tblOption').focus();
    });
});

app.controller('UserProfileController', function ($scope, $rootScope, $http, $uibModal) {
    //#region toolbar actions
    $scope.tbRecall = function () {
        setFormControls("Recall");
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select User Profile";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getUserProfileById($rootScope.SelectedRow.UserId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function (res) {
        $scope.UserProfile.Options = getUseroptionDataFromGrid();
        $scope.UserProfile.Branches = getUserBranchDataFromGrid();
        $scope.UserProfile.Companies = getUserCompanyDataFromGrid();
        $scope.UserProfile.Grades = getUserGradeDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.UserProfile
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                setGridData();
                clearForm();
            }
            setFormControls(result.data.Session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setGridData();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getUserProfileById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.UserProfile = result.data.UserProfile;
                $scope.footer = $scope.UserProfile.AuditTrail;
                setGridData();
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.UserProfile = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.UserProfile.AuditTrail != null) {
            $scope.UserProfile.AuditTrail.CreatedOn = formatDateTime($scope.UserProfile.AuditTrail.CreatedOn);
            if ($scope.UserProfile.AuditTrail.UpdatedOn != null) {
                $scope.UserProfile.AuditTrail.UpdatedOn = formatDateTime($scope.UserProfile.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion

    //#region grid setup
    //#region User Option Grid Definition & functions
    var colUserOption = [
        {
            headerName: 'Access',
            width: 90,
            editable: false,
            cellRenderer: params => {
                return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
            },
            field: 'AllowAccess'  
        },
        {
            headerName: "Option Name", field: "OptionName", editable: false, width: 240
        },
        {
            headerName: 'Add',
            width: 60,
            editable: false,
            cellRenderer: params => {
                return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
            },
            field: 'AllowAdd'  
        },
        {
            headerName: 'Edit',
            width: 60,
            editable: false,
            cellRenderer: params => {
                return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
            },
            field: 'AllowEdit'       
        },
    ];


    $scope.grdOptOption = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        //defaultColDef: {
        //    editable: allowEdit.bind(this)
        //},
        columnDefs: colUserOption,
        rowData: [],
        rowSelection: 'multiple',
        enableSorting: true,
        suppressRowClickSelection: true,
        
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = false;
            //if (params.colDef.field == "Amount")
            //   setSalaryFooter();
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>'
        
    };

    function getUseroptionDataFromGrid() {
        let rowData = [];
        $scope.grdOptOption.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }
    function getUserBranchDataFromGrid() {
        let rowData = [];
        $scope.grdOptBranch.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    //#endregion       

    //#region User Branch Grid Definition & functions
    var colUserBranch = [
        {
            headerName: 'S',
            width: 80,
            editable: false,
            cellRenderer: params => {
                return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
            },
            field: 'Selected'          
        },
        {
            headerName: "Branch Name", field: "BranchName", editable: false, width: 300
        },
    ];
    
    $scope.grdOptBranch = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        //defaultColDef: {
        //    editable: allowEdit.bind(this)
        //},
        columnDefs: colUserBranch,
        rowData: [],
        rowSelection: 'multiple',
        enableSorting: true,
        suppressRowClickSelection: true,
        
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = false;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>'
        
    };

    function getUserBranchDataFromGrid() {
        let rowData = [];
        $scope.grdOptBranch.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    //#endregion       

    //#region User Company Grid Definition & functions
    var colUserCompany = [
        {
            headerName: 'S',
            width: 80,
            editable: false,
            cellRenderer: params => {
                return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
            },
            field: 'Selected'          
        },
        {
            headerName: "Company Name", field: "CompanyName", editable: false, width: 300
        },
    ];

    $scope.grdOptCompany = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        //defaultColDef: {
        //    editable: allowEdit.bind(this)
        //},
        columnDefs: colUserCompany,
        rowData: [],
        rowSelection: 'multiple',   
        enableSorting: true,   
        suppressRowClickSelection:true,
        
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = false;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>'
        
    };

    function getUserCompanyDataFromGrid() {
        let rowData = [];
        $scope.grdOptCompany.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    //#endregion       

    //#region User Grade Grid Definition & functions
    var colUserGrade = [
        {
            headerName: 'S',
            width: 80,
            editable: false,
            cellRenderer: params => {
                return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
            },
            field: 'Selected'            
        },
        {
            headerName: "Grade Name", field: "GradeName", editable: false, width: 300
        },
    ];

    $scope.grdOptGrade = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        //defaultColDef: {
        //    editable: allowEdit.bind(this)
        //},
        columnDefs: colUserGrade,
        rowData: [],
        rowSelection: 'multiple',
        enableSorting: true,
        suppressRowClickSelection: true,
        
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = false;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        
    };

    function getUserGradeDataFromGrid() {
        let rowData = [];
        $scope.grdOptGrade.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    //#endregion       
    
    //#region general functions
    function setGridData() {
        if ($scope.UserProfile != []) {
            $scope.grdOptOption.api.setRowData($scope.UserProfile.Options);
            $scope.grdOptBranch.api.setRowData($scope.UserProfile.Branches);
            $scope.grdOptCompany.api.setRowData($scope.UserProfile.Companies);
            $scope.grdOptGrade.api.setRowData($scope.UserProfile.Grades);
        }
        else {
            $scope.grdOptOption.api.setRowData([]);
            $scope.grdOptOptBranch.api.setRowData([]);
            $scope.grdCompany.api.setRowData([]);
            $scope.grdOptGrade.api.setRowData([]);}
    }

    $scope.sum = function (items, prop) {
        return items.reduce(function (a, b) {
            return a + b[prop];
        }, 0);
    };
    //#endregion
    //#endregion



});