﻿baseURL = "/HRIS/Master/Config/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);



app.controller('ConfigController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
        getConfig();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstLoan = result.data.lstLoan;
            $scope.lstAbsent = result.data.lstAbsent;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    //#endregion



    //#region toolbar actions
    $scope.tbSave = function (res) {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.Config
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
            }
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };

    function getConfig() {
        $http.get(baseURL + 'Get').then(result => {
            $scope.Config = result.data.Config;
        }, errorMsg => {
            alert(errorMsg);
        });
    }



});