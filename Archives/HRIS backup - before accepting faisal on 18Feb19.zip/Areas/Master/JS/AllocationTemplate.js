﻿baseURL = "/HRIS/Master/AllocationTemplate/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#txtTemplateDesc').focus();
    });
});

app.controller('AllocationTemplateController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstDepartment = result.data.lstDepartment;
        }, errorMsg => {
            alert(errorMsg);
            });
    }
    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {      
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.AllocationTemplate = response.data.AllocationTemplate;
            $scope.Footer = response.data.AllocationTemplate.AuditTrail;
            setFormControls(response.data.session);
            maskDates();
            $('#txtTemplateDesc').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtTemplateId').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Allocation Template";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getAllocationTemplateById($rootScope.SelectedRow.TemplateId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $scope.AllocationTemplate.Details = getDepartmentDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.AllocationTemplate
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);               
                clearForm();
                setGridData();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setGridData();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getAllocationTemplateById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.AllocationTemplate = result.data.AllocationTemplate;
                $scope.footer = $scope.AllocationTemplate.AuditTrail;
                setGridData();
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.AllocationTemplate = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.AllocationTemplate.AuditTrail != null) {
            $scope.AllocationTemplate.AuditTrail.CreatedOn = formatDateTime($scope.AllocationTemplate.AuditTrail.CreatedOn);
            if ($scope.AllocationTemplate.AuditTrail.UpdatedOn != null) {
                $scope.AllocationTemplate.AuditTrail.UpdatedOn = formatDateTime($scope.AllocationTemplate.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion

    //#region grid setup
    //#region Template Grid Definition & functions
    var colDepartment = [
        {
            headerName: "Department", field: "DepartmentCode", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'Depart', class: "agGridSelect130" },
            valueFormatter: getDepartmentName, width: 130
        },
        {
            headerName: "Rate (%)", field: "Rate", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 100
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true },
    ];

    $scope.grdOptDepartment = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colDepartment,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        onGridReady: (grid) => {
            setDepartmentFooter();
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
            if (params.colDef.field == "Rate")
                setDepartmentFooter();
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect()
        }
    };

    function getDepartmentDataFromGrid() {
        let rowData = [];
        $scope.grdOptDepartment.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddDepartment = function () {
        try {
            var res = $scope.grdOptDepartment.api.updateRowData({
                add: [{
                    DepartmentCode: null, Rate: 0, Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptDepartment.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "DepartmentCode" });
        }
        catch (exception) { alert('Add Department: ' + exception); }
    };

    $scope.onDeleteCostAllocation = function () {
        try {
            if ($scope.grdOptDepartment.api.getSelectedRows().length > 0) {
                $scope.grdOptDepartment.api.getSelectedRows().forEach(x => x.Delete = true);
                $scope.grdOptDepartment.api.getFilterInstance('Delete').onFilterChanged();
                setDepartmentFooter();
            }
        }
        catch (exception) { alert('Delete Department: ' + exception); }
    };

    function setDepartmentFooter() {
        try {
            let _rate = 0;
            $scope.grdOptDepartment.api.forEachNode(n => _rate +=
                n.data.DepartmentCode != undefined && n.data.DepartmentCode != null && !n.data.Delete ?
                    n.data.Rate : 0);
            var _footer = [{ DepartmentCode: null, Rate: _rate }];
            $scope.grdOptDepartment.api.setPinnedBottomRowData(_footer);
        }
        catch (exception) { alert('Department  Footer Method:' + exception); }
    }
    //#endregion       

    //#region general functions
    function setGridData() {
        if ($scope.AllocationTemplate != []) {
            $scope.grdOptDepartment.api.setRowData($scope.AllocationTemplate.Details);
            setGridDeleteFilter($scope.grdOptDepartment.api);
        }
        else { $scope.grdOptDepartment.api.setRowData([]); }
        setDepartmentFooter();
    }

    $scope.sum = function (items, prop) {
        return items.reduce(function (a, b) {
            return a + b[prop];
        }, 0);
    };
    //#endregion
     //#endregion


});