﻿baseURL = "/HRIS/Master/Employee/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

//to be verified later
$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#txtEmployeeName').focus();
    });

    // #region Date field setup      
    //$('#DueDate').datepicker({
    //    minDate: '0D',
    //    maxDate: '+10Y'
    //});

    //$('#DExpiryDate').datepicker({
    //    minDate: '0D',
    //    maxDate: '+10Y'
    //});

    //$('#ExpiryDate').datepicker({
    //    minDate: '0D',
    //    maxDate: '+10Y'
    //});

    //$('#ReminderDate').datepicker({
    //    minDate: '0D',
    //    maxDate: '+10Y'
    //});

    //$('#DisposalDate').datepicker({
    //    minDate: '0D',
    //    maxDate: '+10Y'
    //});

    //$('#IssueDate').datepicker({});
    ////$('#DOB').datepicker({
    ////    minDate: '-60Y',
    ////    maxDate: '+0D'
    ////});

    //$('#EffectiveDate').datepicker();

    //$("#tbSalary").tabs({
    //    collapsible: false
    //});

    //$("#dialog-delete").dialog({
    //    autoOpen: false,
    //    resizable: false,
    //    height: 250,
    //    width: 400,
    //    modal: true,
    //    class: "DeleteAlert",
    //    dialogClass: "DeleteAlert",
    //    title: "Confirm Delete Action",
    //    buttons: [
    //        {
    //            id: "btnDelete",
    //            text: "Delete",
    //            width: 120,
    //            class: "delete",
    //            click: function () {
    //                $(this).dialog('close');
    //                var employeeid = document.getElementById("txtEmployeeCode").value;
    //                deleteRequest(employeeid);
    //            }
    //        },
    //        {
    //            id: "btnCancel",
    //            text: "Go Back!",
    //            width: 120,
    //            click: function () {
    //                $(this).dialog('close');
    //            }
    //        }
    //    ],
    //    open: function () {
    //        //this special part is just done because delete and cancel were appearing in this form for unknown reason
    //        $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').prop('disabled', false);
    //        $(this).siblings('.ui-dialog-buttonpane').find('button:eq(0)').prop('disabled', false);
    //        //end of this special part
    //        $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').focus();
    //    }

    //});
});

//to be verified later
//#region profile image section
function ShowDefaultImage() {
    //document.getElementById("photo-id").style.display = "inline-block";
    //document.getElementById("DefaultImg").style.display = "inline-block";
    //document.getElementById("photo-id").style.display = "none";
}

function ShowProfileImage() {
    //document.getElementById("photo-id").style.display = "inline-block";
    //document.getElementById("DefaultImg").style.display = "none";
}
//#endregion

//to be verified later
function changePicture() {
    $('#fuAttachment').click();
}

app.controller('EmployeeController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        LoadDropDown();
        setDateParameters();
    };

    function LoadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            if (result.data.success) {
                $scope.lstCompany = result.data.lstCompany;
                $scope.lstBranch = result.data.lstBranch;
                $scope.lstDepartment = result.data.lstDepartment;
                $scope.lstSupervisor = result.data.lstSupervisor;
                $scope.lstReplacement = result.data.lstReplacement;
                $scope.lstStatus = result.data.lstEmployeeStatus;
                $scope.lstJobNature = result.data.lstJobNature;
                $scope.lstMaritalStatus = result.data.lstMaritalStatus;
                $scope.lstGrade = result.data.lstGrade;
                $scope.lstQualification = result.data.lstQualification;
                $scope.lstPaymentMode = result.data.lstPaymentMode;
                $scope.lstBank = result.data.lstBank;
                //$scope.lstLeaveType = result.data.lstLeaveType;
                $scope.lstAssetType = result.data.lstAssetType;
                $scope.lstRelation = result.data.lstRelation;
                $scope.lstMedicalPlan = result.data.lstMedicalPlan;
                $scope.lstSalaryHead = result.data.lstSalaryHead;
                $scope.lstAttachmentType = result.data.lstAttachmentType;
                $scope.lstAllocTemplate = result.data.lstAllocTemplate;
                $scope.lstWorkerType = result.data.lstWorkerType;

                $scope.lstGender = [{
                    GenderId: 1,
                    GenderName: 'Male'
                }, {
                    GenderId: 2,
                    GenderName: 'Female'
                }];

                $scope.lstHiringType = [{
                    HiringTypeId: 1,
                    HiringTypeName: 'Additional'
                }, {
                    HiringTypeId: 2,
                    HiringTypeName: 'Replacement'
                }, {
                    HiringTypeId: 3,
                    HiringTypeName: 'Replacement Promotion'
                }];
            }
            else {
                //scope.errors = [result.data.errorMsg];
                alert('Load dropdown failed with: ' + result.data.errorMsg);
            }
        }, errorMsg => {
            alert('Main dropdown loading function failed with following reasons\n' + errorMsg);
        });
    }
    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.Employee = response.data.employee;
            $scope.footer = response.data.employee.AuditTrail;
            setFormControls(response.data.session);
            setGridData();
            maskDates();
            $('#txtEmployeeName').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtEmployeeCode').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Employee";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getEmployeeByCode($rootScope.SelectedRow.EmployeeCode);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.getEmployeeByCode = function (res) {
        $http({
            method: "GET",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            $scope.errors = [];
            $scope.Employee = {};
            if (!result.data.success) {
                $scope.errors = [result.data.Message];
            }
            else {
                $scope.Employee = result.data.data;
                $scope.footer = $scope.Employee.AuditTrail;
                setGridData();
                //Calculate_TotalSalary();
                //Calculate_TotalPercentage();
            }
            setFormControls(result.data.Session);
            ShowProfileImage();
            maskDates();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    //to be verified later
    $scope.tbSave = function () {
        $scope.Employee.Salary = getSalaryDataFromGrid();
        $scope.Employee.CostAllocations = getCostAllocationDataFromGrid();
        $scope.Employee.Family = getFamilyDataFromGrid();
        $scope.Employee.Asset = getAssetDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.Employee
            //
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.Message];
            }
            else {
                alert(result.data.Message);
                $scope.Employee = {};
                //$('#photo-id').val("");
                $('#fuAttachment').val("");
                setGridData();
                //$scope.ClearAsset();
                setFormControls(result.data.Session);
                if ($scope.Employee.image == null) {
                    ShowDefaultImage();
                }
                else {
                    ShowProfileImage();
                }
                //maskDates();
            }
        }, errorMsg => {
            alert(result);
        });
    };

    $scope.tbUndo = function () {
        try {
            $scope.Employee = {};
            $scope.footer = {};
            $scope.errors = [];
            setGridData();
            setFormControls("Initialize");
            //this part to be reviewed later once screen finalize
            //$('#fuAttachment').val("");
            //document.getElementById("TotalSalary").innerText = "";
            //document.getElementById("TotalPercentage").innerText = "";
            //$scope.ClearLeave();
            //$scope.ClearSM();
            //$scope.ClearAsset();
            //$scope.ClearFNK();
            //$scope.ClearFM();
            //$scope.ClearCA();
        }
        catch (exception) {
            alert(exception);
        }
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region grid setup
    //#region Salary Grid
    var colSalary = [
        {
            headerName: "HeadId", field: "HeadId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'SalaryHead', class: "agGridSelect250" },
            valueFormatter: getSalaryHeadName, width: 250
        },
        {
            headerName: "Amount", field: "Amount", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 120
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true }
    ];

    $scope.grdOptSalary = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colSalary,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        stopEditingWhenGridLosesFocus: true,
        onGridReady: (grid) => {
            setSalaryFooter();
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
            setSalaryFooter();
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect()
        }
    };

    function getSalaryDataFromGrid() {
        let rowData = [];
        $scope.grdOptSalary.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddSalary = function () {
        try {
            var res = $scope.grdOptSalary.api.updateRowData({ add: [{ HeadId: null, Amount: 0, Add: true, Edit: false, Delete: false }] });
            $scope.grdOptSalary.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "HeadId" });
        }
        catch (exception) { alert('Add Salary Head: ' + exception); }
    };

    $scope.onDeleteSalary = function () {
        try {
            if ($scope.grdOptSalary.api.getSelectedRows().length > 0) {
                $scope.grdOptSalary.api.getSelectedRows().forEach(x => x.Delete = true);
                $scope.grdOptSalary.api.getFilterInstance('Delete').onFilterChanged();
                setSalaryFooter();
            }
        }
        catch (exception) { alert('Delete Salary Head: ' + exception); }
    };

    function setSalaryFooter() {
        try {
            let _total = 0;
            if ($scope.grdOptSalary.api.getDisplayedRowCount() > 0) {
                $scope.grdOptSalary.api.forEachNode(n => _total +=
                    n.data.HeadId != undefined && n.data.HeadId != -1 && !n.data.Delete ?
                        n.data.Amount * $scope.lstSalaryHead.find(sh => { return sh.HeadId == n.data.HeadId; })["Symbol"] : 0);
            }
            var _footer = [{ HeadId: -1, Amount: _total }];
            $scope.grdOptSalary.api.setPinnedBottomRowData(_footer);
        }
        catch (exception) { alert('Salary Footer Method:' + exception); }
    }
    //#endregion

    //#region Cost Allocation Grid
    var colCostAllocation = [
        {
            headerName: "Template", field: "TemplateId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'Template', class: "agGridSelect130" },
            valueFormatter: getAllocTemplateName, width: 130
        },
        {
            headerName: "Branch", field: "BranchCode", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'Branch', class: "agGridSelect170" },
            valueFormatter: getBranchName, width: 170
        },
        {
            headerName: "Rate (%)", field: "Rate", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 100
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true }
    ];

    $scope.grdOptCostAlloc = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colCostAllocation,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        stopEditingWhenGridLosesFocus: true,
        onGridReady: (grid) => {
            setCostAllocationFooter();
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
            if (params.colDef.field == "Rate")
                setCostAllocationFooter();
        },
        onGridSizeChanged: () => {
            $scope.grdOptCostAlloc.api.sizeColumnsToFit();
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect()
        }
    };

    function getCostAllocationDataFromGrid() {
        let rowData = [];
        $scope.grdOptCostAlloc.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddCostAllocation = function () {
        try {
            var res = $scope.grdOptCostAlloc.api.updateRowData({ add: [{ TemplateId: null, BranchCode: null, Rate: 0, Add: true, Edit: false, Delete: false }] });
            $scope.grdOptCostAlloc.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "TemplateId" });
        }
        catch (exception) { alert('Add Cost Allocation: ' + exception); }
    };

    $scope.onDeleteCostAllocation = function () {
        try {
            if ($scope.grdOptCostAlloc.api.getSelectedRows().length > 0) {
                $scope.grdOptCostAlloc.api.getSelectedRows().forEach(x => x.Delete = true);
                $scope.grdOptCostAlloc.api.getFilterInstance('Delete').onFilterChanged();
                setCostAllocationFooter();
            }
        }
        catch (exception) { alert('Delete Cost Allocation: ' + exception); }
    };

    function setCostAllocationFooter() {
        try {
            let _total = 0;
            $scope.grdOptCostAlloc.api.forEachNode(n => _total +=
                n.data.TemplateId != undefined && n.data.TemplateId != -1 && !n.data.Delete ?
                    n.data.Rate : 0);
            var _footer = [{ TemplateId: -1, BranchCode: null, Rate: _total }];
            $scope.grdOptCostAlloc.api.setPinnedBottomRowData(_footer);
        }
        catch (exception) { alert('Cost Allocation Footer Method:' + exception); }
    }
    //#endregion

    //#region Family Grid
    var colFamily = [
        {
            headerName: "Relation", field: "RelationId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'Relation', class: "agGridSelect130" },
            valueFormatter: getRelationName, width: 130
        },
        {
            headerName: "Member Name", field: "MemberName", width: 250,
        },
        {
            headerName: "Birth Date", field: "DoB", width: 125,
            cellEditor: 'datePicker',
            cellEditorParams: { minDate: '-25Y', maxDate: '+0d' }
        },
        {
            headerName: 'Emergency Ctc?', field: 'EmergencyContact', width: 145,
            cellRenderer: params => {
                if (params.value) {
                    return "<input type='checkbox' checked />";
                }
                else {
                    return "<input type='checkbox'/>";
                }
            },
            cellEditor: "agilityCheckBoxEditor"
        },
        {
            headerName: "Contact #", field: "ContactNo", cellEditor: "agTextCellEditor",
            width: 150
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true }
    ];

    $scope.grdOptFamily = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colFamily,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        //stopEditingWhenGridLosesFocus: true,
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect(),
            datePicker: getDatePicker(),
            agilityCheckBoxEditor: getCellCheckBox()
        }
    };

    function getFamilyDataFromGrid() {
        let rowData = [];
        $scope.grdOptFamily.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddFamily = function () {
        try {
            var res = $scope.grdOptFamily.api.updateRowData({
                add: [{
                    RelationId: null, MemberName: null, DoB: "",
                    EmergencyContact: false, ContactNo: null, Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptFamily.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "RelationId" });
        }
        catch (exception) { alert('Add Family Member: ' + exception); }
    };

    $scope.onDeleteFamily = function () {
        try {
            if ($scope.grdOptFamily.api.getSelectedRows().length > 0) {
                if (confirm("Are you sure you want to Delete selected row?")) {
                    $scope.grdOptFamily.api.getSelectedRows().forEach(x => x.Delete = true);
                    $scope.grdOptFamily.api.getFilterInstance('Delete').onFilterChanged();
                }
            }
            else
                alert("No Row selected to apply Delete operation. Please select row and then hit Delete button!");
        }
        catch (exception) { alert('Delete Family Member: ' + exception); }
    };
    //#endregion

    //#region Asset Grid
    var colAsset = [
        {
            headerName: "Asset Type", field: "AssetTypeId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'AssetType', class: "agGridSelect130" },
            valueFormatter: getAssetTypeName, width: 130
        },
        {
            headerName: "Reg/Ser #", field: "RegistrationNo", width: 120
        },
        {
            headerName: "Model", field: "Model", width: 100
        },
        {
            headerName: "Base Value", field: "BaseValue", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 100
        },
        {
            headerName: "Limit", field: "Limit", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 100
        },
        {
            headerName: "Issue Date", field: "IssueDate", width: 105,
            cellEditor: 'datePicker',
            cellEditorParams: { minDate: '-5Y', maxDate: '+0d' }
        },
        {
            headerName: "Expiry Date", field: "ExpiryDate", width: 105,
            cellEditor: 'datePicker',
            cellEditorParams: { minDate: '-1Y', maxDate: '+10Y' }
        },
        {
            headerName: "Reminder Date", field: "ReminderDate", width: 105,
            cellEditor: 'datePicker',
            cellEditorParams: { minDate: '-0d', maxDate: '+10Y' }
        },
        {
            headerName: "Disposal Date", field: "DisposalDate", width: 105,
            cellEditor: 'datePicker',
            cellEditorParams: { minDate: '-5Y', maxDate: '+0d' }
        },
        {
            headerName: 'Consumable?', field: 'Consumable', width: 105, //editable: false,
            //cellRenderer: params => {
            //    return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
            //}
            cellRenderer: params => {
                return `<input type='checkbox' ${params.value ? 'checked' : ''} />`;
                //if (params.value) {
                //    return "<input type='checkbox' checked />";
                //}
                //else {
                //    return "<input type='checkbox'/>";
                //}
            },
            cellEditor: "agilityCheckBoxEditor"
        },
        {
            headerName: 'Active?', field: 'Active', width: 85,
            cellRenderer: params => {
                if (params.value) {
                    return "<input type='checkbox' checked />";
                }
                else {
                    return "<input type='checkbox'/>";
                }
            },
            cellEditor: "agilityCheckBoxEditor"
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true }
    ];

    $scope.grdOptAsset = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colAsset,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect(),
            datePicker: getDatePicker(),
            agilityCheckBoxEditor: getCellCheckBox()
        }
    };

    function getAssetDataFromGrid() {
        let rowData = [];
        $scope.grdOptAsset.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddAsset = function () {
        try {
            var res = $scope.grdOptAsset.api.updateRowData({
                add: [{
                    AssetTypeId: null, RegistrationNo: null, Model: null, BaseValue: 0, Limit: 0,
                    IssueDate: "", ExpiryDate: "", ReminderDate: "", DisposalDate: "",
                    Consumable: false, Active: true, Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptAsset.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "AssetTypeId" });
        }
        catch (exception) { alert('Add Employee Asset: ' + exception); }
    };

    $scope.onDeleteAsset = function () {
        try {
            if ($scope.grdOptAsset.api.getSelectedRows().length > 0) {
                if (confirm("Are you sure you want to Delete selected row?")) {
                    $scope.grdOptAsset.api.getSelectedRows().forEach(x => x.Delete = true);
                    $scope.grdOptAsset.api.getFilterInstance('Delete').onFilterChanged();
                }
            }
            else
                alert("No Row selected to apply Delete operation. Please select row and then hit Delete button!");
        }
        catch (exception) { alert('Delete Employee Asset: ' + exception); }
    };
    //#endregion

    //#region general functions
    function setGridData() {
        try {
            if ($scope.Employee != []) {
                $scope.grdOptSalary.api.setRowData($scope.Employee.Salary);
                $scope.grdOptCostAlloc.api.setRowData($scope.Employee.CostAllocations);
                $scope.grdOptFamily.api.setRowData($scope.Employee.Family);
                $scope.grdOptAsset.api.setRowData($scope.Employee.Asset);
                setGridDeleteFilter($scope.grdOptSalary.api);
                setGridDeleteFilter($scope.grdOptCostAlloc.api);
                setGridDeleteFilter($scope.grdOptFamily.api);
                setGridDeleteFilter($scope.grdOptAsset.api);
            }
            else {
                $scope.grdOptSalary.api.setRowData([]);
                $scope.grdOptCostAlloc.api.setRowData([]);
                $scope.grdOptFamily.api.setRowData([]);
                $scope.grdOptAsset.api.setRowData([]);
            }
            setSalaryFooter();
            setCostAllocationFooter();
        }
        catch (exception) { alert(exception); }
    }
    //#endregion
    //#endregion

    //to be verified later
    //$scope.readURL = function (input) {
    $scope.readURL = function (input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {

                //Sets the Old Image to new New Image
                $('#photo-id').attr('src', e.target.result);

                //Create a canvas and draw image on Client Side to get the byte[] equivalent
                var canvas = document.createElement("canvas");
                var imageElement = document.createElement("img");

                imageElement.setAttribute('src', e.target.result);
                canvas.width = imageElement.width;
                canvas.height = imageElement.height;
                var context = canvas.getContext("2d");
                context.drawImage(imageElement, 0, 0);
                var base64Image = canvas.toDataURL("image/jpeg");

                //Removes the Data Type Prefix 
                //And set the view model to the new value
                //
                $scope.Employee.ProfileImage = base64Image.replace(/data:image\/jpeg;base64,/g, '');
                ShowProfileImage();
            };
            reader.readAsDataURL(input.files[0]);
        }
    };

    //$scope.toggleEdit = function (m) {
    //    m.showEdit = m.showEdit ? false : true;
    //}

    //to be verified later
    //#region Attachments
    $scope.AddAttachment = function () {
        var AT = document.getElementById('atid').value;
        var DE = document.getElementById('DExpiryDate').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var totalFiles = document.getElementById("fuAttachment").files.length;

        if (AT == "" && totalFiles < 1) {
            alert("Please Seelct Valid Attachment type and File. Before saving value in Grid.");
            document.getElementById('atid').value = "";
            document.getElementById('DExpiryDate').value = "";
            $('#fuAttachment').val("");
            return false;
        }

        var dr = $scope.Employee.EmpAttachmentDetails.filter(function (a) { return a.AttachmentTypeId = AT && !a.IsDeleted; });
        if (dr.lenght != undefined) {
            alert("You can not upload document of same type more than once!");
            document.getElementById('atid').value = "";
            document.getElementById('DExpiryDate').value = "";
            $('#fuAttachment').val("");
            return false;
        }
        var formData = new FormData();
        //File Upload
        totalFiles = document.getElementById("fuAttachment").files.length;

        for (var i = 0; i < totalFiles; i++) {
            var file = document.getElementById("fuAttachment").files[i];
            formData.append("UploadedFile", file);
        }

        formData.append("DExpiryDate", $('#DExpiryDate').val());
        formData.append("AttachmentTypeId", $('#atid').val());

        $http({
            url: '/Employee/SaveAttachment',
            method: 'POST',
            headers: { "Content-Type": undefined },
            transformRequest: function (data) {
                return formData;//NOTICE THIS RETURN WHICH WAS MISSING
            }
        }).then(result => {
            if (result.data.success == true) {
                $scope.Employee.EmpAttachmentDetails.push(result.data);
                for (i = 0; i < result.data.length; i++) {
                    if (result.data[i]["DExpiryDate"] != null)
                        result.data[i]["DExpiryDate"] = formatDate(result.data[i]["DExpiryDate"]);
                }
                document.getElementById('atid').value = "";
                document.getElementById('DExpiryDate').value = "";
                $('#fuAttachment').val("");
            }
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.ViewAttachment = function (index) {
        var id = $scope.Employee.EmpAttachmentDetails[index].AttachmentTypeId;
        var AttachmentContentType = $scope.Employee.EmpAttachmentDetails[index].AttachmentContentType;
        var AttachmentName = $scope.Employee.EmpAttachmentDetails[index].AttachmentName;

        $http({
            method: "POST",
            url: "/Employee/ViewAttachment",
            data: { _KeyId: id },
            headers: {
                'Content-type': 'application/json'
                //"Content-Type": undefined
            },
            responseType: 'arraybuffer'
        }).then(result => {
            var blob = new Blob([result.data], {
                type: AttachmentContentType
            });
            saveAs(blob, AttachmentName);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.RemoveAttachment = function (index) {
        //Find the record using Index from Array.
        var id = $scope.Employee.EmpAttachmentDetails[index].AttachmentTypeId;
        var isnew = $scope.Employee.EmpAttachmentDetails[index].IsNew;
        $window.confirm("Do you want to delete: ");

        $http({
            url: "/Employee/DeleteAttachment",
            method: "POST",
            data: { _keyId: id }
        }).then(result => {
            if (result.data.success == true) {
                $scope.Employee.EmpAttachmentDetails = result.data;
                for (i = 0; i < result.data.length; i++) {
                    if (result.data[i]["DExpiryDate"] != null)
                        result.data[i]["DExpiryDate"] = formatDate(result.data[i]["DExpiryDate"]);
                }
            }
            else {
                alert(result.Message);
            }
        }, errorMsg => {
            alert(errorMsg);
        });
    };
    //#endregion

    //#region date functions
    function setDateParameters() {
        $('#dpJoining').datepicker({
            startDate: '-90Y',
            endDate: '+30d'
        });

        $('#dpConfirmationDue').datepicker({
            startDate: '-90Y',
            endDate: '+180d'
        });

        $('#dpConfirmation').datepicker({
            startDate: '-60Y'
        }).on('changeDate', function (e) {
            $scope.Employee.ConfirmationDate = e.format();
            $scope.$apply();
        });

        $('#dpSeparation').datepicker({
            startDate: '-30Y',
            endDate: '+30d'
        }).on('changeDate', function (e) {
            $scope.Employee.SeparationDate = e.format();//dt;
            $scope.$apply();
        });

        $('#dpBirth').datepicker({
            startDate: '-70y',
            enddate: '-18y',
            defaultViewDate: new Date(new Date().getFullYear() - 18, new Date().getMonth(), new Date().getDate())
        });

        $('#dpWorkingSince').datepicker({
            startDate: '-60y'
        }).on('changeDate', function (e) {
            $scope.Employee.EmpPersonalInfo.WorkingSince = e.format();//dt;
            $scope.$apply();
        });
    }

    //to be verified later
    function maskDates() {
        $scope.Employee.JoiningDate = formatDate($scope.Employee.JoiningDate);
        $scope.Employee.ConfirmationDueDate = formatDate($scope.Employee.ConfirmationDueDate);
        $scope.Employee.EmpPersonalInfo.BirthDate = formatDate($scope.Employee.EmpPersonalInfo.BirthDate);
        $scope.Employee.EmpPersonalInfo.WorkingSince = formatDate($scope.Employee.EmpPersonalInfo.WorkingSince);

        if ($scope.Employee.ConfirmationDate != null) {
            $scope.Employee.ConfirmationDate = formatDate($scope.Employee.ConfirmationDate);
        }

        if ($scope.Employee.SeparationDate != null) {
            $scope.Employee.SeparationDate = formatDate($scope.Employee.SeparationDate);
        }

        if ($scope.Employee.Family != null) {
            for (i = 0; i < $scope.Employee.Family.length; i++) {
                $scope.Employee.Family[i]["DOB"] = formatDate($scope.Employee.Family[i]["DOB"]);
            }
        }

        if ($scope.Employee.Assets != null) {
            for (i = 0; i < $scope.Employee.Assets.length; i++) {
                $scope.Employee.Assets[i]["IssueDate"] = formatDate($scope.Employee.Assets[i]["IssueDate"]);
                $scope.Employee.Assets[i]["ExpiryDate"] = formatDate($scope.Employee.Assets[i]["ExpiryDate"]);
                $scope.Employee.Assets[i]["ReminderDate"] = formatDate($scope.Employee.Assets[i]["ReminderDate"]);
                $scope.Employee.Assets[i]["DisposalDate"] = formatDate($scope.Employee.Assets[i]["DisposalDate"]);
            }
        }
        if ($scope.Employee.Attachments != null) {
            for (i = 0; i < $scope.Employee.Attachments.length; i++) {
                if ($scope.Employee.Attachments[i]["ExpiryDate"] != null)
                    $scope.Employee.Attachments[i]["ExpiryDate"] = formatDate($scope.Employee.Attachments[i]["ExpiryDate"]);
            }
        }

        if ($scope.Employee.AuditTrail != null) {
            if ($scope.Employee.AuditTrail.CreatedOn != null) {
                $scope.Employee.AuditTrail.CreatedOn = formatDateTime($scope.Employee.AuditTrail.CreatedOn);
            }
            if ($scope.Employee.AuditTrail.UpdatedOn != null) {
                $scope.Employee.AuditTrail.UpdatedOn = formatDateTime($scope.Employee.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion
});