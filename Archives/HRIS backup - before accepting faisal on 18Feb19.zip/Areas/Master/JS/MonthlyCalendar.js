﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setNoFindFormControls("Edit");
        setDropDown("Edit")
        $('#Desc').focus();
    });
});


function setDropDown(formMode) {
    if (formMode == "Recall") {
        document.getElementById("ddmonth").disabled = false;
        document.getElementById("ddyear").disabled = false;
        document.getElementById("btnLoad").disabled = false;
    }
    else {
        document.getElementById("ddmonth").disabled = true;
        document.getElementById("ddyear").disabled = true;
        document.getElementById("btnLoad").disabled = true;
    }
}


function validate(mon, year) {


    if (mon == "") {
        alert("Please select month before hitting load button");
        return false;
    }

    else if (year == "") {
        alert("Please select Year before hitting load button");
        return false;
    }
    else
        return true;
};



var app = angular.module('HRIS', []);

app.controller('MonthlyCalendarController', function ($scope, $http, $window) {

    $scope.load = function (res) {               
        LoadDropDown();
    };


    $scope.savedata = function () {
        $http({
            method: "POST",
            url: "/MonthlyCalendar/Save",
            data: $scope.MonthlyCalendar
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.MonthlyCalendar = result.data;
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                 $scope.MonthlyCalendar = [];
            }
            setNoFindFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    }



    $scope.GetMonthlyCalendar = function () {
        var mon = document.getElementById("ddmonth").value;
        var year = document.getElementById("ddyear").value;
        var isValid = validate(mon, year);
        if (isValid == true) {

            $http({
                method: "POST",
                url: "/MonthlyCalendar/Get",
                data: { monthnum: mon, year: year },

            }).success(function (result) {
                $scope.errors = [];
                $scope.MonthlyCalendar = {};
                if (result.success == false) {
                    $scope.errors = [
                       result.Message]
                }
                else {
                    $scope.MonthlyCalendar = result.data;
                }
                setNoFindFormControls(result.Session);
                setDropDown(result.Session);
                ConvertDate();
            }).catch(function (result) {
                alert(result);
            });
        }
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/MonthlyCalendar/Undo"
        }).success(function (result) {
            $scope.MonthlyCalendar = {};
            $scope.errors = [];
            setNoFindFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/MonthlyCalendar/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    //$scope.Add = function () {
    //    $http({
    //        method: "POST",
    //        url: "/MonthlyCalendar/Add"
    //    }).success(function (result) {
    //        $scope.MonthlyCalendar = {};
    //        $scope.MonthlyCalendar = result.data;
    //        setNoFindFormControls(result.Session);
    //        ConvertDate();
    //    }).catch(function (result) {

    //    });
    //}

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/MonthlyCalendar/Recall"
        }).success(function (result) {
            $scope.MonthlyCalendar = [];
            setNoFindFormControls(result.Session);
            setDropDown("Recall");
        }).catch(function (result) {

        });
    }


    $scope.AddMC = function () {

        //Add the new item to the Array.
        var CD = document.getElementById('CalendarDate').value;
        var DA = document.getElementById('Day').value;
        var HO = document.getElementById('Holiday').checked;
        var RE = document.getElementById('Reason').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;
           
            var ma = {};
            if (RE == true && RE!="")
            {
                alert("If Holiday is checked please enter reason for that. Before saving value in Grid. ");
                return false;
            }
            else {
                return true;
            }
            if (Index != "")
                $scope.MonthlyCalendar.Details.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }

            ma.CalendarDate = CD;
            ma.Day = DA;
            ma.Holiday = HO;
            ma.Reason = RE;
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.MonthlyCalendar.Details.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = detailid + 1;
            //}
            $scope.MonthlyCalendar.Details.push(ma);
            $scope.Clear();
            ma = {};
       
    }
    $scope.Clear = function () {
        //Clear the TextBoxes.
        document.getElementById('CalendarDate').value = "";
        document.getElementById('Day').value = "";
        document.getElementById('Holiday').checked = false;
        document.getElementById('Reason').value = "";
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
    }
    $scope.EditMC = function (m, index) {

        document.getElementById('CalendarDate').value = m.CalendarDate;
        document.getElementById('Day').value = m.Day;
        document.getElementById('Holiday').checked = m.Holiday;
        document.getElementById('Reason').value = m.Reason;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }


    //$scope.toggleEdit = function (m) {
    //    m.showEdit = m.showEdit ? false : true;
    //}

 
    //$scope.EditMC = function (m, index) {
    //    //Add the new item to the Array.

    //    var mc = {};
    //    $scope.MonthlyCalendar.Details.splice(index, 1);
    //    mc.CalendarDate = m.CalendarDate;
    //    mc.Day = m.Day;
    //    mc.Holiday = m.Holiday;
    //    mc.Reason = m.Reason;
    //    mc.DetailId = m.DetailId;
    //    mc.showEdit = false;
    //    mc.status = "Edited";
    //    $scope.MonthlyCalendar.Details.push(mc);

    //}
    //$scope.RemoveMC = function (index) {
    //    //Find the record using Index from Array.
    //    var CC = $scope.MonthlyCalendar.Details[index].DetailId;
    //    if ($window.confirm("Do you want to delete: " + CC)) {
    //        //Remove the item from Array using Index.
    //        $scope.MonthlyCalendar.Details.splice(index, 1);
    //    }
    //}

    function LoadDropdown ()
    {
        $http.get('/MonthlyCalendar/GetMonth').then(function (d) {
            $scope.Monthlist = d.data;
        }, function () {
            alert('failed');
        });


        $http.get('/MonthlyCalendar/GetYear').then(function (d) {
            $scope.Yearlist = d.data;
        }, function () {
            alert('failed');
        });

    }

    



    function ConvertDate() {
               
        for (i = 0; i < $scope.MonthlyCalendar.Details.length; i++) {
            if ($scope.MonthlyCalendar.Details[i]["CalendarDate"] != null)
                $scope.MonthlyCalendar.Details[i]["CalendarDate"] = formattingdate($scope.MonthlyCalendar.Details[i]["CalendarDate"]);
        }

        for (i = 0; i < $scope.MonthlyCalendar.donotUseDetails.length; i++) {
            if ($scope.MonthlyCalendar.donotUseDetails[i]["CalendarDate"] != null)
                $scope.MonthlyCalendar.donotUseDetails[i]["CalendarDate"] = formattingdate($scope.MonthlyCalendar.donotUseDetails[i]["CalendarDate"]);
        }

    }

});