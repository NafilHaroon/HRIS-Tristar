﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});

var app = angular.module('HRIS', []);

app.controller('LeaveController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtLId').value;
        if (id > 0)
            $scope.GetData(id);

    };

    $scope.savedata = function (res) {
        $http({
            method:"POST",
            url: "/Leave/Save",
            data: $scope.Leave
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Leave = result.data;
               
            }
            else {
                 alert(result.Message);
                $scope.Leave = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/Leave/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.Leave = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.Leave = result.data;

            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/Leave/Undo"
        }).success(function (result) {
            $scope.Leave = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/Leave/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/Leave/Add"
        }).success(function (result) {
            $scope.Leave = {};
            $scope.Leave = result.data;
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/Leave/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    function ConvertDate() {

        $scope.Leave.AuditTrail.CreatedOn = formattingDateTime($scope.Leave.AuditTrail.CreatedOn);
        if ($scope.Leave.AuditTrail.UpdatedOn != null) {
            $scope.Leave.AuditTrail.UpdatedOn = formattingDateTime($scope.Leave.AuditTrail.UpdatedOn);
        }
    }


   
});