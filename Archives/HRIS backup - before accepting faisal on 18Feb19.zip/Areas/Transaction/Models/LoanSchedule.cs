﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Transaction.Models
{
    public class LoanSchedule: IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Loan Id")]
        public short? LoanId { get; set; }
        [Display(Name = "Starting Date")]
        public DateTime? StartingDate { get; set; }
        [Display(Name = "Employee")]
        public short? EmployeeId { get; set; }
        [Display(Name = "Remarks")]
        public string Remarks  { get; set; }
        [Display(Name = "Loan Amount")]
        public double LoanAmount { get; set; }
        [Display(Name = "Loan Period")]
        public short? LoanPeriod { get; set; }
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }
        [Display(Name = "Company Book")]
        public bool CompanyBook { get; set; }
        [Display(Name = "PF Book")]
        public bool PFBook { get; set; }
       
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public LoanSchedule()
        {
            AuditTrail = new Footer();
            IsActive = true;
            StartingDate = DateTime.Now;
        }
        #endregion

        #region internal methods
        internal static LoanSchedule Get(short LoanId, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetLoanScheduleByCode"))
            {
                db.AddInParameter(dbCommand, "LoanId", SqlDbType.SmallInt, LoanId);
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (LoanSchedule _bran = new LoanSchedule())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _bran.LoanId = LoanId;
                            _bran.StartingDate = Convert.ToDateTime(dr["StartingDate"]);
                            _bran.EmployeeId = Convert.ToInt16(dr["EmployeeId"]);
                            _bran.Remarks = dr["Remarks"].ToString();
                            _bran.LoanAmount = Convert.ToDouble(dr["LoanAmount"]);
                            _bran.LoanPeriod = Convert.ToInt16(dr["LoanPeriod"]);
                            _bran.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _bran.CompanyBook = Convert.ToBoolean(dr["CompanyBook"]);
                            _bran.PFBook = Convert.ToBoolean(dr["PFBook"]);
                            _bran.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _bran.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _bran.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _bran.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                            return _bran;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(LoanSchedule _ls, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveLoanSchedule"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "LoanId", SqlDbType.SmallInt, _ls.LoanId);
                    db.AddInParameter(dbCommand, "StartingDate", SqlDbType.DateTime, _ls.StartingDate);
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _ls.EmployeeId);
                    db.AddInParameter(dbCommand, "Remarks", SqlDbType.VarChar, _ls.Remarks);
                    db.AddInParameter(dbCommand, "LoanAmount", SqlDbType.Float, _ls.LoanAmount);
                    db.AddInParameter(dbCommand, "LoanPeriod", SqlDbType.SmallInt, _ls.LoanPeriod);
                    db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _ls.IsActive);
                    db.AddInParameter(dbCommand, "PFBook", SqlDbType.Bit, _ls.PFBook);
                    db.AddInParameter(dbCommand, "CompanyBook ", SqlDbType.Bit, _ls.CompanyBook);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _ls.AuditTrail.UpdatedOn);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}