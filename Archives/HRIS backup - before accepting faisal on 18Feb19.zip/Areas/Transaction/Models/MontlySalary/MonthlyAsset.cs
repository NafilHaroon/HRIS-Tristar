﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Transaction.Models
{
    public class MonthlyAsset : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Asset")]
        public short? AssetId { get; set; }
        [Display(Name = "Limit")]
        public double Limit { get; set; }
        public string Remarks { get; set; }
        public int? DetailId { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        #endregion

        #region constructor
        public MonthlyAsset()
        {
            DetailId = -1;
            Add = true; Edit = false; Delete = false;
        }
        public MonthlyAsset(int _detailId, short _assetId, double _Limit, string _Remarks)
        {
            DetailId = _detailId;
            AssetId = _assetId;
            Limit = _Limit;
            Remarks = _Remarks;
            Add = true; Edit = false; Delete = false;
        }
        #endregion

        #region internal methods

        internal static List<MonthlyAsset> Get(short _empId)
        {
            try
            {
                List<MonthlyAsset> lstEAD = new List<MonthlyAsset>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getCurrentMonthCompanyAssetByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstEAD.Add(new MonthlyAsset(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["AssetId"]),
                                         Convert.ToDouble(dr["Limit"]),
                                             dr["Remarks"].ToString()));
                            }
                        }
                    }
                }
                return lstEAD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<MonthlyAsset> _details, DbTransaction _transaction)
        {
            try
            {
                foreach (MonthlyAsset eld in getChanges(_details))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveCurrentMonthCompanyAssetDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "AssetId", SqlDbType.TinyInt, eld.AssetId);
                        db.AddInParameter(dbCommand, "Remarks", SqlDbType.VarChar, eld.Remarks);
                        db.AddInParameter(dbCommand, "Limit", SqlDbType.Float, eld.Limit);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                               eld.Add ? "I" : (eld.Delete ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<MonthlyAsset> getChanges(List<MonthlyAsset> _details)
        {
            return (_details.Where(x => (x.Add && !x.Delete) || (x.Edit && !x.Delete) || x.Delete));
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}