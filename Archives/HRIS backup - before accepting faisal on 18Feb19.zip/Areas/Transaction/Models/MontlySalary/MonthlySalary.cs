﻿using HRIS.Areas.Common.Models;
using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Web;

namespace HRIS.Areas.Transaction.Models
{
    public class MonthlySalary : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Id")]
        public short? EmployeeId { get; set; }
        [Display(Name = "Branch")]
        public string BranchName { get; set; }
        [Display(Name = "Department")]
        public string DepartmentName { get; set; }
        [Display(Name = "Designation")]
        public string Designation { get; set; }
        [Display(Name = "Joining Date")]
        public DateTime JoiningDate { get; set; }
        [Display(Name = "Month Days")]
        public short MonthDays { get; set; }
        [Display(Name = "Absent Days")]
        public short AbsentDays { get; set; }
        [Display(Name = "LeavesDays")]
        public short LeavesDays { get; set; }
        [Display(Name = "SalaryDays")]
        public short SalaryDays { get; set; }
        [Display(Name = "Stop Salary")]
        public bool StopSalary { get; set; }
        public short SalaryMonth { get; set; }
        public short SalaryYear { get; set; }
        public bool Verified { get; set; }
        public string VerifiedBy { get; set; }
        public DateTime? VerifiedOn { get; set; }
        public List<SalaryDetail> Salary { get; set; }
        public List<MonthlyAsset> Asset { get; set; }
        public short AbsentDeductionId { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region constructor
        public MonthlySalary()
        {
            AuditTrail = new Footer();
            Salary = new List<SalaryDetail>();
            Asset = new List<MonthlyAsset>();
            AbsentDeductionId = Convert.ToInt16(HttpContext.Current.Session["AbsentDeductionId"]);
        }
        public MonthlySalary(short _EmployeeId)
        {
            EmployeeId = _EmployeeId;
            Salary = new List<SalaryDetail>();
            Asset = new List<MonthlyAsset>();
            AbsentDeductionId = Convert.ToInt16(HttpContext.Current.Session["AbsentDeductionId"]);
        }
        #endregion

        #region internal methods

        internal static MonthlySalary Get(short employeeid)
        {
            try
            {
                using (DbCommand dbCommandDetail = db.GetStoredProcCommand("getMonthlySalaryByCode"))
                {
                    db.AddInParameter(dbCommandDetail, "EmployeeId", SqlDbType.SmallInt, employeeid);
                    using (DataSet ds = db.ExecuteDataSet(dbCommandDetail))
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            MonthlySalary _cn = new MonthlySalary();
                            DataRow dr = ds.Tables[0].Rows[0];
                            _cn.EmployeeId = employeeid;
                            _cn.BranchName = dr["BranchName"].ToString();
                            _cn.DepartmentName = dr["DepartmentName"].ToString();
                            _cn.Designation = dr["Designation"].ToString();
                            _cn.JoiningDate = Convert.ToDateTime(dr["JoiningDate"]);
                            _cn.MonthDays = Convert.ToInt16(dr["MonthDays"]);
                            _cn.AbsentDays = Convert.ToInt16(dr["AbsentDays"]);
                            _cn.LeavesDays = Convert.ToInt16(dr["LeaveDays"]);

                            _cn.SalaryDays = Convert.ToInt16(_cn.MonthDays - _cn.AbsentDays);
                            _cn.SalaryMonth = Convert.ToInt16(dr["SalaryMonth"]);
                            _cn.SalaryYear = Convert.ToInt16(dr["SalaryYear"]);

                            _cn.Verified = Convert.ToBoolean(dr["Verified"]);
                            if (_cn.Verified == true)
                            {
                                _cn.VerifiedBy = dr["VerifiedBy"].ToString();
                                _cn.VerifiedOn = Convert.ToDateTime(dr["VerifiedOn"]);
                            }
                            _cn.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _cn.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                            _cn.Salary = SalaryDetail.Get(_cn.EmployeeId.Value);
                            _cn.Asset = MonthlyAsset.Get(_cn.EmployeeId.Value);
                            return _cn;
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Save(MonthlySalary _emp, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveCurrentMonthSalary"))
            {
                db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _emp.EmployeeId);
                db.AddInParameter(dbCommand, "MonthDays", SqlDbType.SmallInt, _emp.MonthDays);
                db.AddInParameter(dbCommand, "AbsentDays", SqlDbType.SmallInt, _emp.AbsentDays);
                db.AddInParameter(dbCommand, "LeaveDays", SqlDbType.SmallInt, _emp.LeavesDays);
                db.AddInParameter(dbCommand, "StopSalary", SqlDbType.Bit, _emp.StopSalary);

                db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        SalaryDetail.Save(_emp.EmployeeId.Value, _emp.Salary, transaction);
                        MonthlyAsset.Save(_emp.EmployeeId.Value, _emp.Asset, transaction);                   

                        transaction.Commit();
                        return true;
                    }

                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }


        internal static bool Delete(short _empid)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("DeleteCurrentSalary"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empid);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool GenerateSalary(string _userId, bool _generateOnlyNew)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("GenerateSalary"))
                {
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "GenerateOnlyNew", SqlDbType.Bit, _generateOnlyNew);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool PostSalary(string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("PostSalary"))
                {
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }


        #endregion

        #region private methods
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
    }
}