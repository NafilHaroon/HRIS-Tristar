﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Transaction.Models
{
    public class SalaryDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Head")]
        public short? HeadId { get; set; }
        [Display(Name = "Amount")]
        public double Amount { get; set; }
        [Display(Name = "Remarks")]
        public string Remarks { get; set; }
        public short LoanId { get; set; }
        public int? DetailId { get; set; }
        public bool AutoCalculated { get; set; }
        public bool AbsentDeduction { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }

        #endregion

        #region constructor
        public SalaryDetail()
        {
            DetailId = -1;
            Add = true; Edit = false; Delete = false;
        }
        public SalaryDetail(int _DetailId, short _HeadId, double _Amount, short _LoanId,  bool _AbsentDeduction,string _Remarks)
        {
            DetailId = _DetailId;
            HeadId = _HeadId;
            Amount = _Amount;
            LoanId = _LoanId;
            AbsentDeduction = _AbsentDeduction;
            Remarks = _Remarks;
            Add = true; Edit = false; Delete = false;
        }
        #endregion

        #region internal methods
        internal static List<SalaryDetail> Get(short _empId)
        {
            try
            {
                List<SalaryDetail> lstESMD = new List<SalaryDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getCurrentMonthSalaryDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstESMD.Add(new SalaryDetail(
                                     Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["HeadId"]),
                                         Convert.ToDouble(dr["Amount"]),
                                          Convert.ToInt16(dr["LoanId"]),
                                           Convert.ToBoolean(dr["AbsentDeduction"]),
                                         dr["Remarks"].ToString()));
                            }
                        }
                    }
                }
                return lstESMD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<SalaryDetail> _details, DbTransaction _transaction)
        {
            try
            {
                foreach (SalaryDetail eld in getChanges(_details))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveCurrentMonthlySalaryDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, eld.HeadId);
                        db.AddInParameter(dbCommand, "Amount", SqlDbType.Float, eld.Amount);
                        db.AddInParameter(dbCommand, "Remarks", SqlDbType.VarChar, eld.Remarks);
                        db.AddInParameter(dbCommand, "LoanId", SqlDbType.TinyInt, eld.LoanId);
                        db.AddInParameter(dbCommand, "AutoCalculated", SqlDbType.Bit, eld.AutoCalculated);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                               eld.Add ? "I" : (eld.Delete ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<SalaryDetail> getChanges(List<SalaryDetail> _details)
        {
            return (_details.Where(x => (x.Add && !x.Delete) || (x.Edit && !x.Delete) || x.Delete));
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}