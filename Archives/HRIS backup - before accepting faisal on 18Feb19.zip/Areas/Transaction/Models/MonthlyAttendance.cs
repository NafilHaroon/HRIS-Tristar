﻿using HRIS.Helper;
using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;



namespace HRIS.Areas.Transaction.Models
{
    public class MonthlyAttendance : IDisposable
    {
         #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Id")]
        public short? EmployeeId { get; set; }
        public short MonthNumber { get; set; }
        public string MonthName { get; set; }
        public int Year { get; set; }
        public List<MonthlyAttendanceDetail> Details { get; set; }
        public List<MonthlyAttendanceDetail> donotUseDetails { get; set; }
        #endregion

        #region constructor
        public MonthlyAttendance()
        {
            
            Details = new List<MonthlyAttendanceDetail>();
            donotUseDetails = new List<MonthlyAttendanceDetail>();
        }

        public MonthlyAttendance(short _EmployeeId, short _MonthNumber, string _MonthName, int _Year)
        {           
            EmployeeId = _EmployeeId;
            MonthNumber = _MonthNumber;
            MonthName = _MonthName;
            Year = _Year;
            Details = new List<MonthlyAttendanceDetail>();
            donotUseDetails = new List<MonthlyAttendanceDetail>();
        }
        #endregion

        #region internal methods
        internal static MonthlyAttendance getMonthlyAttendanceById(short _EmployeeId, short _MonthNumber, int _Year)
        {
            try
            {
                using (MonthlyAttendance _cd = new MonthlyAttendance())
                {
                    _cd.EmployeeId = _EmployeeId;
                    _cd.MonthNumber = _MonthNumber;
                    _cd.Year = _Year;
                    _cd.donotUseDetails = MonthlyAttendanceDetail.getDetailbyId(_EmployeeId, _MonthNumber, _Year);
                    _cd.Details = _cd.donotUseDetails.Clone();
                    return _cd;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(MonthlyAttendance _cd, string userid)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    MonthlyAttendanceDetail.Save(_cd.EmployeeId.Value, _cd.Details, _cd.donotUseDetails, transaction, userid);
                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }

    [DataContract]
    public class MonthlyAttendanceList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short MonthNumber { get; set; }
        public string MonthName { get; set; }
        public int Year { get; set; }

        #endregion

        #region constructor
        public MonthlyAttendanceList()
        {
        }

        public MonthlyAttendanceList(short _MonthNumber, string _MonthName, int _Year)
        {
            MonthNumber = _MonthNumber;
            MonthName = _MonthName;
            Year = _Year;

        }
        #endregion

        #region internal methods
        internal static List<MonthlyAttendanceList> getMonthlyAttendances()
        {
            return getMonthlyAttendanceList();
        }

        internal static DataTable GetDTMonthlyAttendances()
        {
            return AgilityHelper.ListToDataTable(getMonthlyAttendanceList());
        }
        #endregion

        #region private methods
        private static List<MonthlyAttendanceList> getMonthlyAttendanceList()
        {
            List<MonthlyAttendanceList> lstMonthlyAttendance = new List<MonthlyAttendanceList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetMonthYear"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstMonthlyAttendance.Add(new MonthlyAttendanceList(
                             Convert.ToInt16(dr["MonthNumber"]),
                                dr["MonthName"].ToString(),
                                Convert.ToInt32(dr["Year"])));
                        }
                    }
                }
            }
            return lstMonthlyAttendance;
        }

        internal static List<MonthlyAttendanceList> getSalaryMonthYearList()
        {
            List<MonthlyAttendanceList> lstMonthlyAttendance = new List<MonthlyAttendanceList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getSalaryMonthYear"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstMonthlyAttendance.Add(new MonthlyAttendanceList(
                             Convert.ToInt16(dr["MonthNumber"]),
                                dr["MonthName"].ToString(),
                                Convert.ToInt32(dr["Year"])));
                        }
                    }
                }
            }
            return lstMonthlyAttendance;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}