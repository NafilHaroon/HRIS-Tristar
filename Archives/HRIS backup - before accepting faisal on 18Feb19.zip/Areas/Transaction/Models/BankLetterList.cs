﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Transaction.Models
{
    public class BankLetterList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         [DataMember(Order = 0)]
         [Display(Name = "Letter #")]
         public short? LetterNumber { get; set; }
         [DataMember(Order = 1)]
         [Display(Name = "Letter Date")]
         public DateTime LetterDate { get; set; }
         [DataMember(Order = 2)]
         [Display(Name = "Bank")]
         public string  Bank { get; set; }
          [DataMember(Order = 3)]
         [Display(Name = "Salary Month")]
         public string  SalaryMonth { get; set; }
         [DataMember(Order = 4)]
         [Display(Name = "Salary Year")]
         public string  SalaryYear { get; set; }
         
        #endregion

        #region constructor
        public BankLetterList()
        {
        }

        public BankLetterList(short _LetterNumber, DateTime _LetterDate, string _Bank, string _SalaryMonth, string _SalaryYear)
        {
            LetterNumber = _LetterNumber;
            LetterDate = _LetterDate;
            Bank = _Bank;
            SalaryMonth = _SalaryMonth;
            SalaryYear = _SalaryYear;
           
        }
        #endregion

        #region internal methods
        internal static List<BankLetterList> Get()
        {
            return getBankLetters();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getBankLetters());
        }
        #endregion

        #region private methods
        private static List<BankLetterList> getBankLetters()
        {
            List<BankLetterList> lstdat = new List<BankLetterList>();

            DbCommand dbCommand = db.GetStoredProcCommand("getBankLetterList");
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new BankLetterList(
                              Convert.ToInt16(dr["LetterNumber"]),
                              Convert.ToDateTime(dr["LetterDate"]),
                                  dr["Bank"].ToString(),
                                  dr["SalaryMonth"].ToString(),
                                  dr["SalaryYear"].ToString()));
                    }
                }
            }
            return lstdat;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}