﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;



namespace HRIS.Areas.Transaction.Models
{
    public class BankLetterDetail : IDisposable, ICloneable
    {
         #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int? DetailId { get; set; }
        [Display(Name = "Employee")]
        public short? EmployeeId { get; set; }
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }
        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }
        [Display(Name = "Branch Name")]
        public string BranchName { get; set; }
        [Display(Name = "Department Name")]
        public string DepartmentName { get; set; }
        [Display(Name = "Grade Name")]
        public string GradeName { get; set; }
        [Display(Name = "Account #")]
        public string AccountNumber { get; set; }
        [Display(Name = "Amount")]
        public string Amount { get; set; }
        [Display(Name = "StopSalary")]
        public bool StopSalary { get; set; }
        [Display(Name = "Selected")]
        public bool Selected { get; set; }
        public string  Status { get; set; }
        #endregion

        #region constructor
        public BankLetterDetail()
        {
            DetailId = 0;
            Status ="Added";
        }

        public BankLetterDetail(bool _Selected, int _detailId,   short _EmployeeId, string _EmployeeCode, string _EmployeeName, string  _BranchName,
            string _DepartmentName, string _GradeName, string _AccountNumber, string  _Amount, bool _StopSalary,
            string _itemState ="UnChanged")
        {
            Selected = _Selected;
            DetailId = _detailId;
            EmployeeId = _EmployeeId;
            EmployeeCode = _EmployeeCode;
            EmployeeName = _EmployeeName;
            BranchName = _BranchName;
            DepartmentName = _DepartmentName;
            GradeName = _GradeName;
            AccountNumber = _AccountNumber;
            Amount = _Amount;
            StopSalary = _StopSalary;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<BankLetterDetail> getDetailbyId(short _letternumber, short _SalaryMonth, short _SalaryYear,
            short _BankId, short _comid, bool _OnlySelected,string  _userId)
        {
            try
            {
                List<BankLetterDetail> adjList = new List<BankLetterDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeesForBankLetter"))
                {
                    db.AddInParameter(dbCommand, "LetterNumber", SqlDbType.SmallInt, _letternumber);
                    db.AddInParameter(dbCommand, "SalaryMonth", SqlDbType.SmallInt,_SalaryMonth);
                    db.AddInParameter(dbCommand, "SalaryYear", SqlDbType.SmallInt, _SalaryYear);
                    db.AddInParameter(dbCommand, "BankId", SqlDbType.SmallInt, _BankId);
                    db.AddInParameter(dbCommand, "CompanyId", SqlDbType.SmallInt, _comid);
                    db.AddInParameter(dbCommand, "OnlySelected", SqlDbType.Bit, _OnlySelected);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                adjList.Add(new BankLetterDetail(
                                    Convert.ToBoolean(dr["Selected"]),
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["EmployeeId"]),
                                    dr["EmployeeCode"].ToString(),
                                     dr["EmployeeName"].ToString(),
                                      dr["BranchName"].ToString(),
                                       dr["DepartmentName"].ToString(),
                                        dr["GradeName"].ToString(),
                                         dr["BankAccountNumber"].ToString(),
                                        Convert.ToDouble(dr["Amount"]).ToString("###,###,##0.00"),
                                         Convert.ToBoolean(dr["StopSalary"])));
                            }
                        }
                    }
                }
                return adjList;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _letternumber, BankLetter _details, string UserId, DbTransaction _transaction)
        {
            try
            {
                foreach (BankLetterDetail _cdd in getCDDetailChanges(_details))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveBankLetterDetail"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, _cdd.DetailId);
                        db.AddInParameter(dbCommand, "Selected", SqlDbType.Bit, _cdd.Selected);
                        db.AddInParameter(dbCommand, "LetterNumber", SqlDbType.SmallInt, _letternumber);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _cdd.EmployeeId);
                        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, UserId);

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods

        private static IEnumerable<BankLetterDetail> getCDDetailChanges(BankLetter u)
        {
            return u.Details.Where(a => (a.Selected && a.DetailId==0) || (!a.Selected && a.DetailId>0));
        }

        //private static IEnumerable<BankLetterDetail> getCDDetailChanges(List<BankLetterDetail> details,
        //    List<BankLetterDetail> originalDetails)
        //{
        //    //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
        //    originalDetails.ForEach(o => o.Status = "Deleted");

        //    //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
        //    //items that were part of initial list but not present in current list
        //    IEnumerable<BankLetterDetail> editedItems = (IEnumerable<BankLetterDetail>)
        //            (from actualItem in details
        //             where AgilityHelper.InList(actualItem.Status,
        //                "Edited", "Added")
        //             select actualItem).Union(
        //                from actualItem in originalDetails
        //                where !
        //                (from newItem in details select newItem.DetailId).Contains(actualItem.DetailId)
        //                select actualItem);
        //    return editedItems.ToList<BankLetterDetail>();
        //}
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion

       
    }
}