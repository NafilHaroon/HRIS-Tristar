﻿using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Common;



namespace HRIS.Areas.Transaction.Models
{
    public class MonthlyLeave : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Id")]
        public short? EmployeeId { get; set; }
        public List<MonthlyLeaveDetail> Details { get; set; }
        #endregion

        #region constructor
        public MonthlyLeave()
        {
            Details = new List<MonthlyLeaveDetail>();
        }

        public MonthlyLeave(short _EmployeeId)
        {
            EmployeeId = _EmployeeId;
            Details = new List<MonthlyLeaveDetail>();
        }
        #endregion

        #region internal methods
        internal static MonthlyLeave getMonthlyLeaveById(short _EmployeeId)
        {
            try
            {
                using (MonthlyLeave _cd = new MonthlyLeave())
                {
                    _cd.EmployeeId = _EmployeeId;
                    _cd.Details = MonthlyLeaveDetail.getDetailbyId(_EmployeeId);
                    return _cd;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(MonthlyLeave _cd)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    MonthlyLeaveDetail.Save(_cd.EmployeeId.Value, _cd.Details, transaction);
                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}