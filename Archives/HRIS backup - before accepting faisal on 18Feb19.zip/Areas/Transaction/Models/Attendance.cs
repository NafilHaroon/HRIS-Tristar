﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Payroll.Areas.Transaction.Models
{
    public class Attendance
    {
    }
}