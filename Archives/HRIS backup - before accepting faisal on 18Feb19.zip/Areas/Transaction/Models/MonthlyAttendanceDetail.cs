﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;



namespace HRIS.Areas.Transaction.Models
{
    public class MonthlyAttendanceDetail : IDisposable, ICloneable
    {
         #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        [Display(Name = "AttendanceDate")]
        public DateTime? AttendanceDate { get; set; }
        [Display(Name = "Time In")]
        public DateTime? TimeIn { get; set; }
        [Display(Name = "Time Out")]
        public DateTime? TimeOut { get; set; }
        [Display(Name = "Official Visit")]
        public bool OfficialVisit { get; set; }        
        public string  Status { get; set; }
        #endregion

        #region constructor
        public MonthlyAttendanceDetail()
        {
            DetailId = 0;
            Status ="Added";
        }

        public MonthlyAttendanceDetail(int _detailId, DateTime _AttendanceDate,
            DateTime _TimeIn, DateTime _TimeOut, bool _OfficialVisit, 
            string _itemState ="UnChanged")
        {
            DetailId = _detailId;
            AttendanceDate = _AttendanceDate;
            TimeIn = _TimeIn;
            TimeOut = _TimeOut;
            OfficialVisit = _OfficialVisit;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<MonthlyAttendanceDetail> getDetailbyId(short _employeeid, short _monthnumber, int _year)
        {
            try
            {
                List<MonthlyAttendanceDetail> adjList = new List<MonthlyAttendanceDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetMonthlyAttendancebyEmployee"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _employeeid);
                    db.AddInParameter(dbCommand, "MonthNumber", SqlDbType.SmallInt, _monthnumber);
                    db.AddInParameter(dbCommand, "Year", SqlDbType.Int, _year);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                adjList.Add(new MonthlyAttendanceDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToDateTime(dr["AttendanceDate"]),
                                    Convert.ToDateTime(dr["TimeIn"]),
                                    Convert.ToDateTime(dr["TimeOut"]),
                                    Convert.ToBoolean(dr["OfficialVisit"])));
                            }
                        }
                    }
                }
                return adjList;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _employeeid, List<MonthlyAttendanceDetail> _details,
            List<MonthlyAttendanceDetail> _originalDetails, DbTransaction _transaction, string userid)
        {
            try
            {
                foreach (MonthlyAttendanceDetail _cdd in getCDDetailChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveMonthlyAttendance"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, _cdd.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _employeeid);
                        db.AddInParameter(dbCommand, "AttendanceDate", SqlDbType.DateTime, _cdd.AttendanceDate);
                        db.AddInParameter(dbCommand, "TimeIn", SqlDbType.DateTime, _cdd.TimeIn);
                        db.AddInParameter(dbCommand, "TimeOut", SqlDbType.DateTime, _cdd.TimeOut);
                        db.AddInParameter(dbCommand, "OfficialVisit", SqlDbType.Bit, _cdd.OfficialVisit);
                        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, userid);
                       
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                        _cdd.Status == "Added" ? "I" : (
                        _cdd.Status == "Deleted" ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<MonthlyAttendanceDetail> getCDDetailChanges(List<MonthlyAttendanceDetail> details,
            List<MonthlyAttendanceDetail> originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<MonthlyAttendanceDetail> editedItems = (IEnumerable<MonthlyAttendanceDetail>)
                    (from actualItem in details
                     where AgilityHelper.InList(actualItem.Status,
                        "Edited", "Added")
                     select actualItem).Union(
                        from actualItem in originalDetails
                        where !
                        (from newItem in details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<MonthlyAttendanceDetail>();
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion

     
    }
}