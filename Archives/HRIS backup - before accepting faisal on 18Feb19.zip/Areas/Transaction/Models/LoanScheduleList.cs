﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Transaction.Models
{
    public class LoanScheduleList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         [DataMember(Order = 0)]
         [Display(Name = "Loan Id")]
         public short LoanId { get; set; }
         [DataMember(Order = 1)]
         [Display(Name = "StartingDate")]
         public string StartingDate { get; set; }
         [DataMember(Order = 3)]
         [Display(Name = "Employee Name")]
         public string EmployeeName { get; set; }
         
        #endregion

        #region constructor
        public LoanScheduleList()
        {
        }

        public LoanScheduleList(short _LoanId, string _StartingDate, string _EmployeeName)
        {
            LoanId = _LoanId;
            StartingDate = _StartingDate;
            EmployeeName = _EmployeeName;
           
        }
        #endregion

        #region internal methods
        internal static List<LoanScheduleList> Get(string _userId, bool _isActive = true)
        {
            return getLoanScheduleLists(_userId, _isActive);
        }

        //internal static DataTable GetDTLoanSchedules(bool _ActiveOnly, string _userId)
        //{
        //    return AgilityHelper.ListToDataTable(getLoanScheduleLists(_ActiveOnly, _userId));
        //}
        #endregion

        #region private methods
        private static List<LoanScheduleList> getLoanScheduleLists(string _userId, bool _isActive)
        {
            List<LoanScheduleList> lstdat = new List<LoanScheduleList>();

            DbCommand dbCommand = db.GetStoredProcCommand("getLoanScheduleList");
            db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _isActive);
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new LoanScheduleList(
                              Convert.ToInt16(dr["LoanId"]),
                                dr["StartingDate"].ToString(),
                                  dr["EmployeeName"].ToString()));
                    }
                }
            }
            return lstdat;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}