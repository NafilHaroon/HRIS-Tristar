﻿using HRIS.Areas.Common.Models;
using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Transaction.Models
{
    public class BankLetter : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Letter #")]
        public short? LetterNumber { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Letter Date")]
        public DateTime LetterDate { get; set; }
        [Display(Name = "Bank")]
        public short? BankId { get; set; }
        [Display(Name = "Salary Month")]
        public short? SalaryMonth { get; set; }
        [Display(Name = "Salary Year")]
        public short? SalaryYear { get; set; }
        public short MonthNumber { get; set; }
        [Display(Name = "Remarks")]
        public string Remarks { get; set; }
        public List<BankLetterDetail> Details { get; set; }
        public List<BankLetterDetail> donotUseDetails { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region constructor
        public BankLetter()
        {
            AuditTrail = new Footer();
            LetterDate = DateTime.Now;
            LetterNumber = 0;
            Details = new List<BankLetterDetail>();
            donotUseDetails = new List<BankLetterDetail>();
        }


        #endregion

        #region internal methods
        internal static BankLetter getBankLetterById(short _letterNo, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetBankLetter"))
                {
                    db.AddInParameter(dbCommand, "LetterNumber", SqlDbType.SmallInt, _letterNo);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                        {
                            using (BankLetter _bl = new BankLetter())
                            {
                                DataRow dr = ds.Tables[0].Rows[0];
                                _bl.LetterNumber = _letterNo;
                                _bl.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                                _bl.LetterDate = Convert.ToDateTime(dr["LetterDate"]);
                                _bl.BankId = Convert.ToInt16(dr["BankId"]);
                                _bl.SalaryMonth = Convert.ToInt16(dr["SalaryMonth"]);
                                _bl.SalaryYear = Convert.ToInt16(dr["SalaryYear"]);
                                _bl.Remarks = dr["Remarks"].ToString();
                                _bl.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                                _bl.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                                _bl.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                                if (dr["UpdatedOn"] != DBNull.Value)
                                _bl.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                                _bl.donotUseDetails = BankLetterDetail.getDetailbyId(_letterNo, Convert.ToInt16(_bl.SalaryMonth), Convert.ToInt16(_bl.SalaryYear),
                                       Convert.ToInt16(_bl.BankId), Convert.ToInt16(_bl.CompanyId),  true, _userId);
                                _bl.Details = _bl.donotUseDetails.Clone();


                                return _bl;
                            }
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(BankLetter _bl, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveBankLetter"))
            {

                db.AddInParameter(dbCommand, "LetterNumber", SqlDbType.SmallInt, _bl.LetterNumber);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.SmallInt, _bl.CompanyId);
                db.AddInParameter(dbCommand, "LetterDate", SqlDbType.DateTime, _bl.LetterDate);
                db.AddInParameter(dbCommand, "BankId", SqlDbType.SmallInt, _bl.BankId);
                db.AddInParameter(dbCommand, "SalaryMonth", SqlDbType.SmallInt, _bl.SalaryMonth);
                db.AddInParameter(dbCommand, "SalaryYear", SqlDbType.SmallInt, _bl.SalaryYear);
                db.AddInParameter(dbCommand, "Remarks", SqlDbType.VarChar, _bl.Remarks);

                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddOutParameter(dbCommand, "NewLetterNumber", SqlDbType.SmallInt, 32);
                db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _bl.AuditTrail.UpdatedOn);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        _bl.LetterNumber = Convert.ToInt16(dbCommand.Parameters["@NewLetterNumber"].Value);


                        BankLetterDetail.Save(_bl.LetterNumber.Value, _bl, _userId, transaction);

                        _bl.Details.ForEach(o => o.Status = "UnChanged");
                        _bl.donotUseDetails = _bl.Details.Clone();

                        transaction.Commit();
                        return true;
                    }

                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }            
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}