﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;



namespace HRIS.Areas.Transaction.Models
{
    public class MonthlyLeaveDetail : IDisposable, ICloneable, IValidatableObject
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        [Display(Name = "Leave")]
        public short? LeaveTypeId { get; set; }     
        [Display(Name = "Date From")]
        public DateTime? DateFrom { get; set; }
        [Display(Name = "Date To")]
        public DateTime? DateTo { get; set; }
        [Display(Name = "Half Day")]
        public bool HalfDay { get; set; }
        [Display(Name = "Reason")]
        public string Reason { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        #endregion

        #region constructor
        public MonthlyLeaveDetail()
        {
            DetailId = -1;
            DateFrom = DateTime.Now;
            DateTo = DateTime.Now.AddDays(30);
            Add = true; Edit = false; Delete = false;
        }

        public MonthlyLeaveDetail(int _detailId, short _LeaveTypeId,
            DateTime _dateFrom, DateTime _dateTo, bool _HalfDay, string _Reason)
        {
            DetailId = _detailId;
            LeaveTypeId = _LeaveTypeId;
            DateFrom = _dateFrom;
            DateTo = _dateTo;
            HalfDay = _HalfDay;
            Reason=_Reason;
            Add = false; Edit = false; Delete = false;
        }
        #endregion

        #region internal methods
        internal static List<MonthlyLeaveDetail> getDetailbyId(short _employeeid)
        {
            try
            {
                List<MonthlyLeaveDetail> adjList = new List<MonthlyLeaveDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetMonthlyLeavebyEmployee"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _employeeid);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                adjList.Add(new MonthlyLeaveDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["LeaveTypeId"]),
                                    Convert.ToDateTime(dr["DateFrom"]),
                                    Convert.ToDateTime(dr["DateTo"]),
                                    Convert.ToBoolean(dr["HalfDay"]),                                   
                                    dr["Reason"].ToString()));
                            }
                        }
                    }
                }
                return adjList;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _employeeid, List<MonthlyLeaveDetail> _details, DbTransaction _transaction)
        {
            try
            {
                foreach (MonthlyLeaveDetail _cdd in getCDDetailChanges(_details))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveMonthlyLeave"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, _cdd.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _employeeid);
                        db.AddInParameter(dbCommand, "LeaveTypeId", SqlDbType.SmallInt, _cdd.LeaveTypeId);
                        db.AddInParameter(dbCommand, "DateFrom", SqlDbType.DateTime, _cdd.DateFrom);
                        db.AddInParameter(dbCommand, "DateTo", SqlDbType.DateTime, _cdd.DateTo);
                        db.AddInParameter(dbCommand, "HalfDay", SqlDbType.Bit, _cdd.HalfDay);
                        db.AddInParameter(dbCommand, "Reason", SqlDbType.VarChar, _cdd.Reason);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                           _cdd.Add ? "I" : (_cdd.Delete ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<MonthlyLeaveDetail> getCDDetailChanges(List<MonthlyLeaveDetail> _details)
        {
            return (_details.Where(x => (x.Add && !x.Delete) || (x.Edit && !x.Delete) || x.Delete));
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            List<ValidationResult> res = new List<ValidationResult>();
            if (DateTo.Value.Date < DateFrom.Value.Date)
            {
                res.Add(new ValidationResult("Date To must always be newer than or equal to Date From", new string[] { "DateTo" }));
            }
            return res;
        }
    }
}