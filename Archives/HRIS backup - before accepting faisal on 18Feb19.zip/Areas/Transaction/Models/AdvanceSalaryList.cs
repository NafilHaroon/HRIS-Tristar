﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Transaction.Models
{
    public class AdvanceSalaryList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         [DataMember(Order = 0)]
         [Display(Name = "Advance #")]
         public short AdvanceId { get; set; }
         [DataMember(Order = 1)]
         [Display(Name = "Advance Date")]
         public string AdvanceDate { get; set; }
         [DataMember(Order = 3)]
         [Display(Name = "Employee Name")]
         public string EmployeeName { get; set; }
         
        #endregion

        #region constructor
        public AdvanceSalaryList()
        {
        }

        public AdvanceSalaryList(short _AdvanceId, string _AdvanceDate, string _EmployeeName)
        {
            AdvanceId = _AdvanceId;
            AdvanceDate = _AdvanceDate;
            EmployeeName = _EmployeeName;
           
        }
        #endregion

        #region internal methods
        internal static List<AdvanceSalaryList> Get(string _userId)
        {
            return getAdvanceSalaries(_userId);
        }

        //internal static DataTable GetDT(string _userId)
        //{
        //    return AgilityHelper.ListToDataTable(getAdvanceSalaries(_userId));
        //}
        #endregion

        #region private methods
        private static List<AdvanceSalaryList> getAdvanceSalaries(string _userId)
        {
            List<AdvanceSalaryList> lstdat = new List<AdvanceSalaryList>();

            DbCommand dbCommand = db.GetStoredProcCommand("getAdvanceSalaryList");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new AdvanceSalaryList(
                              Convert.ToInt16(dr["AdvanceId"]),
                                dr["AdvanceDate"].ToString(),
                                  dr["EmployeeName"].ToString()));
                    }
                }
            }
            return lstdat;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}