﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class LoanScheduleController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                LoanSchedule _ls = new LoanSchedule();
                ModelState.Clear();
                return Json(new { success = true, LoanSchedule = _ls, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(LoanSchedule _ls)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_ls);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (LoanSchedule.Save(_ls, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                LoanSchedule _ls = LoanSchedule.Get(_keyId, Session["UserId"].ToString());
                if (_ls == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Loan Schedule Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, LoanSchedule = _ls, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new LoanScheduleList()),
                    rowData = LoanScheduleList.Get(Session["UserId"].ToString())
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetLookups()
        {
            return Json(EmployeeList.Get(Session["UserId"], Session["CompanyId"]), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Loan Schedule'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(LoanSchedule _ls)
        {
            if (!_ls.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if (!_ls.StartingDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Starting Date"));

            if (string.IsNullOrEmpty(_ls.Remarks))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Remarks"));

            if (_ls.LoanAmount <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Loan Amount"));

            if (!_ls.LoanPeriod.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Loan Period"));

            if (_ls.LoanPeriod <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Loan Period"));
        }
        #endregion
    }
}

