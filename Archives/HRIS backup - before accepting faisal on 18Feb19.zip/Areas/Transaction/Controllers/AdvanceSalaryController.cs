﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class AdvanceSalaryController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                AdvanceSalary _as = new AdvanceSalary();
                ModelState.Clear();
                return Json(new { success = true, AdvanceSalary = _as, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(AdvanceSalary _as)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_as);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (AdvanceSalary.Save(_as, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                AdvanceSalary _as = AdvanceSalary.Get(_keyId);
                if (_as == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Advance Salary Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, AdvanceSalary = _as, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new AdvanceSalaryList()),
                    rowData = AdvanceSalaryList.Get(Session["UserId"].ToString())
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetLookups()
        {
            return Json(EmployeeList.Get(Session["UserId"], Session["CompanyId"]), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Advance Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(AdvanceSalary _as)
        {
            if (_as.AdvanceId > 0)
                ModelState.AddModelError("Validation", "=> No further changes can be made to this Advance Salary");

            if (!_as.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if (!_as.AdvanceDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Advance Date"));

            if (string.IsNullOrEmpty(_as.Description))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Description"));

            if (_as.Amount <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Amount"));
        }
        #endregion
    }
}

