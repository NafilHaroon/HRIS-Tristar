﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class MonthlyLeaveController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save(MonthlyLeave _ml)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_ml);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (MonthlyLeave.Save(_ml))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                MonthlyLeave _ml = MonthlyLeave.getMonthlyLeaveById(_keyId);

                if (_ml == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Monthly Leave  doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, MonthlyLeave = _ml, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new EmployeeList()),
                    rowData = EmployeeList.Get(Session["UserId"].ToString(), Convert.ToInt16(Session["CompanyId"]))
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    success = true,
                    lstEmployee = EmployeeList.Get(Session["UserId"], Convert.ToInt16(Session["CompanyId"])),
                    lstLeaveType = LeaveTypeList.Get(true),
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Monthly Leave'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(MonthlyLeave _ml)
        {
            if (!_ml.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if (_ml.Details.Count > 0)
            {
                if (_ml.Details.Where(x => !x.LeaveTypeId.HasValue).Any())
                    ModelState.AddModelError("Validation", "=> Leave line must have Leave Selected!");

                if (_ml.Details.Where(x => !x.DateFrom.HasValue & !x.DateTo.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Validity From & To"));

                else if (_ml.Details.Where(x => x.DateFrom.Value.Date > x.DateTo.Value.Date).Any())
                    ModelState.AddModelError("Validation", "=> Date From for  must always be older than Date To");

                if (_ml.Details.GroupBy(x => new { x.LeaveTypeId, x.DateFrom }).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> The combination of Leave & Date From must be unique for each Row");

                if (_ml.Details.Where(x => string.IsNullOrWhiteSpace(x.Reason)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Reason"));
            }
        }
        #endregion
    }
}

