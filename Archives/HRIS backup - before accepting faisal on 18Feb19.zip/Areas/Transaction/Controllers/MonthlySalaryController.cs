﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class MonthlySalaryController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                MonthlySalary _as = new MonthlySalary();
                ModelState.Clear();
                return Json(new { success = true, MonthlySalary = _as, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(MonthlySalary _as)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_as);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (MonthlySalary.Save(_as, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(short _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                MonthlySalary _as = MonthlySalary.Get(_keyId);
                if (_as == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Monthly Salary Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, MonthlySalary = _as, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new MonthlySalaryList()),
                    rowData = MonthlySalaryList.Get(Session["UserId"].ToString())
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult Delete(short _keyId)
        {
            try
            {
                if (Convert.ToBoolean(Session["AllowDelete"]))
                {
                    if (MonthlySalary.Delete(_keyId))
                    {
                        TempData["alertMessage"] = "Employee Id " + _keyId + " deleted successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    }
                }
                return Json(new { success = true, errorMsg = string.Empty }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    success = true,
                    lstEmployee = EmployeeList.Get(Session["UserId"].ToString(), Convert.ToInt16(Session["CompanyId"])),
                    lstAssetType = AssetTypeList.Get(),
                    lstSalaryHead = SalaryHeadList.Get(true),
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Current Month Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(MonthlySalary _as)
        {
            if (!_as.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if (_as.LeavesDays > _as.MonthDays)
                ModelState.AddModelError("Validation", "Leave days can't be more than total days in the month");

            if (_as.AbsentDays > _as.MonthDays)
                ModelState.AddModelError("Validation", "Absent days can't be more than total days in the month");

            else if (_as.Asset.Where(x => !x.AssetId.HasValue).Any())
                ModelState.AddModelError("Validation", "=> Employee Asset  must have Aseet Selected!");

            else if (_as.Salary.Where(x => !x.HeadId.HasValue).Any())
                ModelState.AddModelError("Validation", "=> Employee Salary  must have Salary Head Selected!");

            else if (_as.Salary.Where(x => x.Amount <= 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Amount"));

            else if (_as.Asset.Where(x => x.Limit <= 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Limit"));

            else if (_as.Asset.GroupBy(x => x.AssetId).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Asset  used in  Monthly Company Asset must be unique");

            else if (_as.Salary.GroupBy(x => new { x.HeadId, x.LoanId }).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Head and Loan  used in  Monthly Salary must be unique");
        }
        #endregion
    }
}

