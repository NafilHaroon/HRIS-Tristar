﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class MonthlyAttendanceController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, MonthlyAttendance _em)
        {
            return View();
        }
                

        [HttpPost]
        public JsonResult Save(MonthlyAttendance e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (MonthlyAttendance.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short employeeid, short monthnum, int year)
        {
            var msg = new Object();
            try
            {

                MonthlyAttendance cn = MonthlyAttendance.getMonthlyAttendanceById(employeeid, monthnum, year);
             

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            MonthlyAttendance e = new MonthlyAttendance();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

     
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region lookup methods
        private void populateLUSessions()
        {            
         
            Session["lstEmployee"] = EmployeeList.GetShortInfo(Session["UserId"], Session["CompanyId"]);
            Session["lstMonthYear"] = MonthlyAttendanceList.getSalaryMonthYearList();
        
        }
        #endregion

        #region Json Method
        public JsonResult GetAllowedEmployee()
        {
            return Json((List<EmployeeList>)Session["lstEmployee"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMonth()
        {
            return Json((List<MonthlyAttendanceList>)Session["lstMonthYear"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetYear()
        {
            List<MonthlyAttendanceList> mcDetails = new List<MonthlyAttendanceList>();
            mcDetails = (List<MonthlyAttendanceList>)Session["lstMonthYear"];


            var result = mcDetails.GroupBy(test => test.Year)
                   .Select(grp => grp.First())
                   .ToList();

            return Json((List<MonthlyAttendanceList>)result, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region private methods

        

        private void clearSessions()
        {
            Session.Remove("lstEmployee");
            Session.Remove("lstMonthYear");

        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Monthly Attendance'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        private void validate(MonthlyAttendance e)
        {
            if (!e.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Employee"));

            if(e.Details.Count>0)
            {

                 if (e.Details.Where(x => x.TimeIn.Value > x.TimeOut.Value).Any())
                    ModelState.AddModelError("Validation", "=> Time In   must always be older than Time out");

                if (e.Details.GroupBy(x => x.AttendanceDate).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Attendance Date  used in Monthly Attendance must be unique");

            }
        }

        #endregion

    }
}
