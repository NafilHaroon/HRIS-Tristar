﻿$(document).ready(function () {    
    $("#btnEdit").click(function () {
        setNoFindFormControls("Edit");
        setDropDown("Edit");
    });
    
    $('#AttendanceDate').datepicker();
    $('#TimeIn').timepicker();
    $('#TimeOut').timepicker();
   
    //$('body').on('focus', ".mydatepicker", function () {
    //    $(this).datepicker();
    //});

    //$('body').on('focus', ".mytimepicker", function () {

    //    $(this).timepicker();
    //});
});



function setDropDown(formMode) {
    if (formMode == "Recall") {
        document.getElementById("ddemp").disabled = false;
        document.getElementById("ddmonth").disabled = false;
        document.getElementById("ddyear").disabled = false;
        document.getElementById("btnLoad").disabled = false;
    }
    else {
        document.getElementById("ddemp").disabled = true;
        document.getElementById("ddmonth").disabled = true;
        document.getElementById("ddyear").disabled = true;
        document.getElementById("btnLoad").disabled = true;
    }
}



function validate(emp, mon, year) {

    if (emp == "") {
        alert("Please select Employee before hitting load button");
        return false;
    }

    if (mon == "") {
        alert("Please select month before hitting load button");
        return false;
    }

    else if (year == "") {
        alert("Please select Year before hitting load button");
        return false;
    }
    else
        return true;
};

var app = angular.module('HRIS', []);

app.controller('MonthlyAttendanceController', function ($scope, $http, $window) {

    $scope.load = function () {

        //var id = document.getElementById('txtReferenceNo').value;
        //if (id > 0)
        //    $scope.GetData(id);
        LoadDropDown();
    };
    
    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/MonthlyAttendance/Save",
            data: $scope.MonthlyAttendance
        }).success(function (result) {

            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.MonthlyAttendance = result.data;
      
            }
            else {
                alert(result.Message);
                $scope.MonthlyAttendance = {};
            }
            setNoFindFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    } 

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/MonthlyAttendance/Undo"
        }).success(function (result) {
            $scope.MonthlyAttendance = [];
            $scope.errors = [];
            setNoFindFormControls(result.Session);
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/MonthlyAttendance/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }   

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/MonthlyAttendance/Recall"
        }).success(function (result) {
           $scope.errors = [];
           setNoFindFormControls(result.Session);
           setDropDown("Recall");
           //LoadDropDown();
        }).catch(function (result) {

        });
    }

    //$scope.Add = function () {
    //    $http({
    //        method: "POST",
    //        url: "/MonthlyAttendance/Add"
    //    }).success(function (result) {
    //        $scope.errors = [];
    //        $scope.MonthlyAttendance = result.data;
            
    //        setNoFindFormControls(result.Session);
    //    }).catch(function (result) {

    //    });
    //}

   
    $scope.GetMontlyAttendance = function () {
        var emp = document.getElementById("ddemp").value;
        var mon = document.getElementById("ddmonth").value;
        var year = document.getElementById("ddyear").value;
        var isValid = validate(emp, mon, year);
        if (isValid == true) {
       
            $http({
                method: "POST",
                url: "/MonthlyAttendance/Get",
                data: { employeeid: emp, monthnum: mon, year: year },
            }).success(function (result) {
               
                $scope.errors = [];
                $scope.MonthlyAttendance = {};
                if (result.success == false) {
                    $scope.errors = [
                       result.Message]
                }
                else {
                    $scope.MonthlyAttendance = result.data;                                            
                }

                setNoFindFormControls(result.Session);
                setDropDown(result.Session);
                ConvertDate();
                //LoadDropDown();
            }).catch(function (result) {
                alert(result);
            });
        }
    }


        //$scope.toggleEdit = function (m) {
        //    m.showEdit = m.showEdit ? false : true;
        //}


        //$scope.AddMA = function () {
        //    //Add the new item to the Array.
        //    $scope.AttendanceDate = document.getElementById('AttendanceDate').value;
        //    $scope.TimeIn = document.getElementById('TimeIn').value;
        //    $scope.TimeOut = document.getElementById('TimeOut').value;

        //    if ($scope.AttendanceDate != undefined && $scope.TimeIn != undefined && $scope.TimeOut != undefined &&
        //       $scope.AttendanceDate != "" && $scope.TimeIn != "" && $scope.TimeOut != "") {

        //        var detailid;
        //        var ma = {};
        //        Math.max.apply(Math, $scope.MonthlyAttendance.Details.map(function (ques) { detailid = ques.DetailId; }))
        //        detailid = (detailid === undefined) ? 0 : detailid;
        //        ma.AttendanceDate = $scope.AttendanceDate;
        //        ma.TimeIn = $scope.TimeIn;
        //        ma.TimeOut = $scope.TimeOut;
        //        ma.OfficialVisit = $scope.OfficialVisit;
        //        ma.DetailId = detailid + 1;
        //        ma.showEdit = false;
        //        ma.status = "Added";
        //        $scope.MonthlyAttendance.Details.push(ma);

        //        //Clear the TextBoxes.
        //        $scope.AttendanceDate = "";
        //        $scope.TimeIn = "";
        //        $scope.TimeOut = "";
        //        $scope.OfficalVisit = false;

        //    }
        //}
        $scope.AddMA = function () {
            var OV ;
            //Add the new item to the Array.
           var AD = document.getElementById('AttendanceDate').value;
           var TI = document.getElementById('TimeIn').value;
           var TD = document.getElementById('TimeOut').value;
           var DID = document.getElementById('DetailId').value;
           var OV = document.getElementById("OfficialVisit").checked;
           var ST = document.getElementById('Status').value;
           var Index = document.getElementById('Row').value;
           DID = (DID === "") ? 0 : DID;
            if (AD != "" && TI != "" && TD != "") {

                var detailid;
                var ma = {};
              
                //Math.max.apply(Math, $scope.MonthlyAttendance.Details.map(function (ques) { detailid = ques.DetailId; }))
                //detailid = (detailid === undefined) ? 0 : detailid;
                if (Index != "")
                    $scope.MonthlyAttendance.Details.splice(Index, 1);
                ma.Status = DID <= 0 ? "Added" : "Edited";
                if (DID == 0)
                    ma.DetailId = -1;
                else {
                    ma.DetailId = DID;
                }
                ma.AttendanceDate = AD;
                ma.TimeIn = TI;
                ma.TimeOut = TD;
                ma.OfficialVisit = OV;
                //if (ST == "UnChanged") {
                //    ma.Status = "Edited";
                // }
                // else {
                //    ma.Status = "Added";
                //}
                
                //if (DID != 0)
                //{
                //    ma.DetailId = DID;
                //    $scope.MonthlyAttendance.Details.splice(Index, 1);
                //}
                //else
                //{
                //    ma.DetailId = detailid + 1;
                //}
                $scope.MonthlyAttendance.Details.push(ma);
                $scope.Clear();
                ma = {};
            }
            else {
                alert("Please Selct Valid Date , Time in and Time Out. Before saving value in Grid. ");
            }
        }

        $scope.Clear = function () {           
                //Clear the TextBoxes.
             document.getElementById('AttendanceDate').value = "";
             document.getElementById('TimeIn').value = "";
             document.getElementById('TimeOut').value = "";
             document.getElementById("OfficialVisit").checked = false;
             document.getElementById('DetailId').value = "";
             document.getElementById('Status').value = "";
             document.getElementById('Row').value = "";
        }

        $scope.EditMA = function (m, index) {

            document.getElementById('AttendanceDate').value = m.AttendanceDate;
            document.getElementById('TimeIn').value = m.TimeIn;
            document.getElementById('TimeOut').value = m.TimeOut;         
            document.getElementById("OfficialVisit").checked = m.OfficialVisit;
            document.getElementById('DetailId').value = m.DetailId;
            document.getElementById('Status').value = m.Status;
            document.getElementById('Row').value = index;

            
            //m.AttendanceDate = document.getElementById('AD').value;
            //m.TimeIn = document.getElementById('TI').value;
            //m.TimeOut = document.getElementById('TO').value;

            //    //Add the new item to the Array.
            //    if (m.AttendanceDate != "" && m.TimeIn != "" && m.TimeOut != "") {
            //        var ma = {};
            //        $scope.MonthlyAttendance.Details.splice(index, 1);
            //        ma.AttendanceDate = m.AttendanceDate;
            //        ma.TimeIn = m.TimeIn;
            //        ma.TimeOut = m.TimeOut;
            //        ma.OfficialVisit = m.OfficialVisit;
            //        ma.DetailId = m.DetailId;
            //        if (ma.status == "UnChanged") {
            //            ma.status = "Edited";
            //        }
            //        else {
            //            ma.status = "Added";
            //        }
            //        ma.status = "Edited";
            //        $scope.MonthlyAttendance.Details.push(ma);

            //        $scope.AttendanceDate = "";
            //        $scope.TimeIn = "";
            //        $scope.TimeOut = "";
            //        $scope.OfficalVisit = false;
            //    }

            }
            $scope.RemoveMA = function (index) {
                //Find the record using Index from Array.
                //var CC = $scope.MonthlyAttendance.Details[index].DetailId;
                if ($window.confirm("Do you want to delete: " )) {
                    //Remove the item from Array using Index.
                    $scope.MonthlyAttendance.Details.splice(index, 1);
                }
            }

            function LoadDropDown() {
                $http.get('/MonthlyAttendance/GetAllowedEmployee').then(function (d) {
                    $scope.Employeelist = d.data;
                }, function () {
                    alert('failed');
                });

                $http.get('/MonthlyAttendance/GetMonth').then(function (d) {
                    $scope.Monthlist = d.data;
                }, function () {
                    alert('failed');
                });


                $http.get('/MonthlyAttendance/GetYear').then(function (d) {
                    $scope.Yearlist = d.data;
                }, function () {
                    alert('failed');
                });

            }

            function ConvertDate() {

                for (i = 0; i < $scope.MonthlyAttendance.Details.length; i++) {
                    if ($scope.MonthlyAttendance.Details[i]["AttendanceDate"] != null)
                        $scope.MonthlyAttendance.Details[i]["AttendanceDate"] = formattingdate($scope.MonthlyAttendance.Details[i]["AttendanceDate"]);

                    if ($scope.MonthlyAttendance.Details[i]["TimeIn"] != null)
                        $scope.MonthlyAttendance.Details[i]["TimeIn"] = formattingTime($scope.MonthlyAttendance.Details[i]["TimeIn"]);

                    if ($scope.MonthlyAttendance.Details[i]["TimeOut"] != null)
                        $scope.MonthlyAttendance.Details[i]["TimeOut"] = formattingTime($scope.MonthlyAttendance.Details[i]["TimeOut"]);
                }

                for (i = 0; i < $scope.MonthlyAttendance.donotUseDetails.length; i++) {
                    if ($scope.MonthlyAttendance.donotUseDetails[i]["AttendanceDate"] != null)
                        $scope.MonthlyAttendance.donotUseDetails[i]["AttendanceDate"] = formattingdate($scope.MonthlyAttendance.donotUseDetails[i]["AttendanceDate"]);

                    if ($scope.MonthlyAttendance.donotUseDetails[i]["TimeIn"] != null)
                        $scope.MonthlyAttendance.donotUseDetails[i]["TimeIn"] = formattingTime($scope.MonthlyAttendance.donotUseDetails[i]["TimeIn"]);

                    if ($scope.MonthlyAttendance.donotUseDetails[i]["TimeOut"] != null)
                        $scope.MonthlyAttendance.donotUseDetails[i]["TimeOut"] = formattingTime($scope.MonthlyAttendance.donotUseDetails[i]["TimeOut"]);
                }

                if ($scope.MonthlyAttendance.AuditTrail.CreatedOn != null) {
                    $scope.MonthlyAttendance.AuditTrail.CreatedOn = formattingDateTime($scope.MonthlyAttendance.AuditTrail.CreatedOn);
                }
                if ($scope.MonthlyAttendance.AuditTrail.UpdatedOn != null) {
                    $scope.MonthlyAttendance.AuditTrail.UpdatedOn = formattingDateTime($scope.MonthlyAttendance.AuditTrail.UpdatedOn);
                }
            }

       
});