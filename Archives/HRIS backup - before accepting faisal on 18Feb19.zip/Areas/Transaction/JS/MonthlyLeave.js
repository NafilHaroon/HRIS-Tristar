﻿baseURL = "/HRIS/Transaction/MonthlyLeave/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        //document.getElementById('ddEmployee').disabled = true;
        //document.getElementById("btnLoad").disabled = true;
       // $('#btnLoad').focus();
    });
});

app.controller('MonthlyLeaveController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstEmployee = result.data.lstEmployee;
            $scope.lstLeaveType = result.data.lstLeaveType;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    //#endregion

    //#region toolbar actions


    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#ddEmployee').focus();
    };

    $scope.tbSave = function () {
        $scope.MonthlyLeave.Details = getMonthlyLeaveDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.MonthlyLeave
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);                
                clearForm();
                setGridData();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Employee";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getMonthlyLeaveById($rootScope.SelectedRow.EmployeeId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbUndo = function () {
        clearForm();
        setGridData();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    
    //#endregion

    //#region form functions
    $scope.getMonthlyLeaveById = function (_EmpId) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: _EmpId }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.MonthlyLeave = result.data.MonthlyLeave;
               
            }
            setFormControls(result.data.session);
            maskDates();
            setGridData();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.MonthlyLeave = {};
        $scope.errors = [];
    }    

    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.MonthlyLeave.Details != null) {
            for (i = 0; i < $scope.MonthlyLeave.Details.length; i++) {
                $scope.MonthlyLeave.Details[i]["DateFrom"] = formatDate($scope.MonthlyLeave.Details[i]["DateFrom"]);
                $scope.MonthlyLeave.Details[i]["DateTo"] = formatDate($scope.MonthlyLeave.Details[i]["DateTo"]);
            }
        }
    }
    //#endregion

    //#region grid setup
    //#region Monthly Leave Grid Definition & functions
    var colMonthlyLeave = [
        {
            headerName: "Leave Type", field: "LeaveTypeId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'LeaveType', class: "agGridSelect130" },
            valueFormatter: getLeaveTypeName, width: 130
        },    
        {
            headerName: "Reason", field: "Reason", cellEditor: "agTextCellEditor",
            width: 200
        },
        {
            headerName: "DateFrom", field: "DateFrom", width: 125,
             cellEditor: 'datePicker',
            cellEditorParams: { minDate: '-30Y', maxDate: '+0d' }
        },
        {
            headerName: "DateTo", field: "DateTo", width: 125,
            cellEditor: 'datePicker',
            cellEditorParams: { minDate: '-0Y', maxDate: '+30d' }
        },
        {
            headerName: 'Half Day', field: 'HalfDay', width: 60,
            cellRenderer: params => {
                if (params.value) {
                    return "<input type='checkbox' checked />";
                }
                else {
                    return "<input type='checkbox'/>";
                }
            },
            cellEditor: "agilityCheckBoxEditor"
        },
        
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true }
    ];

   

    $scope.grdOptMonthlyLeave = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colMonthlyLeave,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        //stopEditingWhenGridLosesFocus: true,
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect(),
            datePicker: getDatePicker(),
            agilityCheckBoxEditor: getCellCheckBox()
        }
    };

    function getMonthlyLeaveDataFromGrid() {
        let rowData = [];
        $scope.grdOptMonthlyLeave.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddMonthlyLeave = function () {
        try {
            var res = $scope.grdOptMonthlyLeave.api.updateRowData({
                add: [{
                    LeaveTypeId: null, DateFrom: "", DateTo: "",
                    HalfDay: false, Reason: null, Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptMonthlyLeave.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "LeaveTypeId" });
        }
        catch (exception) { alert('Add Montly Leave: ' + exception); }
    };

    $scope.onDeleteMonthlyLeave = function () {
        try {
            if ($scope.grdOptMonthlyLeave.api.getSelectedRows().length > 0) {
                if (confirm("Are you sure you want to Delete selected row?")) {
                    $scope.grdOptMonthlyLeave.api.getSelectedRows().forEach(x => x.Delete = true);
                    $scope.grdOptMonthlyLeave.api.getFilterInstance('Delete').onFilterChanged();
                }
            }
            else
                alert("No Row selected to apply Delete operation. Please select row and then hit Delete button!");
        }
        catch (exception) { alert('Delete Leave Type: ' + exception); }
    };

    //#endregion       

    //#region general functions
    function setGridData() {
        if ($scope.MonthlyLeave != []) {
            $scope.grdOptMonthlyLeave.api.setRowData($scope.MonthlyLeave.Details);
            setGridDeleteFilter($scope.grdOptMonthlyLeave.api);
        }
        else { $scope.grdOptMonthlyLeave.api.setRowData([]); }
    }

    $scope.sum = function (items, prop) {
        return items.reduce(function (a, b) {
            return a + b[prop];
        }, 0);
    };
    //#endregion
    //#endregion

});