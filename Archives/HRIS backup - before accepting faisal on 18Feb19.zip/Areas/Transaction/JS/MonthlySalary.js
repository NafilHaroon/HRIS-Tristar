﻿baseURL = "/HRIS/Transaction/MonthlySalary/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#txtAbsentDay').focus();
    });
});

app.controller('MonthlySalaryController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstEmployee = result.data.lstEmployee;
            $scope.lstAssetType = result.data.lstAssetType;
            $scope.lstSalaryHead = result.data.lstSalaryHead;
        }, errorMsg => {
            alert(errorMsg);
        });
    }

    //#endregion

    //#region toolbar actions

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#ddEmployee').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Monthly Salary";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getMonthlySalaryById($rootScope.SelectedRow.EmployeeId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $scope.MonthlySalary.Salary = getSalaryDataFromGrid();
        $scope.MonthlySalary.Asset = getAssetDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.MonthlySalary
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();
                setGridData();               
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setGridData();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbDelete = function () {
        var _Empid = document.getElementById("hdEmployeeId");
        $http({
            type: "Get",
            url: baseURL + "Delete",
            dataType: "JSON",
            params: { _keyId: _Empid }
        }).then(result => {           
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);             
            }
            setFormControls(result.data.session);            
        }, errorMsg => {
            alert(result);
        });
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };

    $scope.CalculateSalary = function () {
        var AbsentDays = document.getElementById('txtAbsentDay').value;
        var MonthDays = document.getElementById('txtMonthDays').value;
        if (AbsentDays > MonthDays) {
            alert("Absent days can't be more than total days in the month!");
            document.getElementById('txtAbsentDay').value = 0;
        }
        else {
            var SalaryDays = parseInt(MonthDays) - parseInt(AbsentDays);
            document.getElementById('txtSalaryDays').value = SalaryDays;
            AddAbsentHead();
        }
       
    };

    $scope.ValidateLDays = function () {
        var LeaveDays = document.getElementById('txtLeaveDay').value;
        var MonthDays = document.getElementById('txtMonthDays').value;
        if (LeaveDays > MonthDays) {
            alert("Leave days can't be more than total days in the month!");
            document.getElementById('txtLeaveDay').value = 0;
        }
        else {
            AddAbsentHead();
        }
    };
    //#endregion

    //#region form functions
    $scope.getMonthlySalaryById = function (_EmpId) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: _EmpId }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.MonthlySalary = result.data.MonthlySalary;
                $scope.footer = $scope.MonthlySalary.AuditTrail;                
            }
            setFormControls(result.data.session);
            maskDates();
            setGridData();
            AddAbsentHead();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.MonthlySalary = {};
        $scope.footer = {};
        $scope.errors = [];
    }


    //#endregion

    //#region date functions

    function maskDates() {
        $scope.MonthlySalary.JoiningDate = formatDate($scope.MonthlySalary.JoiningDate);
        $scope.MonthlySalary.VerifiedOn = formatDate($scope.MonthlySalary.VerifiedOn);
        if ($scope.MonthlySalary.AuditTrail != null) {
            $scope.MonthlySalary.AuditTrail.CreatedOn = formatDateTime($scope.MonthlySalary.AuditTrail.CreatedOn);
            if ($scope.MonthlySalary.AuditTrail.UpdatedOn != null) {
                $scope.MonthlySalary.AuditTrail.UpdatedOn = formatDateTime($scope.MonthlySalary.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion

    //#region grid setup
    //#region Salary Grid Definition & functions
    var colSalary = [
        {
            headerName: "Head", field: "HeadId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'SalaryHead', class: "agGridSelect130" },
            valueFormatter: getSalaryHeadName, width: 130
        },
        {
            headerName: "Amount", field: "Amount", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 120,
        },
        {
            headerName: "Loan", field: "LoanId", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 90,
        },
        {
            headerName: "Remarks", field: "Remarks", width: 250,
        },
        {
            headerName: "AutoCalculated", field: "AutoCalculated", width: 1, hide: true,
        },

        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true }
    ];

    $scope.grdOptSalary = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colSalary,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        stopEditingWhenGridLosesFocus: true,
        onGridReady: (grid) => {
            setSalaryFooter();
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
            setSalaryFooter();
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect()
        }
    };

    function getSalaryDataFromGrid() {
        let rowData = [];
        $scope.grdOptSalary.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddSalary = function () {
        try {
            var res = $scope.grdOptSalary.api.updateRowData({
                add: [{
                    HeadId: null, Amount: 0, LoanId: 0, Remarks:null,  Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptSalary.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "HeadId" });
        }
        catch (exception) { alert('Add Salary Head: ' + exception); }
    };

    $scope.onDeleteSalary = function () {
        try {
            if ($scope.grdOptSalary.api.getSelectedRows().length > 0) {
                if (confirm("Are you sure you want to Delete selected row?")) {
                    $scope.grdOptSalary.api.getSelectedRows().forEach(x => x.Delete = true);
                    $scope.grdOptSalary.api.getFilterInstance('Delete').onFilterChanged();
                    setSalaryFooter();
                }
            }
            else
                alert("No Row selected to apply Delete operation. Please select row and then hit Delete button!");
        }
        catch (exception) { alert('Delete Salary Head: ' + exception); }
    };

    function AddAbsentHead () {
        var _AbsentDeductId = $scope.MonthlySalary.AbsentDeductionId;
        var _MonthDays = $scope.MonthlySalary.MonthDays; 
        var _AbsentDay = $scope.MonthlySalary.AbsentDays; 
      
      
        if (_AbsentDay >= 1) {
            let _dblGrossSalary = 0, _HeadId = 0;

            if ($scope.grdOptSalary.api.getDisplayedRowCount() > 0) {
                $scope.grdOptSalary.api.forEachNode(n => _dblGrossSalary +=
                    n.data.AbsentDeduction == true && !n.data.Delete ?
                        n.data.Amount * $scope.lstSalaryHead.find(sh => { return sh.HeadId == n.data.HeadId; })["Symbol"] : 0); 

                $scope.grdOptSalary.api.forEachNode(n => _HeadId +=
                    n.data.HeadId ==_AbsentDeductId ?
                    n.data.HeadId : 0);              
            }
            if (_HeadId!=0) {

              
            }
            else {
                $scope.grdOptSalary.api.updateRowData({
                    add: [{
                        HeadId: _AbsentDeductId, Amount: ((_dblGrossSalary / _MonthDays) * _AbsentDay).toFixed(0),
                        LoanId: 0, Remarks: null, 
                        Add: true, Edit: false, Delete: false
                    }]
                });
            }

        }
           
            setSalaryFooter();        
    };    

    function setSalaryFooter() {
        try {
            let _total = 0;
            if ($scope.grdOptSalary.api.getDisplayedRowCount() > 0) {
                $scope.grdOptSalary.api.forEachNode(n => _total +=
                    n.data.HeadId != undefined && n.data.HeadId != -1 && !n.data.Delete ?
                        n.data.Amount * $scope.lstSalaryHead.find(sh => { return sh.HeadId == n.data.HeadId; })["Symbol"] : 0);
            }
            var _footer = [{ HeadId: -1, Amount: _total }];
            $scope.grdOptSalary.api.setPinnedBottomRowData(_footer);
        }
        catch (exception) { alert('Salary Footer Method:' + exception); }
    }
    //#endregion

    //#region Asset Grid Definition & functions
    var colAsset = [
        {
            headerName: "Asset", field: "AssetId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'Asset', class: "agGridSelect130" },
            valueFormatter: getAssetName, width: 130
        },
        {
            headerName: "Limit", field: "Limit", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 120,
        },       
        {
            headerName: "Remarks", field: "Remarks", width: 250,
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true },
    ];

    $scope.grdOptAsset = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colAsset,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        stopEditingWhenGridLosesFocus: true,
        onGridReady: (grid) => {
           
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
          
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect()
        }
    };

    function getAssetDataFromGrid() {
        let rowData = [];
        $scope.grdOptAsset.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddAsset = function () {
        try {
            var res = $scope.grdOptAsset.api.updateRowData({
                add: [{
                    AssetId: null, Limit: 0, Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptAsset.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "AssetId" });
        }
        catch (exception) { alert('Add Department: ' + exception); }
    };

    $scope.onDeleteAsset = function () {
        try {
            if ($scope.grdOptAsset.api.getSelectedRows().length > 0) {
                $scope.grdOptAsset.api.getSelectedRows().forEach(x => x.Delete = true);
                $scope.grdOptAsset.api.getFilterInstance('Delete').onFilterChanged();
            
            }
        }
        catch (exception) { alert('Delete Asset: ' + exception); }
    };
   
    //#endregion

    //#region general functions
    function setGridData() {
        try {
            if ($scope.MonthlySalary != []) {
                $scope.grdOptSalary.api.setRowData($scope.MonthlySalary.Salary);
                $scope.grdOptAsset.api.setRowData($scope.MonthlySalary.Asset);
                setGridDeleteFilter($scope.grdOptSalary.api);
                setGridDeleteFilter($scope.grdOptAsset.api);              
            }
            else {
                $scope.grdOptSalary.api.setRowData([]);
                $scope.grdOptAsset.api.setRowData([]);
            }
            setSalaryFooter();
        }
        catch (exception) { alert(exception); }
    }

    $scope.sum = function (items, prop) {
        return items.reduce(function (a, b) {
            return a + b[prop];
        }, 0);
    };
    //#endregion
    //#endregion

});