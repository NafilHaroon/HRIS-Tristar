﻿baseURL = "/HRIS/Transaction/AdvanceSalary/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        //document.getElementById('ddEmployee').disabled = true;
        $('#ddEmployee').focus();
    });
});

app.controller('AdvanceSalaryController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
        setDateParameters();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstEmployee = result.data;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.AdvanceSalary = response.data.AdvanceSalary;
            $scope.Footer = response.data.AdvanceSalary.AuditTrail;
            setFormControls(response.data.session);
            maskDates();
            $('#ddEmployee').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtAdvanceId').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Advance Salary";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getAdvanceSalaryById($rootScope.SelectedRow.AdvanceId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.AdvanceSalary
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getAdvanceSalaryById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.AdvanceSalary = result.data.AdvanceSalary;
                $scope.footer = $scope.AdvanceSalary.AuditTrail;
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.AdvanceSalary = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function setDateParameters() {
        $('#dtAdvanceDate').datepicker({
            startDate: '-30d'
        }).on('changeDate', function (e) {
            $scope.AdvanceSalary.AdvanceDate = e.format();
            $scope.$apply();
        });
    }

    function maskDates() {
        $scope.AdvanceSalary.AdvanceDate = formatDateTime($scope.AdvanceSalary.AdvanceDate);
        if ($scope.AdvanceSalary.AuditTrail != null)
            $scope.AdvanceSalary.AuditTrail.CreatedOn = formatDateTime($scope.AdvanceSalary.AuditTrail.CreatedOn);
        if ($scope.AdvanceSalary.AuditTrail.UpdatedOn != null)
            $scope.AdvanceSalary.AuditTrail.UpdatedOn = formatDateTime($scope.AdvanceSalary.AuditTrail.UpdatedOn);
    }
    //#endregion
});