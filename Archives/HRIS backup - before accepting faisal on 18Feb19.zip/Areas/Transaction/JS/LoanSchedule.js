﻿baseURL = "/HRIS/Transaction/LoanSchedule/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        //document.getElementById('ddEmployee').disabled = true;
        $('#ddEmployee').focus();
    });
});

app.controller('LoanScheduleController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
        setDateParameters();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstEmployee = result.data;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.LoanSchedule = response.data.LoanSchedule;
            $scope.Footer = response.data.LoanSchedule.AuditTrail;
            setFormControls(response.data.session);
            maskDates();
            $('#ddEmployee').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtLoanId').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Loan Schedule";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getLoanScheduleById($rootScope.SelectedRow.LoanId);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.LoanSchedule
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getLoanScheduleById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.LoanSchedule = result.data.LoanSchedule;
                $scope.footer = $scope.LoanSchedule.AuditTrail;
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.LoanSchedule = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function setDateParameters() {
        $('#dtStartingDate').datepicker({
            startDate: '-30d',
             endDate: '+30d'
        }).on('changeDate', function (e) {
            $scope.LoanSchedule.StartingDate = e.format();
            $scope.$apply();
        });
    }

    function maskDates() {
        $scope.LoanSchedule.StartingDate = formatDateTime($scope.LoanSchedule.StartingDate);
        if ($scope.LoanSchedule.AuditTrail != null)
            $scope.LoanSchedule.AuditTrail.CreatedOn = formatDateTime($scope.LoanSchedule.AuditTrail.CreatedOn);
        if ($scope.LoanSchedule.AuditTrail.UpdatedOn != null)
            $scope.LoanSchedule.AuditTrail.UpdatedOn = formatDateTime($scope.LoanSchedule.AuditTrail.UpdatedOn);
    }
    //#endregion
});