﻿$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        document.getElementById("ddBank").disabled = true;
        document.getElementById("ddmonth").disabled = true;
        document.getElementById("ddyear").disabled = true;
        document.getElementById("btnLoad").disabled = true;
        document.getElementById("ddCompanyId").disabled = true;
        $('#LetterDate').focus();
        
    });

    $('#LetterDate').datepicker();

    $('#allcb').change(function () {
        $('tbody tr td input[type="checkbox"]').prop('checked', $(this).prop('checked'));
    });

});




function validate(bank, mon, year, comid) {

    if (mon == null && year == null && bank == null && comid == null) {
        alert("Please select month,Year, Bank, CompanyId before hitting load button");
        return false;
    }
    else
        return true;
};

var app = angular.module('HRIS', []);

app.controller('BankLetterController', function ($scope, $http, $window) {

    $('#LetterDate').datepicker({
        onSelect: function (date) {
            $scope.BankLetter.LetterDate = date;
            $scope.$apply();
        }
    });

    $scope.checkAll = function () {
       var CN = document.getElementById('Select').checked;
       indexes = $.map($scope.BankLetter.Details, function (obj, index) {

           if (CN == true)
           {
               $scope.BankLetter.Details[index].Selected = true;             
           }

           else if (CN == false) {
               $scope.BankLetter.Details[index].Selected = false;
           }
           
       })
    };


    $scope.load = function () {

        var id = document.getElementById('txtLNo').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/BankLetter/Save",
            data: $scope.BankLetter
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.BankLetter = result.data;
            }
            else {
                alert(result.Message);
                $scope.BankLetter = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/BankLetter/Undo"
        }).success(function (result) {
            $scope.BankLetter = [];
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/BankLetter/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/BankLetter/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls(result.Session);
          
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/BankLetter/Add"
        }).success(function (result) {
            $scope.errors = [];
            $scope.BankLetter = result.data;

            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }
    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/BankLetter/Get",
            data: { _keyId: res },
        }).success(function (result) {
            $scope.errors = [];
            $scope.BankLetter = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.BankLetter = result.data;
            }
            setFormControls(result.Session);
           
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }


    $scope.GetEmployeeDetail = function () {
        id = 0;
        var bank = document.getElementById("ddbank").value;
        var mon = document.getElementById("ddmonth").value;
        var year = document.getElementById("ddyear").value;
        var comid = document.getElementById("ddCompanyId").value;

        var isValid = validate(bank, mon, year, comid);
        if (isValid == true) {

            $http({
                method: "POST",
                url: "/BankLetter/GetEmployeeDetail",
                data: $scope.BankLetter
                //data: { _KeyId: id, _bankId: bank, _monthnum: mon, _year: year, _comid: comid },

            }).success(function (result) {
                $scope.errors = [];
                $scope.BankLetter = {};
                if (result.success == false) {
                    $scope.errors = [
                       result.Message]
                }
                else {
                    $scope.BankLetter = result.data;
                }
                setFormControls(result.Session);
              
                ConvertDate();
            }).catch(function (result) {

            });
        }
    }

    function LoadDropDown()
    {
        $http.get('/BankLetter/GetMonth').then(function (d) {
            $scope.Monthlist = d.data;
        }, function () {
            alert('failed');
        });


        $http.get('/BankLetter/GetYear').then(function (d) {
            $scope.Yearlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/BankLetter/GetBank').then(function (d) {
            $scope.Banklist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/BankLetter/GetCompany').then(function (d) {
            $scope.companylist = d.data;
        }, function () {
            alert('failed');
        });
    }

   


    function ConvertDate() {

        if ($scope.BankLetter.LetterDate != null) {
            $scope.BankLetter.LetterDate = formattingdate($scope.BankLetter.LetterDate);
        }
        $scope.BankLetter.AuditTrail.CreatedOn = formattingDateTime($scope.BankLetter.AuditTrail.CreatedOn);
        if ($scope.BankLetter.AuditTrail.UpdatedOn != null) {
            $scope.BankLetter.AuditTrail.UpdatedOn = formattingDateTime($scope.BankLetter.AuditTrail.UpdatedOn);
        }
    }


});