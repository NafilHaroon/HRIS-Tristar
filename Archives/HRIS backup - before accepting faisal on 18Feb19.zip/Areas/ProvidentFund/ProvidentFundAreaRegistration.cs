﻿using System.Web.Mvc;

namespace HRIS.Areas.ProvidentFund
{
    public class ProvidentFundAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "ProvidentFund";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "ProvidentFund_default",
                "ProvidentFund/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
