﻿baseURL = "/HRIS/ProvidentFund/CoA/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        //document.getElementById('ddCompany').disabled = true;
        //document.getElementById('ddAccountType').disabled = true;
        $('#txtAccountName').focus();
    });
});

app.controller('CoAController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstCompany = result.data.lstCompany;
            $scope.lstAccountType = result.data.lstAccountType;
        }, errorMsg => {
            alert(errorMsg);
        });
    }   

    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.CoA = response.data.CoA;
            $scope.Footer = response.data.CoA.AuditTrail;
            setFormControls(response.data.session);
            maskDates();
            $('#txtAccountName').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtAccountCode').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select CoA";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getCoAById($rootScope.SelectedRow.AccountCode);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.CoA
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                clearForm();

            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getCoAById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.CoA = result.data.CoA;
                $scope.footer = $scope.CoA.AuditTrail;
            }
            setFormControls(result.data.session);
            maskDates();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.CoA = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function maskDates() {
        if ($scope.CoA.AuditTrail != null) {
            $scope.CoA.AuditTrail.CreatedOn = formatDateTime($scope.CoA.AuditTrail.CreatedOn);
            if ($scope.CoA.AuditTrail.UpdatedOn != null) {
                $scope.CoA.AuditTrail.UpdatedOn = formatDateTime($scope.CoA.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion 
});