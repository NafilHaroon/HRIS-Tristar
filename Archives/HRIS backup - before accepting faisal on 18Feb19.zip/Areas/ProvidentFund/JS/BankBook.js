﻿baseURL = "/HRIS/ProvidentFund/BankBook/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        document.getElementById('ddCompany').disabled = true;
        //document.getElementById('ddBankAccount').disabled = true;
        $('#txtDescription').focus();
    });
});

app.controller('BankBookController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
        setDateParameters();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstCompany = result.data.lstCompany;
            $scope.lstBankAccount = result.data.lstBankAccount;
            $scope.lstCompanyAccount = result.data.lstCompanyAccount;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    
   
    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.BankBook = response.data.BankBook;
            $scope.Footer = response.data.BankBook.AuditTrail;
            setFormControls(response.data.session);
            document.getElementById('ddCompany').disabled = true;
            maskDates();
            $('#txtDescription').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtVoucherNumber').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Bank Book";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getBankBookById($rootScope.SelectedRow.VoucherNumber);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $scope.BankBook.Details = getBankBookDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.BankBook
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);                
                clearForm();
                setGridData();

            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setGridData();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getBankBookById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.BankBook = result.data.BankBook;
                $scope.footer = $scope.BankBook.AuditTrail;
               
            }
            setFormControls(result.data.session);
            maskDates();
            setGridData();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.BankBook = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function setDateParameters() {       

        $('#dtVoucherDate').datepicker({
            startDate: '-30d'
        }).on('changeDate', function (e) {
            $scope.BankBook.VoucherDate = e.format();
            $scope.$apply();
        });

        $('#dtChequeDate').datepicker({
            startDate: '-150d',
            endDate: '+180d'
        }).on('changeDate', function (e) {
            $scope.BankBook.ChequeDate = e.format();//dt;
            $scope.$apply();
        });      
    }

    function maskDates() {
        $scope.BankBook.VoucherDate = formatDate($scope.BankBook.VoucherDate);
        $scope.BankBook.ChequeDate = formatDate($scope.BankBook.ChequeDate);

        if ($scope.BankBook.AuditTrail != null) {
            $scope.BankBook.AuditTrail.CreatedOn = formatDateTime($scope.BankBook.AuditTrail.CreatedOn);
            if ($scope.BankBook.AuditTrail.UpdatedOn != null) {
                $scope.BankBook.AuditTrail.UpdatedOn = formatDateTime($scope.BankBook.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion

    //#region grid setup
    //#region Bank Book Grid Definition & functions
    var colBankBook = [
        {
            headerName: "Account", field: "AccountId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'CompanyAccount', class: "agGridSelect250" },
            valueFormatter: getCompanyAccountName, width: 250
        },
        {
            headerName: "Description", field: "Description", cellEditor: "agTextCellEditor",
            width: 200
        },
        {
            headerName: "Debit", field: "Debit", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 120
        },
        {
            headerName: "Credit", field: "Credit", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 120
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true },
    ];   

    $scope.grdOptBankBook = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colBankBook,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        onGridReady: (grid) => {
            setBankBookFooter();
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
            if (params.colDef.field == "Debit" || params.colDef.field == "Credit")
                setBankBookFooter();
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect()
        }
    };

    function getBankBookDataFromGrid() {
        let rowData = [];
        $scope.grdOptBankBook.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    $scope.onAddBankBook = function () {
        try {
            var res = $scope.grdOptBankBook.api.updateRowData({
                add: [{
                    AccountId: null, Debit: 0, Credit: 0, Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptBankBook.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "AccountId" });
        }
        catch (exception) { alert('Add Bank Book: ' + exception); }
    };

    $scope.onDeleteBankBook = function () {
        try {
            if ($scope.grdOptBankBook.api.getSelectedRows().length > 0) {
                if (confirm("Are you sure you want to Delete selected row?")) {
                    $scope.grdOptBankBook.api.getSelectedRows().forEach(x => x.Delete = true);
                    $scope.grdOptBankBook.api.getFilterInstance('Delete').onFilterChanged();
                    setBankBookFooter();
                }
            }
            else
                alert("No Row selected to apply Delete operation. Please select row and then hit Delete button!");
        }
        catch (exception) { alert('Delete Bank Book: ' + exception); }
    };

    function setBankBookFooter() {
        try {
            let _debit = 0, _credit=0;
            $scope.grdOptBankBook.api.forEachNode(n => _debit +=
                n.data.AccountId != undefined && n.data.AccountId != -1 ?
                    n.data.Debit : 0);
            $scope.grdOptBankBook.api.forEachNode(n => _credit +=
                n.data.AccountId != undefined && n.data.AccountId != -1 ?
                n.data.Credit : 0);
            var _footer = [{ AccountId: -1, Description: null, Debit: _debit, Credit: _credit }];            
            $scope.grdOptBankBook.api.setPinnedBottomRowData(_footer);

            var Balance = parseFloat(_debit) - parseFloat(_credit);
            if (Balance < 0)
                Balance = Balance * -1;
            var value = ((_debit - _credit) < 0 ? "Debit with " : "Credit with ") + (Balance);        
                 $("#lblBalance").val(value);
        }
        catch (exception) { alert('Add Bank Book:' + exception); }
    }


    //#endregion       

    //#region general functions
    function setGridData() {
        if ($scope.BankBook != []) {
            $scope.grdOptBankBook.api.setRowData($scope.BankBook.Details);
            setGridDeleteFilter($scope.grdOptBankBook.api);
        }
        else { $scope.grdOptBankBook.api.setRowData([]); }
        setBankBookFooter();
    }

    $scope.sum = function (items, prop) {
        return items.reduce(function (a, b) {
            return a + b[prop];
        }, 0);
    };
    //#endregion
    //#endregion

});