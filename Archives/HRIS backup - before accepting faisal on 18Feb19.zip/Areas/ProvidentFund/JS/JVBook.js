﻿baseURL = "/HRIS/ProvidentFund/JVBook/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        document.getElementById('ddCompany').disabled = true;
        $('#dtVoucherDate').focus();
    });
});

app.controller('JVBookController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
        setDateParameters();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstCompany = result.data.lstCompany;
            $scope.lstCompanyAccount = result.data.lstCompanyAccount;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    //#endregion

    //#region toolbar actions
    $scope.tbAdd = function () {
        $http({
            method: "Get",
            url: baseURL + "Add"
        }).then(response => {
            $scope.JVBook = response.data.JVBook;
            $scope.Footer = response.data.JVBook.AuditTrail;
            setFormControls(response.data.session);
            document.getElementById('ddCompany').disabled = true;
            maskDates();
            $('#dtVoucherDate').focus();
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbRecall = function () {
        setFormControls("Recall");
        $('#txtVoucherNumber').focus();
    };

    $scope.tbSearch = function () {
        $scope.formTitle = "Search & Select Jv Book";
        try {
            var modalScope = $scope.$new();
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: '/HRIS/Helper/Pages/Search.html',
                windowClass: 'show',
                backdropClass: 'show',
                size: "lg",
                scope: modalScope
            });
            modalScope.modalInstance = modalInstance;

            modalInstance.result.then(function () {
                $scope.getJVBookById($rootScope.SelectedRow.VoucherNumber);
            }, function () {

            });
        }
        catch (exception) { alert(exception); }
    };

    $scope.tbSave = function () {
        $scope.JVBook.Details = getJVBookDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.JVBook
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);                
                clearForm();
                setGridData();
            }
            setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbUndo = function () {
        clearForm();
        setGridData();
        setFormControls("Initialize");//result.data.Session
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion

    //#region form functions
    $scope.getJVBookById = function (res) {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON",
            params: { _keyId: res }
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.JVBook = result.data.JVBook;
                $scope.footer = $scope.JVBook.AuditTrail;               
            }
            setFormControls(result.data.session);
            maskDates();
            setGridData();
        }, errorMsg => {
            alert(result);
        });
    };
    //#endregion

    //#region local function
    function clearForm() {
        $scope.JVBook = {};
        $scope.footer = {};
        $scope.errors = [];
    }
    //#endregion

    //#region date functions
    function setDateParameters() {

        $('#dtVoucherDate').datepicker({
            startDate: '-30d'
        }).on('changeDate', function (e) {
            $scope.JVBook.VoucherDate = e.format();
            $scope.$apply();
        });
    }

    function maskDates() {
        $scope.JVBook.VoucherDate = formatDate($scope.JVBook.VoucherDate);

        if ($scope.JVBook.AuditTrail != null) {
            $scope.JVBook.AuditTrail.CreatedOn = formatDateTime($scope.JVBook.AuditTrail.CreatedOn);
            if ($scope.JVBook.AuditTrail.UpdatedOn != null) {
                $scope.JVBook.AuditTrail.UpdatedOn = formatDateTime($scope.JVBook.AuditTrail.UpdatedOn);
            }
        }
    }
    //#endregion

    //#region grid setup
    //#region Jv Book Grid Definition & functions
    var colJVBook = [
        {
            headerName: "Account", field: "AccountId", cellEditor: "agilitySelectEditor",
            cellEditorParams: { source: 'JvCompanyAccount', class: "agGridSelect250" },
            valueFormatter: getJvCompanyAccountName, width: 250
        },
        {
            headerName: "Description", field: "Description", cellEditor: "agTextCellEditor",
            width: 200
        },
        {
            headerName: "Debit", field: "Debit", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 120
        },
        {
            headerName: "Credit", field: "Credit", type: "numericColumn",
            valueFormatter: formatNumbers, valueParser: numberValueParser, width: 120
        },
        { headerName: "Add", field: "Add", hide: true, suppressToolPanel: true },
        { headerName: "Edit", field: "Edit", hide: true, suppressToolPanel: true },
        { headerName: "Delete", field: "Delete", hide: true, suppressToolPanel: true },
    ];


    $scope.grdOptJVBook = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        defaultColDef: {
            editable: allowEdit.bind(this)
        },
        columnDefs: colJVBook,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        onGridReady: (grid) => {
            setJVBookFooter();
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = true;
            if (params.colDef.field == "Debit" || params.colDef.field == "Credit")
                setJVBookFooter();
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
        components: {
            agilitySelectEditor: getAgilitySelect()
        }
    };

    function getJVBookDataFromGrid() {
        let rowData = [];
        $scope.grdOptJVBook.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }
       
    $scope.onAddJVBook = function () {
        try {
            var res = $scope.grdOptJVBook.api.updateRowData({
                add: [{
                    AccountId: null, Debit: 0, Credit: 0, Add: true, Edit: false, Delete: false
                }]
            });
            $scope.grdOptJVBook.api.startEditingCell({ rowIndex: res.add[0].rowIndex, colKey: "AccountId" });
        }
        catch (exception) { alert('Add JV Book: ' + exception); }
    };

    $scope.onDeleteJVBook = function () {
        try {
            if ($scope.grdOptJVBook.api.getSelectedRows().length > 0) {
                if (confirm("Are you sure you want to Delete selected row?")) {
                    $scope.grdOptJVBook.api.getSelectedRows().forEach(x => x.Delete = true);
                    $scope.grdOptJVBook.api.getFilterInstance('Delete').onFilterChanged();
                    setJVBookFooter();
                }
            }
            else
                alert("No Row selected to apply Delete operation. Please select row and then hit Delete button!");
        }
        catch (exception) { alert('Delete JV Book: ' + exception); }
    };

    function setJVBookFooter() {
        try {
            let _debit = 0, _credit = 0;
            $scope.grdOptJVBook.api.forEachNode(n => _debit +=
                n.data.AccountId != undefined && n.data.AccountId != -1 ?
                    n.data.Debit : 0);
            $scope.grdOptJVBook.api.forEachNode(n => _credit +=
                n.data.AccountId != undefined && n.data.AccountId != -1 ?
                    n.data.Credit : 0);
            var _footer = [{ AccountId: -1, Description: null, Debit: _debit, Credit: _credit }];
            $scope.grdOptJVBook.api.setPinnedBottomRowData(_footer);
        }
        catch (exception) { alert('Add Jv Book:' + exception); }
    }

    //#endregion       

    //#region general functions
    function setGridData() {
        if ($scope.JVBook != []) {
            $scope.grdOptJVBook.api.setRowData($scope.JVBook.Details);
            setGridDeleteFilter($scope.grdOptJVBook.api);
        }
        else { $scope.grdOptJVBook.api.setRowData([]); }
        setJVBookFooter();
    }

    $scope.sum = function (items, prop) {
        return items.reduce(function (a, b) {
            return a + b[prop];
        }, 0);
    };
    //#endregion
    //#endregion

});