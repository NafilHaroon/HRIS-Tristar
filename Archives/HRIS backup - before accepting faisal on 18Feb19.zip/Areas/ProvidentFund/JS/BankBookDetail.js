﻿$(document).ready(function () {
  

   
});



$scope.Add = function () {
    //Add the new item to the Array.
        
    var atemplate = {};
    var detailid = 0;
    $scope.AllocationTemplate.Details.map(function(obj){     
        if (obj.Detailid > detailid) detailid = obj.Detailid;    
    });
    atemplate.Percentage = $scope.Percentage;
    atemplate.DivisionId = $scope.DivisionId;
    atemplate.DetailId = detailid += 1
    $scope.AllocationTemplate.Details.push(atemplate);

    //Clear the TextBoxes.
    $scope.Percentage = "";
    $scope.DivisionId = "";
};

$scope.Remove = function (index) {
    //Find the record using Index from Array.
    var CC = $scope.gridTableDetails.[index].DetailId;
    if ($window.confirm("Do you want to delete: " + CC)) {
        //Remove the item from Array using Index.
        $scope.AllocationTemplate.Details.splice(index, 1);
    }
}
