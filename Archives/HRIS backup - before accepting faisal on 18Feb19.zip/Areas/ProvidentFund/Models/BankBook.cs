﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Web;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class BankBook : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Voucher #")]
        public string VoucherNumber { get; set; }
        [Display(Name = "Voucher Id")]
        public short? VoucherId { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Voucher Date")]
        public DateTime? VoucherDate { get; set; }
        [Display(Name = "Bank Book")]
        public short? BankAccountId { get; set; }
        [Display(Name = "Cheque #")]
        public string ChequeNumber { get; set; }
        [Display(Name = "Cheque Date")]
        public DateTime? ChequeDate { get; set; }
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Display(Name = "Payee Name")]
        public string PayeeName { get; set; }        

        public Footer AuditTrail { get; set; }
        public List<BankBookDetail> Details { get; set; }


        #endregion

        #region Constructor
        public BankBook()
        {
            VoucherDate = DateTime.Now;
            ChequeDate = DateTime.Now;
            Details = new List<BankBookDetail>();
            CompanyId = Convert.ToInt16(HttpContext.Current.Session["CompanyId"]);
            AuditTrail = new Footer();
        }
        #endregion

        #region internal methods
        internal static BankBook Get(string _voucherNo)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetBankBookByCode"))
            {
                db.AddInParameter(dbCommand, "VoucherNumber", SqlDbType.VarChar, _voucherNo);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (BankBook _bb = new BankBook())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _bb.VoucherNumber = _voucherNo;
                            _bb.VoucherId = Convert.ToInt16(dr["VoucherId"]);
                            _bb.VoucherDate = Convert.ToDateTime(dr["VoucherDate"]);
                            _bb.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                            _bb.BankAccountId = Convert.ToInt16(dr["BankAccountId"]);
                            _bb.ChequeNumber = dr["ChequeNumber"].ToString();
                            _bb.ChequeDate = Convert.ToDateTime(dr["ChequeDate"]);
                            _bb.Description = dr["Description"].ToString();
                            _bb.PayeeName = dr["PayeeName"].ToString();
                            _bb.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _bb.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();

                            _bb.Details = BankBookDetail.Get(_bb.VoucherId.Value);
                            return _bb;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(BankBook _bb, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveBankBook"))
            {
                db.AddInParameter(dbCommand, "VoucherId", SqlDbType.SmallInt, _bb.VoucherId);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _bb.CompanyId);
                db.AddInParameter(dbCommand, "VoucherDate", SqlDbType.DateTime, _bb.VoucherDate);
                db.AddInParameter(dbCommand, "BankAccountId", SqlDbType.SmallInt, _bb.BankAccountId);
                db.AddInParameter(dbCommand, "ChequeNumber", SqlDbType.VarChar, _bb.ChequeNumber);
                db.AddInParameter(dbCommand, "ChequeDate", SqlDbType.DateTime, _bb.ChequeDate);
                db.AddInParameter(dbCommand, "Description", SqlDbType.VarChar, _bb.Description);
                db.AddInParameter(dbCommand, "PayeeName", SqlDbType.VarChar, _bb.PayeeName);

                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddOutParameter(dbCommand, "NewVoucherId", SqlDbType.SmallInt, 32);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        _bb.VoucherId = Convert.ToInt16(dbCommand.Parameters["@NewVoucherId"].Value);
                        BankBookDetail.Save(_bb.VoucherId.Value, _bb.Details, _userId, transaction);
                        transaction.Commit();
                        return true;
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }            
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}