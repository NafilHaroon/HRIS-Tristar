﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class BankBookList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Vouchere #")]
        public string VoucherNumber { get; set; }
        [DataMember(Order = 1)]
        [Display(Name = "Voucher Date")]
        public DateTime VoucherDate { get; set; }
        [DataMember(Order = 2)]
        [Display(Name = "AccountName")]
        public string AccountName { get; set; }
        [DataMember(Order = 3)]
        [Display(Name = "Debit")]
        public double Debit { get; set; }
        [DataMember(Order = 4)]
        [Display(Name = "Credit")]
        public double Credit { get; set; }
        [DataMember(Order = 4)]
        [Display(Name = "CompanyCode")]
        public string CompanyCode { get; set; }
        [DataMember(Order = 5)]
        [Display(Name = "Bank Name")]
        public string BankName { get; set; }
        #endregion

        #region constructor
        public BankBookList()
        {
        }

        public BankBookList(string _VoucherNumber, DateTime _VoucherDate, string _AccountName, double _Debit, double _Credit,
             string _CompanyCode, string _BankName)
        {
            VoucherNumber = _VoucherNumber;
            VoucherDate = _VoucherDate;
            AccountName = _AccountName;
            Debit = _Debit;
            Credit = _Credit;
            CompanyCode = _CompanyCode;
            BankName = _BankName;
        }


        #endregion

        #region internal methods
        internal static List<BankBookList> Get(string _userId)
        {
            return getBankBooks(_userId);
        }

        //internal static DataTable GetDT(string _userId)
        //{
        //    return AgilityHelper.ListToDataTable(getBankBooks(_userId));
        //}
        #endregion

        #region private methods
        private static List<BankBookList> getBankBooks(string _userId)
        {
            List<BankBookList> lstbbook = new List<BankBookList>();
            DbCommand dbCommand = db.GetStoredProcCommand("getBankBookList");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            {
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds != null && ds.Tables.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            lstbbook.Add(new BankBookList(
                                 dr["VoucherNumber"].ToString(),
                                 Convert.ToDateTime(dr["VoucherDate"]),
                                 dr["AccountName"].ToString(),
                                  Convert.ToDouble(dr["Debit"]),
                                   Convert.ToDouble(dr["Credit"]),
                                    dr["CompanyCode"].ToString(),
                                    dr["BankName"].ToString()));
                        }
                    }
                }
            }
            return lstbbook;
        }

        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}