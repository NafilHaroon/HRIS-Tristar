﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Web;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class JVBook : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Voucher #")]
        public string VoucherNumber { get; set; }
        [Display(Name = "Voucher Id")]
        public short? VoucherId { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Voucher Date")]
        public DateTime? VoucherDate { get; set; }         

        public Footer AuditTrail { get; set; }
        public List<JVBookDetail> Details { get; set; }


        #endregion

        #region Constructor
        public JVBook()
        {
            VoucherDate = DateTime.Now;          
            Details = new List<JVBookDetail>();
            CompanyId =Convert.ToInt16(HttpContext.Current.Session["CompanyId"]);
            AuditTrail = new Footer();
        }
        #endregion

        #region internal methods
        internal static JVBook Get(string _voucherNo)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetJVBookByCode"))
            {
                db.AddInParameter(dbCommand, "VoucherNumber", SqlDbType.VarChar, _voucherNo);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (JVBook _jb = new JVBook())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _jb.VoucherNumber = _voucherNo;
                            _jb.VoucherId = Convert.ToInt16(dr["VoucherId"]);
                            _jb.VoucherDate = Convert.ToDateTime(dr["VoucherDate"]);
                            _jb.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                            _jb.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _jb.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _jb.Details = JVBookDetail.Get(_jb.VoucherId.Value);
                            return _jb;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(JVBook _jb, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveJVBook"))
            {
                db.AddInParameter(dbCommand, "VoucherId", SqlDbType.SmallInt, _jb.VoucherId);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _jb.CompanyId);
                db.AddInParameter(dbCommand, "VoucherDate", SqlDbType.DateTime, _jb.VoucherDate);

                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddOutParameter(dbCommand, "NewVoucherId", SqlDbType.SmallInt, 32);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        _jb.VoucherId = Convert.ToInt16(dbCommand.Parameters["@NewVoucherId"].Value);
                        JVBookDetail.Save(_jb.VoucherId.Value, _jb.Details, _userId, transaction);
                        transaction.Commit();
                        return true;
                    }

                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }            
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}