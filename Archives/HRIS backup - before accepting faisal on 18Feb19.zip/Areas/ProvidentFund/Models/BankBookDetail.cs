﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class BankBookDetail : IDisposable
    {
         #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
       
        [Display(Name = "Account")]
        public short? AccountId { get; set; }
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Display(Name = "Credit")]
        public double Credit { get; set; }
        [Display(Name = "Debit")]
        public double Debit { get; set; }
        public int DetailId { get; set; }
        public bool Add { get; set; }
        public bool Edit { get; set; }
        public bool Delete { get; set; }
        #endregion

        #region constructor
        public BankBookDetail()
        {

            DetailId = -1;
            Add = true; Edit = false; Delete = false;
            Credit = 0;
            Debit = 0;
        }
        public BankBookDetail(int _detailId, short _AccountId, string _Description, 
            double _Credit, double _Debit)
        {
            DetailId = _detailId;
            AccountId = _AccountId;
            Description = _Description;
            Credit = _Credit;
            Debit = _Debit;
            Add = false; Edit = false; Delete = false;
        }
        #endregion

        #region internal methods

        internal static List<BankBookDetail> Get(short _voucherId)
        {
            try
            {
                List<BankBookDetail> lstATD = new List<BankBookDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getBankBookDetailById"))
                {
                    db.AddInParameter(dbCommand, "VoucherId", SqlDbType.SmallInt, _voucherId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                           
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstATD.Add(new BankBookDetail(
                                      Convert.ToInt32(dr["DetailId"]),
                                     Convert.ToInt16(dr["AccountId"]),
                                     dr["Description"].ToString(),
                                     Convert.ToDouble(dr["Credit"]),
                                         Convert.ToDouble(dr["Debit"])));
                            }
                        }
                    }                  
                }
                return lstATD;
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Save(short  _voucherId, List<BankBookDetail> _details, string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (BankBookDetail bbd in _details)
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveBankBookDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "VoucherId", SqlDbType.SmallInt, _voucherId);
                        db.AddInParameter(dbCommand, "AccountId", SqlDbType.VarChar, bbd.AccountId);
                        db.AddInParameter(dbCommand, "Description", SqlDbType.VarChar, bbd.Description);
                        db.AddInParameter(dbCommand, "Credit", SqlDbType.Float, bbd.Credit);
                        db.AddInParameter(dbCommand, "Debit", SqlDbType.Float, bbd.Debit);
                        

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
       
      
        #endregion

        #region private methods
        
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

    }
}