﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class CoA : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Account Code")]
        public string AccountCode { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Account Name")]
        public string AccountName { get; set; }
        [Display(Name = "Account Type")]
        public short? AccountTypeId { get; set; }
        [Display(Name = "Opening Balance")]
        public double OpeningBalance { get; set; }
        [Display(Name = "Bank Account")]
        public bool BankAccount { get; set; }
        public Footer AuditTrail { get; set; }

        #endregion

        #region Constructor
        public CoA()
        {
            AuditTrail = new Footer();

        }
        #endregion

        #region internal methods
        internal static CoA Get(string _accountCode)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetChartofAccountsByCode"))
            {
                db.AddInParameter(dbCommand, "AccountCode", SqlDbType.VarChar, _accountCode);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (CoA _bran = new CoA())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _bran.AccountCode = dr["AccountCode"].ToString();
                            _bran.CompanyId =  Convert.ToInt16(dr["CompanyId"]);
                            _bran.AccountName = dr["AccountName"].ToString();
                            _bran.AccountTypeId = Convert.ToInt16(dr["AccountTypeId"]);
                            _bran.OpeningBalance = Convert.ToDouble(dr["OpeningBalance"]);
                            _bran.BankAccount = Convert.ToBoolean(dr["BankAccount"]);
                            _bran.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _bran.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _bran.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _bran.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                         
                            return _bran;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(CoA _coa, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveChartofAccounts"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "AccountCode", SqlDbType.VarChar, _coa.AccountCode);
                    db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _coa.CompanyId);
                    db.AddInParameter(dbCommand, "AccountName", SqlDbType.VarChar, _coa.AccountName);
                    db.AddInParameter(dbCommand, "AccountTypeId", SqlDbType.TinyInt, _coa.AccountTypeId);
                    db.AddInParameter(dbCommand, "OpeningBalance", SqlDbType.Float, _coa.OpeningBalance);
                    db.AddInParameter(dbCommand, "BankAccount", SqlDbType.Bit, _coa.BankAccount);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _coa.AuditTrail.UpdatedOn);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
