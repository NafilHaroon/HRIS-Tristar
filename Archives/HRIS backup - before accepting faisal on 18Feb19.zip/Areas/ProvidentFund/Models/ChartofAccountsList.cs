﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class CoAList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties

        [DataMember(Order = 0)]
        [Display(Name = "Account Id")]
        public short AccountId { get; set; }

        [DataMember(Order = 1)]
        [Display(Name = "Account Code")]
        public string AccountCode { get; set; }
       
        [DataMember(Order = 2)]
        [Display(Name = "Account Name")]
        public string AccountName { get; set; }
        [DataMember(Order = 3)]
        [Display(Name = "Account Type")]
        public string AccountType { get; set; }
        [DataMember(Order = 4)]
        [Display(Name = "Company Code")]
        public string CompanyCode { get; set; }
        [DataMember(Order = 5)]
        [Display(Name = "Company Code")]
        [Browsable(false)]
        public short CompanyId { get; set; }
        [Browsable(false)]
        [DataMember(Order = 6)]
        [Display(Name = "Account Type")]
        public short? AccountTypeId { get; set; }
        [DataMember(Order = 7)]
        [Browsable(false)]
        [Display(Name = "Bank Account")]
        public bool BankAccount { get; set; }
        #endregion

        #region constructor
        public CoAList()
        {
        }
       
        public CoAList(short _AccountId, string _AccountName, short _CompanyId, short _AccountTypeId, bool _BankAccount)
        {
            AccountId = _AccountId;
            AccountName = _AccountName;
            CompanyId = _CompanyId;
            AccountTypeId = _AccountTypeId;
            BankAccount = _BankAccount;
        }

        public CoAList(string _AccountCode, string _AccountName, string _AccountType, string _CompanyCode)
        {
            AccountCode = _AccountCode;
            AccountName = _AccountName;
            AccountType = _AccountType;
            CompanyCode = _CompanyCode;
        }


        #endregion


        #region internal methods
        internal static List<CoAList> Get(string _userId)
        {
            return getCoAs(_userId);
        }

        //internal static DataTable GetDT(string _userId)
        //{
        //    return AgilityHelper.ListToDataTable(getCoAs(_userId));
        //}
        #endregion

        #region private methods
        private static List<CoAList> getCoAs(string _userId)
        {
            List<CoAList> lstCoA = new List<CoAList>();
            DbCommand dbCommand = db.GetStoredProcCommand("getChartofAccountsList");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            {
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds != null && ds.Tables.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            lstCoA.Add(new CoAList(
                                 dr["AccountCode"].ToString(),
                                dr["AccountName"].ToString(),
                                dr["AccountType"].ToString(),
                                dr["CompanyName"].ToString()));
                        }
                    }
                }
            }
            return lstCoA;
        }

        //internal static List<CoAList> getBankAccounts(string _userId)
        //{
        //    List<CoAList> lstChartofAccounts = new List<CoAList>();
        //    using (DbCommand dbCommand = db.GetStoredProcCommand("getBankAccountCodeList"))
        //    {
        //        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
        //        using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
        //        {
        //            if (dt != null)
        //            {
        //                foreach (DataRow dr in dt.Rows)
        //                {
        //                    lstChartofAccounts.Add(new CoAList(
        //                        dr["AccountCode"].ToString(),
        //                        dr["AccountName"].ToString(),
        //                       Convert.ToInt16(dr["CompanyId"])));
        //                }
        //            }
        //        }
        //    }
        //    return lstChartofAccounts;
        //}

        //internal static List<CoAList> getCompanyByAccountList(string userid)
        //{
        //    List<CoAList> lstChartofAccounts = new List<CoAList>();
        //    using (DbCommand dbCommand = db.GetStoredProcCommand("getCompanyByAccountList"))
        //    {
        //        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, userid);
        //        using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
        //        {
        //            if (dt != null)
        //            {
        //                foreach (DataRow dr in dt.Rows)
        //                {
        //                    lstChartofAccounts.Add(new CoAList(
        //                        dr["AccountCode"].ToString(),
        //                        dr["AccountName"].ToString(),
        //                       Convert.ToInt16(dr["CompanyId"])));
        //                }
        //            }
        //        }
        //    }
        //    return lstChartofAccounts;
        //}

        //internal static List<CoAList> getPFReceivableAccountList(string userid)
        //{
        //    List<CoAList> lstChartofAccounts = new List<CoAList>();
        //    using (DbCommand dbCommand = db.GetStoredProcCommand("getPFReceivableAccountList"))

        //    {
        //        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, userid);
        //        using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
        //        {
        //            if (dt != null)
        //            {
        //                foreach (DataRow dr in dt.Rows)
        //                {
        //                    lstChartofAccounts.Add(new CoAList(
        //                        dr["AccountCode"].ToString(),
        //                        dr["AccountName"].ToString(),
        //                       Convert.ToInt16(dr["CompanyId"])));
        //                }
        //            }
        //        }
        //    }
        //    return lstChartofAccounts;
        //}

        internal static List<CoAList> getCOAsList(string userid)
        {
            List<CoAList> lstChartofAccounts = new List<CoAList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getCOAs"))

            {
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, userid);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstChartofAccounts.Add(new CoAList(
                               Convert.ToInt16(dr["AccountId"]),
                                dr["AccountName"].ToString(),
                               Convert.ToInt16(dr["CompanyId"]),
                               Convert.ToInt16(dr["AccountTypeId"]),
                               Convert.ToBoolean(dr["BankAccount"])));
                        }
                    }
                }
            }
            return lstChartofAccounts;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}