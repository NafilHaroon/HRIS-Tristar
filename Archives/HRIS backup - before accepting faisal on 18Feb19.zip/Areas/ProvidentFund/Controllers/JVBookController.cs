﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.ProvidentFund.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.ProvidentFund.Controllers
{
    [NoCache]
    [Authorize]
    public class JVBookController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                JVBook _jv = new JVBook();
                ModelState.Clear();
                return Json(new { success = true, JVBook = _jv, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(JVBook _jv)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_jv);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (JVBook.Save(_jv, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(string _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                JVBook _jv = JVBook.Get(_keyId);
                if (_jv == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The JV Book Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, JVBook = _jv, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new JVBookList()),
                    rowData = JVBookList.Get(Session["UserId"].ToString())
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Json Method
        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    lstCompanyAccount = getCompanyAccounts(Convert.ToInt16(Session["CompanyId"])),
                    lstCompany = GetCompany(Convert.ToInt16(Session["CompanyId"]))
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        public List<CompanyList> GetCompany(short _CompanyId)
        {
            List<CompanyList> c = CompanyList.Get(Session["UserId"].ToString(), true).Where(x => x.CompanyId == _CompanyId).ToList();
            return c;
        }

        public List<CoAList> getCompanyAccounts(short _CompanyId)
        {
            List <CoAList> co = CoAList.getCOAsList(Session["UserId"].ToString()).Where(x => x.CompanyId == _CompanyId).ToList();
            return co;
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'JV Book'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(JVBook _jv)
        {
            if (!string.IsNullOrEmpty(_jv.VoucherNumber))
                ModelState.AddModelError("Validation", "=> No further changes can be made to this JV Book at this stage");

            if (!_jv.VoucherDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Voucher Date"));

            if (!_jv.CompanyId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company"));

            if (_jv.Details.Count == 0)
            {
                ModelState.AddModelError("Validation", "=> Atleast one Account  must exist in JV Book to perform save operation");
            }
            else if (_jv.Details.Where(x => !x.AccountId.HasValue).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Account"));

            else if (_jv.Details.GroupBy(x => x.AccountId).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Account  used in JV Book must be unique");

            if (_jv.Details.Where(x => x.Credit < 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixZero("Credit"));

            if (_jv.Details.Where(x => x.Debit < 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixZero("Debit"));

            var DB = _jv.Details.Sum(x => x.Debit);
            var CR = _jv.Details.Sum(x => x.Credit);
            if (DB != CR)
                ModelState.AddModelError("Validation", "=> Debit and Credit total must be equal to complete the JV. Please make them equal before saving the entry!");
        }
        #endregion
    }
}


