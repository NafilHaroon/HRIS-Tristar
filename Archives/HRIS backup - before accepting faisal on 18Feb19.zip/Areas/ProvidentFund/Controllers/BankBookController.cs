﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.ProvidentFund.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.ProvidentFund.Controllers
{
    [NoCache]
    [Authorize]
    public class BankBookController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpGet]
        public JsonResult Add()
        {
            try
            {
                BankBook _bb = new BankBook();
                ModelState.Clear();
                return Json(new { success = true, BankBook = _bb, session = AgilityEnums.formMode.Add.ToString() }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Save(BankBook _bb)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_bb);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (BankBook.Save(_bb, Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Save operation completed successfully", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Get(string _keyId)
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                BankBook _bb = BankBook.Get(_keyId);
                if (_bb == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Bank Book Id doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, BankBook = _bb, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult Search()
        {
            var _data = new object();
            try
            {
                return Json(new
                {
                    success = true,
                    columnDefs = ColumnDefinition.getColDef(new BankBookList()),
                    rowData = BankBookList.Get(Session["UserId"].ToString())
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region Json Method
        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    lstBankAccount = getBankAccounts(Convert.ToInt16(Session["CompanyId"])),
                    lstCompanyAccount = getCompanyAccounts(Convert.ToInt16(Session["CompanyId"])),
                    lstCompany = GetCompany(Convert.ToInt16(Session["CompanyId"]))

            }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        public List<CompanyList> GetCompany(short _CompanyId)
        {
            List<CompanyList> c = CompanyList.Get(Session["UserId"].ToString(), true).Where(x => x.CompanyId == _CompanyId).ToList();
            return c;
        }

        public List<CoAList> getCompanyAccounts(short _CompanyId)
        {
            List<CoAList> co = CoAList.getCOAsList(Session["UserId"].ToString()).Where(x => x.CompanyId == _CompanyId).ToList();
            return co;
        }

        public List<CoAList> getBankAccounts(short _CompanyId)
        {
            List<CoAList> co = CoAList.getCOAsList(Session["UserId"].ToString()).Where(x => x.CompanyId == _CompanyId &&  x.BankAccount == true).ToList();
            return co;
        }

        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Bank Book'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(BankBook _bb)
        {
            if (!string.IsNullOrEmpty(_bb.VoucherNumber))
                ModelState.AddModelError("Validation", "=> No further changes can be made to this Bank Book at this stage");

            if (!_bb.VoucherDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Voucher Date"));

            if (!_bb.CompanyId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company"));

            if (!_bb.ChequeDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Cheque Date"));

            if (!_bb.BankAccountId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Bank Book"));

            if (string.IsNullOrEmpty(_bb.ChequeNumber))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Cheque Number"));
            
            if (_bb.Details.Count == 0)
            {
                ModelState.AddModelError("Validation", "=> Atleast one Account  must exist in Bank Book to perform save operation");
            }

            else if (_bb.Details.Where(x => !x.AccountId.HasValue).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Account"));

            else if (_bb.Details.GroupBy(x => x.AccountId).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Account  used in Bank Book must be unique");

            if (_bb.Details.Where(x => x.Credit < 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixZero("Credit"));

            if (_bb.Details.Where(x => x.Debit < 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixZero("Debit"));
        }
        #endregion
    }
}


