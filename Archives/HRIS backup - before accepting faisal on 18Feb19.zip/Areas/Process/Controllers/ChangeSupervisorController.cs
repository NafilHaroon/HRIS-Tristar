﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Process.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class ChangeSupervisorController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save(ChangeSupervisor _cs)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(_cs);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (ChangeSupervisor.Update(_cs, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        msg = new { success = true, message = Success, session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                if (!ModelState.IsValid)
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Json Method
        [HttpGet]
        public JsonResult GetLookups()
        {
            try
            {
                return Json(new
                {
                    success = true,
                    lstBranch = BranchList.Get(Session["UserId"].ToString(), true),
                    lstDepartment = DepartmentList.Get(true),
                    lstSupervisor = EmployeeList.Get(Session["UserId"], Session["CompanyId"])                  
                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        //}
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName =  'Change Supervisor'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private void validate(ChangeSupervisor _cs)
        {            

            if (string.IsNullOrEmpty(_cs.DepartmentCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Department"));

            if (!_cs.CurrentSuperVisorId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Current Supervisor"));

            if (!_cs.NewSupervisorId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("New Supervisor"));

            if (_cs.CurrentSuperVisorId == _cs.NewSupervisorId)
                ModelState.AddModelError("Validation", "New Supervisor cannot be same as Current Supervisor");
        }
        #endregion
    }
}