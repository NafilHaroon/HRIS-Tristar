﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class GenerateSalaryController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save(bool _GenerateOnlyNew)
        {
            var msg = new Object();
            try
            {
                #region save to db
                if (ModelState.IsValid)
                {
                    if (MonthlySalary.GenerateSalary(Session["UserId"].ToString(), _GenerateOnlyNew))
                    {
                        msg = new
                        {
                            success = true,
                            message = "Salary for the month of" + Session["CurrentMonth"].ToString() + "-" + Convert.ToInt32(Session["CurrentYear"]) +
                             " generated successfully.",
                            session = AgilityEnums.formMode.Initialize.ToString()
                        };
                    }
                }
                if (!ModelState.IsValid)
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        #endregion


        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName =  'Generate Current Month Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }
        #endregion
    }
}