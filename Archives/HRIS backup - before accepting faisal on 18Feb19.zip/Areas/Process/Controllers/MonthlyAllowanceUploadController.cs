﻿using Excel;
using HRIS.Areas.Common.Models;
using HRIS.Areas.Process.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class MonthlyAllowanceUploadController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save(MonthlyAllowance _MA)
        {
            var msg = new Object();
            MonthlyAllowance _ma = new MonthlyAllowance();
            HttpPostedFileBase file = Request.Files["UploadedFile"];
            try
            {
                #region save to db
                if (ModelState.IsValid)
                {
                    ProcessUploadAttendace(file, out _ma);
                    msg = new { success = true, MonthlyAllowanceUpload = _ma, session = AgilityEnums.formMode.Initialize.ToString() };
                }
                if (!ModelState.IsValid)
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, MonthlyAllowanceUpload = _ma, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region upload function
        private bool ProcessUploadAttendace(HttpPostedFileBase file, out MonthlyAllowance lstau)
        {
            lstau = new MonthlyAllowance();
            byte[] fileBytes = new byte[file.ContentLength];
            var data = file.InputStream.Read(fileBytes, 0, file.ContentLength);
            MemoryStream stream = new MemoryStream(fileBytes);
            IExcelDataReader xlReader = null;
            bool isXlsx = file.ContentType.Contains("openxmlformats");
            xlReader = isXlsx ? ExcelReaderFactory.CreateOpenXmlReader(stream) : ExcelReaderFactory.CreateBinaryReader(stream);
            xlReader.IsFirstRowAsColumnNames = true;
            DataSet dsXL = xlReader.AsDataSet();

            if (dsXL.Tables.Count == 0)
                throw new Exception("The selected file doesn't contain any worksheet");
            else if (dsXL.Tables.IndexOf("MonthlyAllowance") < 0)
                throw new Exception("The selected file doesn't contain any worksheet with the name 'MonthlyAllowance'");


            DataTable dtMonthlyAllowance = dsXL.Tables["MonthlyAllowance"];

            if (dtMonthlyAllowance.Columns.IndexOf("EmployeeCode") < 0)
                throw new Exception("Employee Code column was not found under 'MonthlyAllowance' worksheet");
            else if (dtMonthlyAllowance.Columns.IndexOf("HeadId") < 0)
                throw new Exception("Head Id column was not found under 'MonthlyAllowance' worksheet");
            else if (dtMonthlyAllowance.Columns.IndexOf("Remarks") < 0)
                throw new Exception("Remarks column was not found under 'MonthlyAllowance' worksheet");
            else if (dtMonthlyAllowance.Columns.IndexOf("Amount") < 0)
                throw new Exception("Amount column was not found under 'MonthlyAllowance' worksheet");




            foreach (DataRow dr in dtMonthlyAllowance.Rows)
            {
                try
                {
                    if (dr["EmployeeCode"] == DBNull.Value)
                        lstau.Details.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0, 0, "", "Employee Code Column can't be empty"));

                    else if (dr["HeadId"] == DBNull.Value)
                        lstau.Details.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0, 0, "", "Head Id column can't be empty"));

                    else if (dr["Remarks"] == DBNull.Value)
                        lstau.Details.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0, 0, "", "Allowed Days column can't be empty"));

                    else if (dr["Amount"] == DBNull.Value || Convert.ToDecimal(dr["Amount"]) == 0)
                        lstau.Details.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0, 0, "", " Amount column can't be empty"));

                    else
                    {
                        MonthlyAllowance _au = new MonthlyAllowance(
                        dr["EmployeeCode"].ToString(),
                        Convert.ToInt16(dr["HeadId"]),
                        Convert.ToDecimal(dr["Amount"]),
                        dr["Remarks"].ToString(), "");

                        MonthlyAllowance.Upload(_au, Session["UserId"].ToString());
                        lstau.Details.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0, 0, "", "Success"));
                    }
                }
                catch (Exception ex)
                {
                    lstau.Details.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0, 0, "", ex.Message));
                }

            }
            return true;
        }
        #endregion


        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Upload Monthly Allowance'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        public FileResult DownloadMATemplate()
        {
            return new FilePathResult(@"~\Content\template\MonthlyAllowanceUpload.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }

        #endregion
    }
}