﻿using Excel;
using HRIS.Areas.Common.Models;
using HRIS.Areas.Process.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class AttendanceUploadController : Controller
    {
        #region public methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public JsonResult Save( )
        {
            var msg = new Object();
            AttendanceUpload _au = new AttendanceUpload();
            HttpPostedFileBase file = Request.Files["UploadedFile"];
            try
            {
                #region save to db
                if (ModelState.IsValid)
                {
                    ProcessUploadAttendace(file, out _au);
                    msg = new { success = true, AttendanceUpload = _au,  session = AgilityEnums.formMode.Initialize.ToString() };               
                }
                if (!ModelState.IsValid)
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, AttendanceUpload = _au, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region upload function
        private bool ProcessUploadAttendace(HttpPostedFileBase file, out AttendanceUpload lstau)
        {
            lstau = new AttendanceUpload();
            byte[] fileBytes = new byte[file.ContentLength];
            var data = file.InputStream.Read(fileBytes, 0, file.ContentLength);
            MemoryStream stream = new MemoryStream(fileBytes);
            IExcelDataReader xlReader = null;
            bool isXlsx = file.ContentType.Contains("openxmlformats");
            xlReader = isXlsx ? ExcelReaderFactory.CreateOpenXmlReader(stream) : ExcelReaderFactory.CreateBinaryReader(stream);
            xlReader.IsFirstRowAsColumnNames = true;
            DataSet dsXL = xlReader.AsDataSet();

            if (dsXL.Tables.Count == 0)
                throw new Exception("The selected file doesn't contain any worksheet");
            else if (dsXL.Tables.IndexOf("Attendance") < 0)
                throw new Exception("The selected file doesn't contain any worksheet with the name 'Attendance'");
            
            DataTable dtAttendance = dsXL.Tables["Attendance"];

            if (dtAttendance.Columns.IndexOf("EmployeeCode") < 0)
                throw new Exception("Employee Code column was not found under 'Attendance' worksheet");
            else if (dtAttendance.Columns.IndexOf("AttendanceDate") < 0)
                throw new Exception("Attendance Date column was not found under 'Attendance' worksheet");
            else if (dtAttendance.Columns.IndexOf("AttendanceTime") < 0)
                throw new Exception("Attendance Time column was not found under 'Attendance' worksheet");
                                 
            foreach (DataRow dr in dtAttendance.Rows)
            {
                try
                {
                    DateTime _date = new DateTime();
                    if (dr["EmployeeCode"] == DBNull.Value)
                        lstau.Details.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Employee Code Column can't be empty"));
                    else if (dr["AttendanceDate"] == DBNull.Value)
                        lstau.Details.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Date column can't be empty"));
                    else if (dr["AttendanceTime"] == DBNull.Value)
                        lstau.Details.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Time column can't be empty"));
                    else if (!DateTime.TryParse(dr["AttendanceDate"].ToString(), out _date))
                        lstau.Details.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Date must be a valid Date"));
                    else if (!DateTime.TryParse(dr["AttendanceTime"].ToString(), out _date))
                        lstau.Details.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Time must be a valid Time"));

                    else
                    {
                        AttendanceUpload _au = new AttendanceUpload(
                        dr["EmployeeCode"].ToString(),
                        Convert.ToDateTime(dr["AttendanceDate"]),
                        Convert.ToDateTime(dr["AttendanceTime"]), "");

                        AttendanceUpload.Upload(_au, Session["UserId"].ToString());
                        lstau.Details.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Success"));
                    }
                }
                catch (Exception ex)
                {
                    lstau.Details.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), ex.Message));
                }

            }
            return true;
        }
        #endregion


        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName =  'Upload Attendance Data from Excel'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        public FileResult DownloadAUTemplate()
        {
            return new FilePathResult(@"~\Content\template\AttendanceUpload.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }

        #endregion
    }
}