﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Process.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class CloseMonthSalaryController : Controller
    {
       
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }        
        [HttpPost]
        public JsonResult Save(CloseMonthSalary _cms)
        {
            var msg = new Object();
            try
            {
                #region save to db
                if (ModelState.IsValid)
                {
                    if (CloseMonthSalary.CloseCurrentMonthSalary( Session["UserId"].ToString()))
                    {
                        msg = new { success = true, message = "Month Salary is closed and Verified", session = AgilityEnums.formMode.Initialize.ToString() };
                    }
                }
                else
                {
                    msg = new
                    {
                        success = false,
                        message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        session = AgilityEnums.formMode.Edit.ToString()
                    };
                }
                #endregion
            }
            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = AgilityEnums.formMode.Edit.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public JsonResult Get()
        {
            var msg = new Object(); AgilityEnums.formMode _formMode = AgilityEnums.formMode.Initialize;
            try
            {
                CloseMonthSalary _cms = CloseMonthSalary.getCurrentMonthSalary(Session["UserId"].ToString());
                if (_cms == null)
                {
                    _formMode = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Montly Salary  doesn't exist or you donot have permission to access it");
                }
                _formMode = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, CloseMonthSalary = _cms, session = _formMode.ToString() };
            }

            catch (Exception ex)
            {
                msg = new { success = false, message = ex.Message, session = _formMode.ToString() };
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region private methods
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Verify & Close Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        #endregion
    }
}

