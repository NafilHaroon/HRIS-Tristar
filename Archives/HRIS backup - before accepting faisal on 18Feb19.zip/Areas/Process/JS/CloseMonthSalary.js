﻿baseURL = "/HRIS/Process/CloseMonthSalary/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);


app.controller('CloseMonthSalaryController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        getCurrentMonthSalary();
    };   
    //#endregion

    //#region toolbar actions     
    $scope.tbSave = function () {
        $scope.CloseMonthSalary.Details = getCloseMonthSalaryDataFromGrid();
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.CloseMonthSalary
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
                getCurrentMonthSalary();
               // setGridData();
                clearForm();
            }
           // setFormControls(result.data.session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };     

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
       
    //#endregion

    //#region form functions   
    function getCurrentMonthSalary() {
        $http({
            type: "Get",
            url: baseURL + "Get",
            dataType: "JSON"
        }).then(result => {
            clearForm();
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                $scope.CloseMonthSalary = result.data.CloseMonthSalary;
                setGridData();
            }
           // setFormControls(result.data.session);
        }, errorMsg => {
            alert(result);
        });
    }
    //#endregion

    //#region local function
    function clearForm() {
        $scope.CloseMonthSalary = {};
        $scope.errors = [];
    }
    //#endregion

    //#region grid setup
    //#region Bank Letter Grid Definition & functions
    var colCloseMonthSalary = [
        {
            headerName: "Branch", field: "BranchName",  editable: false,
            width: 150
        },
        {
            headerName: "Dept", field: "DepartmentName",  editable: false,
            width: 150
        },
        {
            headerName: "Employee", field: "EmployeeName",  editable: false,
            width: 150
        },
        {
            headerName: "Designation", field: "Designation",  editable: false,
            width: 150
        },
        {
            headerName: "Absent", field: "Absent", type: "numericColumn", editable: false,
            width: 80
        },
        {
            headerName: "Leave", field: "Leave", type: "numericColumn", editable: false,
            width: 80
        },
        {
            headerName: "Gross", field: "GrossSalary", type: "numericColumn",valueFormatter: formatNumbers, valueParser: numberValueParser, editable: false,
            width: 100
        },
        {
            headerName: "Allowance", field: "OtherAllowance", type: "numericColumn",valueFormatter: formatNumbers, valueParser: numberValueParser, editable: false,
            width: 100
        },
        {
            headerName: "Personal", field: "PersonalDedcution", type: "numericColumn",valueFormatter: formatNumbers, valueParser: numberValueParser, editable: false,
            width: 100
        },
        {
            headerName: "Absent", field: "AbsentDedcution", type: "numericColumn",valueFormatter: formatNumbers, valueParser: numberValueParser, editable: false,
            width: 100
        },
        {
            headerName: "Other", field: "OtherDedcution", type: "numericColumn",valueFormatter: formatNumbers, valueParser: numberValueParser, editable: false,
            width: 100
        },
        {
            headerName: "Total", field: "TotalSalary", type: "numericColumn",valueFormatter: formatNumbers, valueParser: numberValueParser,  editable: false,
            width: 100
        },
    ];

    $scope.grdOptCloseMonthSalary = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        //defaultColDef: {
        //    editable: allowEdit.bind(this)
        //},
        columnDefs: colCloseMonthSalary,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        //enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        onGridReady: (grid) => {
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = false;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',

    };    

    function getCloseMonthSalaryDataFromGrid() {
        let rowData = [];
        $scope.grdOptCloseMonthSalary.api.forEachNode(node => rowData.push(node.data));
        return rowData;
    }

    //#endregion       

    //#region general functions
    function setGridData() {
        if ($scope.CloseMonthSalary != []) {
            $scope.grdOptCloseMonthSalary.api.setRowData($scope.CloseMonthSalary.Details);
        }
        else { $scope.grdOptCloseMonthSalary.api.setRowData([]); }
    }

    //$scope.sum = function (items, prop) {
    //    return items.reduce(function (a, b) {
    //        return a + b[prop];
    //    }, 0);
    //};
    //#endregion
    //#endregion

});