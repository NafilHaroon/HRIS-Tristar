﻿
var app = angular.module('HRIS', []);

app.controller('CashSalaryEmailSetupController', function ($scope, $http, $window) {

    $scope.load = function () {

        $http({
                    method: "POST",
                    url: "/CashSalaryEmailSetup/Add"
                }).success(function (result) {
                    $scope.errors = [];
                    $scope.CashSalaryEmailSetup = result.data;
                    LoadDropDown();
                }).catch(function (result) {

                });

    };


    
    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/CashSalaryEmailSetup/Save",
            data: $scope.CashSalaryEmailSetup
        }).success(function (result) {
            
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.CashSalaryEmailSetup = result.data;
                
            }
            else {
                alert(result.Message);
                $scope.ClearCS();
                $scope.CashSalaryEmailSetup = result.data;
            }
        }).error(function (result) {
          
        });
    }    
      

    //$scope.Add = function () {
    //    $http({
    //        method: "POST",
    //        url: "/CashSalaryEmailSetup/Add"
    //    }).success(function (result) {
    //        $scope.errors = [];
    //        $scope.CashSalaryEmailSetup = result.data;

    //    }).catch(function (result) {

    //    });
    //}

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/CashSalaryEmailSetup/Undo"
        }).success(function (result) {
            $scope.CashSalaryEmailSetup = result.data;
            $scope.errors = [];
            $scope.ClearCS();
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/CashSalaryEmailSetup/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }
    
    $scope.toggleEdit = function (m) {
        m.showEdit = m.showEdit ? false : true;
    }


    $scope.AddCS = function () {
        //Add the new item to the Array.
        var BC = document.getElementById('BranchCode').value;
        var CI = document.getElementById('CompanyId').value;
        var CN = document.getElementById('ContactName').value;
        var ET = document.getElementById('EmailTo').value;
        var ED = document.getElementById('EmailCC').value;
        var EB = document.getElementById('EmailBCC').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;



        if (BC != "" && CI != "" && CN != "" && ET != ""&& ED != "") {
            var detailid;
            var ma = {};
            //Math.max.apply(Math, $scope.CashSalaryEmailSetup.Details.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;

            if (Index != "")
                $scope.CashSalaryEmailSetup.Details.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }

            ma.BranchCode = BC;
            ma.CompanyId = CI;
            ma.ContactName = CN;
            ma.EmailTo = ET;
            ma.EmailCC = ED;
            ma.EmailBCC = EB;
            $scope.CashSalaryEmailSetup.Details.push(ma);
            $scope.ClearCS();
            ma = {};
        }
        else {
            alert("Require  Valid Branch, Company, ContactName, EmailTo && Email CC.Before Saving Value to Grid.");
            return false;
        }
    }
    $scope.ClearCS = function () {
        //Clear the TextBoxes.
        document.getElementById('BranchCode').value="";
        document.getElementById('CompanyId').value = "";
        document.getElementById('ContactName').value = "";
        document.getElementById('EmailTo').value = "";
        document.getElementById('EmailCC').value = "";
        document.getElementById('EmailBCC').value = "";
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
    }
    $scope.EditCS = function (m, index) {
        //Add the new item to the Array.
        
        document.getElementById('BranchCode').value = m.BranchCode;
        document.getElementById('CompanyId').value = m.CompanyId;
        document.getElementById('ContactName').value = m.ContactName;
        document.getElementById('EmailTo').value = m.EmailTo;
        document.getElementById('EmailCC').value = m.EmailCC;
        document.getElementById('EmailBCC').value = m.EmailBCC;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
    $scope.RemoveCS = function (index) {
        if ($window.confirm("Do you want to delete")) {
            //Remove the item from Array using Index.
            $scope.CashSalaryEmailSetup.Details.splice(index, 1);
        }
    }

  
    function LoadDropDown()
    {
        $http.get('/CashSalaryEmailSetup/GetBranch').then(function (d) {
            $scope.Branchlist = d.data;
        }, function () {
            alert('failed');
        }); 


        $http.get('/CashSalaryEmailSetup/GetCompany').then(function (d) {
            $scope.Companylist = d.data;
        }, function () {
            alert('failed');
        });
    }   
        
});