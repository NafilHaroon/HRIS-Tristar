﻿baseURL = "/HRIS/Process/PostSalary/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

app.controller('PostSalaryController', function ($scope, $rootScope, $http, $uibModal) {
    //#region toolbar actions
    $scope.tbSave = function (res) {
        $http({
            method: "POST",
            url: baseURL + "Save"
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
            }
          //  setFormControls(result.data.Session);
        }, errorMsg => {
            alert(errorMsg);
        });
    };

    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion   


});