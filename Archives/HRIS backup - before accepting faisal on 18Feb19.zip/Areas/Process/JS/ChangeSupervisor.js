﻿baseURL = "/HRIS/Process/ChangeSupervisor/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

$(document).ready(function () {
    $('#ddBranch').focus();
});

app.controller('ChangeSupervisorController', function ($scope, $rootScope, $http, $uibModal) {
    //#region form loading events
    $scope.formLoaded = function () {
        loadDropDown();
    };

    function loadDropDown() {
        $http.get(baseURL + 'GetLookups').then(result => {
            $scope.lstBranch = result.data.lstBranch;
            $scope.lstDepartment = result.data.lstDepartment;
            $scope.lstSupervisor = result.data.lstSupervisor;
        }, errorMsg => {
            alert(errorMsg);
        });
    }
    //#endregion



    //#region toolbar actions
    $scope.tbSave = function (res) {
        $http({
            method: "POST",
            url: baseURL + "Save",
            data: $scope.ChangeSupervisor
        }).then(result => {
            $scope.errors = [];
            if (!result.data.success) {
                $scope.errors = [result.data.message];
            }
            else {
                alert(result.data.message);
            }
        }, errorMsg => {
            alert(errorMsg);
        });
    };
    
    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion   


});