﻿baseURL = "/HRIS/Process/AttendanceUpload/";
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module('HRIS', ["ui.bootstrap", "agGrid"]);

app.controller('AttendanceUploadController', function ($scope, $rootScope, $http, $uibModal) {
    //#region toolbar actions
    $scope.tbSave = function (res) {
        if (validateFile() == true) {
            //File Upload//
            var formData = new FormData();
            var totalFiles = document.getElementById("fuAttachment").files.length;

            for (var i = 0; i < totalFiles; i++) {
                var file = document.getElementById("fuAttachment").files[i];
                formData.append("UploadedFile", file);
            }
            //File Upload//

            $http({
                method: "POST",
                url: baseURL + "Save",
                headers: { "Content-Type": undefined },
                transformRequest: function (data) {
                    return formData;//NOTICE THIS RETURN WHICH WAS MISSING
                },
            }).then(result => {
                $scope.errors = [];
                if (!result.data.success) {
                    $scope.errors = [result.data.message];
                }                
                $scope.AttendanceUpload = result.data.AttendanceUpload;
                 maskDates();
                setGridData();               
                clearForm();
                //setFormControls(result.data.Session);
            }, errorMsg => {
                alert(errorMsg);
            });
        }      
    };
    
    $scope.tbExit = function () {
        $scope = null;
        window.location.href = '/HRIS/Common/Common/Index';
    };
    //#endregion   

    //#region local function
    function clearForm() {
        $('#fuAttachment').val("");
    }
    //#endregion

    //#region date functions 
    function maskDates() {
        if ($scope.AttendanceUpload.Details != null) {
            for (i = 0; i < $scope.AttendanceUpload.Details.length; i++) {
                $scope.AttendanceUpload.Details[i]["AttendanceDate"] = formatDate($scope.AttendanceUpload.Details[i]["AttendanceDate"]);
                $scope.AttendanceUpload.Details[i]["AttendanceTime"] = formatTime($scope.AttendanceUpload.Details[i]["AttendanceTime"]);
            }
        }

    }
    //#endregion

    //#region grid setup
    //#region Attendance  Grid Definition & functions
    var colAttUpload = [
        {
            headerName: "EmployeeCode", field: "EmployeeCode",  editable: false,
            width: 120
        },
        {
            headerName: "Date", field: "AttendanceDate",  editable: false,
            width: 120
        },
        {
            headerName: "Time", field: "AttendanceTime", editable: false,
            width: 120
        },
        {
            headerName: "Status", field: "Status", editable: false,
            width: 350
        },
    ];

    $scope.grdOptAttUpload = {
        headerHeight: 25,
        rowHeight: 32,
        animateRows: true,
        //defaultColDef: {
        //    editable: allowEdit.bind(this)
        //},
        columnDefs: colAttUpload,
        rowData: [],
        rowSelection: 'single',
        rowDeselection: true,
        enableColResize: true,
        enableSorting: true,
        singleClickEdit: true,
        onGridReady: (grid) => {            
        },
        getRowStyle: function (params) {
            if (params.node.rowPinned) {
                return { 'font-weight': 'bold', 'color': 'blue' };
            }
        },
        onCellValueChanged: function (params) {
            if (!params.data.Add)
                params.data.Edit = false;
        },
        overlayLoadingTemplate: '<span class="ag-overlay-loading-center">Please wait while we are fetching requested records from database</span>',
        overlayNoRowsTemplate: '<span style="padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow; color:red;">No rows available to display here</span>',
       
    }; 
    //#endregion       

    //#region general functions
    function setGridData() {
        if ($scope.AttendanceUpload != []) {
        $scope.grdOptAttUpload.api.setRowData($scope.AttendanceUpload.Details);
        }
        else { $scope.grdOptAttUpload.api.setRowData([]); }
    }

    $scope.tbExport = function () {
        var params = {
            skipHeader: false,
            allColumns: true,
            skipFooters: true,
            skipGroups: true,
            fileName: "AttendanceData.csv"
        };
        $scope.grdOptAttUpload.api.exportDataAsCsv(params);
    }
    //#endregion
    //#endregion


    //#region general functions 
    function validateFile() {     

        var fu = document.getElementById("fuAttachment");
        if (fu.value == "") {
            alert("Please select valid  file to be uploaded before hitting upload button");
            return false;
        }
        else {
            var validExts = new Array(".xlsx", ".xls");
            var fileExt = fu.value.substring(fu.value.lastIndexOf('.'));
            if (validExts.indexOf(fileExt) < 0 && fileExt != "") {
                alert("Invalid file selected, valid files are of " +
                    validExts.toString() + " types.");
                $(fu).val("");
                return false;
            }
            else {
               
                return true;
            }
        }
    };
    //#endregion



});