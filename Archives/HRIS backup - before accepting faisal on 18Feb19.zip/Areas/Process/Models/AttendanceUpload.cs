﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class AttendanceUpload: IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }

        [Display(Name = "Attendance Date")]
        public DateTime? AttendanceDate { get; set; }
        [Display(Name = "Attendance Time")]
        public DateTime? AttendanceTime { get; set; }
        [Display(Name = "Status")]
        public string Status { get; set; }

        public List<AttendanceUpload> Details { get; set; }

        #endregion

        #region Constructor

        public AttendanceUpload()
        {
            Details = new List<AttendanceUpload>();
        }
        public AttendanceUpload(string _EmployeeCode,
            DateTime _AttendanceDate, DateTime _AttendanceTime, string _status)
        {
            EmployeeCode = _EmployeeCode;
            AttendanceDate = _AttendanceDate;
            AttendanceTime = _AttendanceTime;
            Status = _status;
        }
        #endregion

        #region internal methods

        internal static bool Upload(AttendanceUpload _au, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("SaveAttendanceUploadData"))
                {
                    db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _au.EmployeeCode);
                    db.AddInParameter(dbCommand, "AttendanceDate", SqlDbType.DateTime, _au.AttendanceDate);
                    db.AddInParameter(dbCommand, "AttendanceTime", SqlDbType.DateTime, _au.AttendanceTime);

                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);

                    db.ExecuteNonQuery(dbCommand);
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}