﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class CloseMonthSalaryDetail : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public string BranchName { get; set; }
        public string DepartmentName { get; set; }
        public string EmployeeName { get; set; }
        public string Designation { get; set; }
        public string AbsentDays { get; set; }
        public string LeaveDays { get; set; }
        public string GrossSalary { get; set; }
        public string OtherAllowances { get; set; }
        public string PersonalDeduction { get; set; }
        public string AbsentDeduction { get; set; }
        public string OtherDeduction { get; set; }
        public string TotalSalary { get; set; }
        public bool Verified { get; set; }
        public short EmployeeId { get; set; }
        #endregion

        #region constructor
        public CloseMonthSalaryDetail()
        {
        }

        public CloseMonthSalaryDetail(string _BranchName, string _DepartmentName, string _EmployeeName, string _Designation, string _AbsentDays,
            string _LeaveDays, string _GrossSalary, string _OtherAllowances, string _PersonalDeduction, string _AbsentDeduction,
            string _OtherDeduction, string _TotalSalary, bool _Verified, short _EmployeeId)
        {
            BranchName = _BranchName;
            DepartmentName = _DepartmentName;
            EmployeeName = _EmployeeName;
            Designation = _Designation;
            AbsentDays = _AbsentDays;
            LeaveDays = _LeaveDays;
            GrossSalary = _GrossSalary;
            OtherAllowances = _OtherAllowances;
            PersonalDeduction = _PersonalDeduction;
            AbsentDeduction = _AbsentDeduction;
            OtherDeduction = _OtherDeduction;
            TotalSalary = _TotalSalary;
            Verified = _Verified;
            EmployeeId = _EmployeeId;

        }
        #endregion

        #region internal methods
       
        #endregion

        #region internal methods
        internal static List<CloseMonthSalaryDetail> getMonthlySalary(string _userId)
        {
            List<CloseMonthSalaryDetail> lstdat = new List<CloseMonthSalaryDetail>();

            DbCommand dbCommand = db.GetStoredProcCommand("getMonthlySalarySummary");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new CloseMonthSalaryDetail(
                                dr["BranchName"].ToString(),
                                 dr["DepartmentName"].ToString(),
                                  dr["EmployeeName"].ToString(),
                                   dr["Designation"].ToString(),
                                    Convert.ToInt32(dr["AbsentDays"]).ToString("#,#.00;(#,#.00)"),
                                      Convert.ToInt32(dr["LeaveDays"]).ToString("#,#.00;(#,#.00)"),
                                         Convert.ToDouble(dr["GrossSalary"]).ToString("#,#.00;(#,#.00)"),
                                            Convert.ToDouble(dr["OtherAllowances"]).ToString("#,#.00;(#,#.00)"),
                                              Convert.ToDouble(dr["PersonalDeduction"]).ToString("#,#.00;(#,#.00)"),
                                                Convert.ToDouble(dr["AbsentDeduction"]).ToString("#,#.00;(#,#.00)"),
                                                 Convert.ToDouble(dr["OtherDeduction"]).ToString("#,#.00;(#,#.00)"),
                                                   Convert.ToDouble(dr["TotalSalary"]).ToString("#,#.00;(#,#.00)"),
                                                     Convert.ToBoolean(dr["Verified"]),
                                                      Convert.ToInt16(dr["EmployeeId"])));
                    }
                }
            }
            return lstdat;
        }


        //internal static bool CloseSalary (List<CloseMonthSalaryDetail> _details, string _userId, DbTransaction _transaction)
        //{
        //    try
        //    {
        //        foreach (CloseMonthSalaryDetail ms in _details)
        //        {
        //            using (DbCommand dbCommand = db.GetStoredProcCommand("CloseMonthSalary"))
        //            {
        //                db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, ms.EmployeeId);
        //                db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
        //                db.ExecuteNonQuery(dbCommand, _transaction);
        //            }
        //        }
        //        return true;
        //    }
        //    catch (Exception)
        //    { throw; }
        //}
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}