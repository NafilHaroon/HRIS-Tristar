﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class MonthlySalary : IDisposable
    {
         #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties       
        [Display(Name = "Month")]
        public string CurrentMonth { get; set; }
        [Display(Name = "Year")]
        public int CurrentYear { get; set; }
        public bool GenerateOnlyNew { get; set; }
        #endregion

        #region constructor
        public MonthlySalary()
        {
        }
        #endregion

        #region internal methods
        internal static MonthlySalary GetCurrentPeriod()
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("getCurrentPeriod"))
                {
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables[0].Rows.Count > 0)
                        {
                            using (MonthlySalary fp = new MonthlySalary())
                            {
                                DataRow dr = ds.Tables[0].Rows[0];
                                fp.CurrentMonth = dr["CurrentMonth"].ToString();
                                fp.CurrentYear = Convert.ToInt32(dr["CurrentYear"]);                             
                                return fp;
                            }
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Generate(string _userId, bool _generateOnlyNew)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("GenerateSalary"))
                {
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "GenerateOnlyNew", SqlDbType.Bit, _generateOnlyNew);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Post(string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("PostSalary"))
                {
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
        }
        #endregion
    }


    
}