﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Process.Models
{
    public class EmailSetupDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public string BranchCode { get; set; }
        public short? CompanyId{ get; set; }
        public string ContactName { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }
        public string EmailBCC { get; set; }
        public short DetailId { get; set; }
        public string Status { get; set; }
        #endregion

        #region constructor
        public EmailSetupDetail()
        {
            Status = "Added";
        }

        public EmailSetupDetail(string _BranchCode, short  _CompanyId, string _ContactName, string _EmailTo,
            string _EmailCC, string _EmailBCC, short _DetailId, string _itemState ="UnChanged")
        {
            BranchCode = _BranchCode;
            CompanyId = _CompanyId;
            ContactName = _ContactName;
            EmailTo = _EmailTo;
            EmailCC = _EmailCC;
            EmailBCC = _EmailBCC;
            DetailId = _DetailId;           

        }
        #endregion

        #region internal methods
        internal static List<EmailSetupDetail> GetDTCashSalary(string _userId)
        {
            return getCashSalary(_userId);
        }

        internal static List<EmailSetupDetail> GetDTProbationReminder(string _userId)
        {
            return getProbationReminder(_userId);
        }
        #endregion

        #region prviate methods
        private static List<EmailSetupDetail> getCashSalary(string _userId)
        {
            List<EmailSetupDetail> lstdat = new List<EmailSetupDetail>();

            DbCommand dbCommand = db.GetStoredProcCommand("getCashSalaryEmail");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new EmailSetupDetail(
                                dr["BranchCode"].ToString(),
                                  Convert.ToInt16(dr["CompanyId"]),
                                  dr["ContactName"].ToString(),
                                   dr["EmailTo"].ToString(),
                                   dr["EmailCC"].ToString(),
                                   dr["EmailBCC"].ToString(),
                                  Convert.ToInt16(dr["DetailId"])));
                    }
                }
            }
            return lstdat;
        }

        private static List<EmailSetupDetail> getProbationReminder(string _userId)
        {
            List<EmailSetupDetail> lstdat = new List<EmailSetupDetail>();

            DbCommand dbCommand = db.GetStoredProcCommand("getProbationReminderEmail");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new EmailSetupDetail(
                                dr["BranchCode"].ToString(),
                                Convert.ToInt16(dr["ComapanyId"]),
                                  dr["ContactName"].ToString(),
                                   dr["EmailTo"].ToString(),
                                   dr["EmailCC"].ToString(),
                                   dr["EmailBCC"].ToString(),
                                  Convert.ToInt16(dr["DetailId"])));
                    }
                }
            }
            return lstdat;
        }

        internal static bool SaveCashSalary(List<EmailSetupDetail> _details,  
            List<EmailSetupDetail> _originalDetails, DbTransaction _transaction)
        {
            try
            {
                foreach (EmailSetupDetail ms in getCDDetailChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveCashSalaryEmail"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, ms.DetailId);
                        db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, ms.BranchCode);
                        db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, ms.CompanyId);
                        db.AddInParameter(dbCommand, "ContactName", SqlDbType.VarChar, ms.ContactName);
                        db.AddInParameter(dbCommand, "EmailTo", SqlDbType.VarChar, ms.EmailTo);
                        db.AddInParameter(dbCommand, "EmailCC", SqlDbType.VarChar, ms.EmailCC);
                        db.AddInParameter(dbCommand, "EmailBCC", SqlDbType.VarChar, ms.EmailBCC);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                        ms.Status == "Added" ? "I" : (
                        ms.Status == "Deleted" ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool SaveProbationReminder(List<EmailSetupDetail> _details,
             List<EmailSetupDetail> _originalDetails, DbTransaction _transaction)
        {
            try
            {
                foreach (EmailSetupDetail ms in getCDDetailChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveProbationReminderEmail"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, ms.DetailId);
                        db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, ms.BranchCode);
                        db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, ms.CompanyId);
                        db.AddInParameter(dbCommand, "ContactName", SqlDbType.VarChar, ms.ContactName);
                        db.AddInParameter(dbCommand, "EmailTo", SqlDbType.VarChar, ms.EmailTo);
                        db.AddInParameter(dbCommand, "EmailCC", SqlDbType.VarChar, ms.EmailCC);
                        db.AddInParameter(dbCommand, "EmailBCC", SqlDbType.VarChar, ms.EmailBCC);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                        ms.Status == "Added" ? "I" : (
                        ms.Status == "Deleted" ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmailSetupDetail> getCDDetailChanges(List<EmailSetupDetail> details,
            List<EmailSetupDetail> originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmailSetupDetail> editedItems = (IEnumerable<EmailSetupDetail>)
                    (from actualItem in details
                     where AgilityHelper.InList(actualItem.Status,
                        "Edited", "Added")
                     select actualItem).Union(
                        from actualItem in originalDetails
                        where !
                        (from newItem in details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmailSetupDetail>();
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}