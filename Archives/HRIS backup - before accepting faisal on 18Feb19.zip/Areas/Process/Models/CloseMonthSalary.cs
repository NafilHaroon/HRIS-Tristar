﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class CloseMonthSalary : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties        
        public List<CloseMonthSalaryDetail> Details { get; set; }
        #endregion

        #region constructor
        public CloseMonthSalary()
        {
            Details = new List<CloseMonthSalaryDetail>();
        }
        #endregion


        #region internal methods
        internal static CloseMonthSalary getCurrentMonthSalary(string _userId)
        {
            try
            {
                using (CloseMonthSalary _csm = new CloseMonthSalary())
                {
                    _csm.Details = CloseMonthSalaryDetail.getMonthlySalary(_userId);
                    return _csm;
                }
            }
            catch (Exception)
            { throw; }
        }
        internal static bool CloseCurrentMonthSalary(string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("CloseMonthSalary"))
                {
                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }

        //internal static bool CloseCurrentMonthSalary(CloseMonthSalary _csm, string _userId)
        //{
        //    using (DbConnection dbconnection = db.CreateConnection())
        //    {
        //        dbconnection.Open();
        //        DbTransaction transaction = dbconnection.BeginTransaction();
        //        try
        //        {
        //           // CloseMonthSalaryDetail.CloseSalary(_csm.Details, _userId, transaction);
        //            transaction.Commit();
        //            return true;
        //        }
        //        catch (Exception)
        //        {
        //            transaction.Rollback();
        //            throw;
        //        }
        //    }
        //}
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}