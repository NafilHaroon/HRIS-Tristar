﻿using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class CashSalaryEmailSetup: IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public List<EmailSetupDetail> Details { get; set; }
        public List<EmailSetupDetail> donotUseDetails { get; set; }
        #endregion

        #region constructor
        public CashSalaryEmailSetup()
        {
            Details = new List<EmailSetupDetail>();
            donotUseDetails = new List<EmailSetupDetail>();
        }


        #endregion


        #region internal methods

        internal static CashSalaryEmailSetup GetCSE(string _userId)
        {
            try
            {
                using (CashSalaryEmailSetup _cd = new CashSalaryEmailSetup())
                {
                    _cd.donotUseDetails = EmailSetupDetail.GetDTCashSalary(_userId);
                    _cd.Details = _cd.donotUseDetails.Clone();
                    return _cd;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool SaveCSE(CashSalaryEmailSetup _cd)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    EmailSetupDetail.SaveCashSalary(_cd.Details, _cd.donotUseDetails, transaction);
                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }


        internal static CashSalaryEmailSetup GetPRE(string _userId)
        {
            try
            {
                using (CashSalaryEmailSetup _cd = new CashSalaryEmailSetup())
                {
                    _cd.donotUseDetails = EmailSetupDetail.GetDTProbationReminder(_userId);
                    _cd.Details = _cd.donotUseDetails.Clone();
                    return _cd;
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool SavePRE(CashSalaryEmailSetup _cd)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    EmailSetupDetail.SaveProbationReminder(_cd.Details, _cd.donotUseDetails, transaction);
                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}