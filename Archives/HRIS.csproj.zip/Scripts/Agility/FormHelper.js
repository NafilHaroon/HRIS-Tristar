﻿function setFormControls(formMode, allowAdd, allowEdit, allowDelete) {
    //this block is there to convert string values to boolean
    allowAdd = allowAdd != "False";
    allowEdit = allowEdit != "False";
    allowDelete = allowDelete != "False";
    //end of special block

    if (formMode == "Edit" || formMode == "Add") {
        $("#divMain input,select,textarea,label,button, a").prop("disabled", false);
        $("#divMain input[type=text],select:enabled")[0].disabled = true;
        $("#divMain select[accesskey='permanentReadOnly']").prop("disabled", true);
        
        $("#FooterButtons a").prop("disabled", true);
    }
    else {
        $("#divMain input,select,textarea,label,button,a[accesskey!='tabPanel']").prop("disabled", true);
        $("#FooterButtons a").prop("disabled", false);

        if (formMode == "Recall") {
            $('#divMain input[type="text"],select:disabled')[0].disabled = false;
        }
    }

    

    if (document.getElementById("btnAdd") != null)
        document.getElementById("btnAdd").disabled = !allowAdd || formMode != "Initialize";
    if (document.getElementById("btnEdit") != null)
        document.getElementById("btnEdit").disabled = !allowEdit || formMode != "ReadOnly";
    if (document.getElementById("btnDelete") != null)
        document.getElementById("btnDelete").disabled = !allowDelete || formMode != "ReadOnly";

    if (document.getElementById("btnSave") != null)
        document.getElementById("btnSave").disabled = formMode != "Edit" && formMode != "Add";

    if (formMode != "Initialize") {
        document.getElementById("btnFind").setAttribute("disabled", true);
    }
    else {
        document.getElementById("btnFind").removeAttribute("disabled");
    }

    document.getElementById("btnUndo").disabled = formMode == "Initialize" || formMode == "Review";
    document.getElementById("btnRecall").disabled = formMode != "Initialize";
    document.getElementById("btnExit").disabled = formMode != "Initialize" && formMode != "Review";

    if (formMode == "Edit" || formMode == "Add" || formMode == "Recall") {
        try {
            $(':input(input[type="text"],select):not([class~="dateField"]):not([type="checkbox"]):enabled:visible:not([readonly]):first').focus();
        }
        catch (exception) { }
    }
}




function setNoFindFormControls(formMode, allowAdd, allowEdit, allowDelete) {
    //this block is there to convert string values to boolean
    allowAdd = allowAdd != "False";
    allowEdit = allowEdit != "False";
    allowDelete = allowDelete != "False";
    //end of special block

    if (formMode == "Edit" || formMode == "Add") {
        $("#divMain input,select,textarea,label,button, a").prop("disabled", false);
        $("#divMain input[type=text],select:enabled")[0].disabled = true;
        $("#divMain select[accesskey='permanentReadOnly']").prop("disabled", true);

        $("#FooterButtons a").prop("disabled", true);
    }
    else {
        $("#divMain input,select,textarea,label,button,a[accesskey!='tabPanel']").prop("disabled", true);
        $("#FooterButtons a").prop("disabled", false);

        if (formMode == "Recall") {
            $('#divMain input[type="text"],select:disabled')[0].disabled = false;
        }
    }

    if (document.getElementById("btnAdd") != null)
        document.getElementById("btnAdd").disabled = !allowAdd || formMode != "Initialize";
    if (document.getElementById("btnEdit") != null)
        document.getElementById("btnEdit").disabled = !allowEdit || formMode != "ReadOnly";
    if (document.getElementById("btnDelete") != null)
        document.getElementById("btnDelete").disabled = !allowDelete || formMode != "ReadOnly";

    if (document.getElementById("btnSave") != null)
        document.getElementById("btnSave").disabled = formMode != "Edit" && formMode != "Add";

   

    document.getElementById("btnUndo").disabled = formMode == "Initialize" || formMode == "Review";
    document.getElementById("btnRecall").disabled = formMode != "Initialize";
    document.getElementById("btnExit").disabled = formMode != "Initialize" && formMode != "Review";

    if (formMode == "Edit" || formMode == "Add" || formMode == "Recall") {
        try {
            $(':input(input[type="text"],select):not([class~="dateField"]):not([type="checkbox"]):enabled:visible:not([readonly]):first').focus();
        }
        catch (exception) { }
    }
}
