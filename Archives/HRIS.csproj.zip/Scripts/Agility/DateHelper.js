﻿$.datepicker.setDefaults({
    dateFormat: 'dd-M-y',
    currentText: 'Now',
    changeYear: true,
    changeMonth: true,
    gotoCurrent: true,
    showAnim: 'blind',
    autoSize: true,
    constrainInput: true,
    highlightWeek: true,
    maxDate: '+0D',
    showOn: "both",
    buttonImageOnly: true,
    buttonImage: "../../Content/Icon/calendar.gif",
    buttonText: "Calendar",


});
