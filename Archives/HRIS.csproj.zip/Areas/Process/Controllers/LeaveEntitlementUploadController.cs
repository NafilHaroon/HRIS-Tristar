﻿using Excel;
using HRIS.Areas.Common.Models;
using HRIS.Areas.Process.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    public class LeaveEntitlementUploadController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, AdvanceSalary _em)
        {           

            return View();
        }


        [HttpPost]
        public ActionResult Save()
        {
            var msg = new Object();
            List<LeaveEntitlement> _lstau = new List<LeaveEntitlement>();
            HttpPostedFileBase file = Request.Files["UploadedFile"];
            try
            {
                #region Validation
                if (file == null)
                    ModelState.AddModelError("Validation", "Please upload valid file containing data as per Attdendance  Upload template");
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    try
                    {
                        ProcessUploadAttendace(file, out _lstau);
                        msg = new { success = true, data = _lstau };
                    }
                    catch (Exception ex)
                    {
                        msg = new { success = false, data = _lstau, Message = ex.Message };
                        return Json(msg, JsonRequestBehavior.AllowGet);
                    }
                    return Json(msg, JsonRequestBehavior.AllowGet);
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        
       
        #endregion               
      


        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            msg = new { success = true };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        public FileResult DownloadLEUTemplate()
        {
            return new FilePathResult(@"~\Content\template\LeaveEntitlementUpload.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }

        #region private methods

        #region upload function
        private bool ProcessUploadAttendace(HttpPostedFileBase file, out List<LeaveEntitlement> lstau)
        {
            lstau = new List<LeaveEntitlement>();
            byte[] fileBytes = new byte[file.ContentLength];
            var data = file.InputStream.Read(fileBytes, 0, file.ContentLength);
            MemoryStream stream = new MemoryStream(fileBytes);
            IExcelDataReader xlReader = null;
            bool isXlsx = file.ContentType.Contains("openxmlformats");
            xlReader = isXlsx ? ExcelReaderFactory.CreateOpenXmlReader(stream) : ExcelReaderFactory.CreateBinaryReader(stream);
            xlReader.IsFirstRowAsColumnNames = true;
            DataSet dsXL = xlReader.AsDataSet();

            if (dsXL.Tables.Count == 0)
                throw new Exception("The selected file doesn't contain any worksheet");
            else if (dsXL.Tables.IndexOf("LeaveEntitlement") < 0)
                throw new Exception("The selected file doesn't contain any worksheet with the name 'LeaveEntitlement'");


            DataTable dtLeaveEntitlement = dsXL.Tables["LeaveEntitlement"];

            if (dtLeaveEntitlement.Columns.IndexOf("EmployeeCode") < 0)
                throw new Exception("Employee Code column was not found under 'LeaveEntitlement' worksheet");
            else if (dtLeaveEntitlement.Columns.IndexOf("LeaveId") < 0)
                throw new Exception("Leave Id column was not found under 'LeaveEntitlement' worksheet");
            else if (dtLeaveEntitlement.Columns.IndexOf("AllowedDays") < 0)
                throw new Exception("Allowed Days column was not found under 'LeaveEntitlement' worksheet");
            else if (dtLeaveEntitlement.Columns.IndexOf("DueDate") < 0)
                throw new Exception("Due Date column was not found under 'LeaveEntitlement' worksheet");




            foreach (DataRow dr in dtLeaveEntitlement.Rows)
            {
                try
                {
                    DateTime _date = new DateTime();
                    DateTime dtDueDate = Convert.ToDateTime(dr["DueDate"]);
                    if (dr["EmployeeCode"] == DBNull.Value)
                        lstau.Add(new LeaveEntitlement(dr["EmployeeCode"].ToString(),  Convert.ToDateTime(dtDueDate.ToString("dd-MMM-yy")) ,
                         0,0, "Employee Code Column can't be empty"));
                    else if (dr["DueDate"] == DBNull.Value)
                        lstau.Add(new LeaveEntitlement(dr["EmployeeCode"].ToString(),  Convert.ToDateTime(dtDueDate.ToString("dd-MMM-yy")) ,
                         0,0, "Attendance Date column can't be empty"));
                    else if (dr["LeaveId"] == DBNull.Value)
                        lstau.Add(new LeaveEntitlement(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dtDueDate.ToString("dd-MMM-yy")),
                         0, 0, "Leave Id column can't be empty"));
                    else if (dr["AllowedDays"] == DBNull.Value)
                        lstau.Add(new LeaveEntitlement(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dtDueDate.ToString("dd-MMM-yy")),
                         0, 0, "Allowed Days column can't be empty"));
                    else if (!DateTime.TryParse(dr["DueDate"].ToString(), out _date))
                        lstau.Add(new LeaveEntitlement(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dtDueDate.ToString("dd-MMM-yy")),
                         0, 0, "Due Date must be a valid Date"));

                    else
                    {
                        LeaveEntitlement _au = new LeaveEntitlement(
                        dr["EmployeeCode"].ToString(),
                        Convert.ToDateTime(dr["DueDate"]),
                        Convert.ToInt16(dr["LeaveId"]),
                        Convert.ToInt16(dr["AllowedDays"]), "");

                        LeaveEntitlement.Upload(_au, Session["UserId"].ToString());
                        lstau.Add(new LeaveEntitlement(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["DueDate"]),
                            Convert.ToInt16(dr["LeaveId"]), Convert.ToInt16(dr["AllowedDays"]), "Success"));
                    }
                }
                catch (Exception ex)
                {
                    lstau.Add(new LeaveEntitlement(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["DueDate"]),
                            Convert.ToInt16(dr["LeaveId"]), Convert.ToInt16(dr["AllowedDays"]), ex.Message));
                }

            }
            return true;
        }
        #endregion

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Upload Leave Entitlement from Excel'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        #endregion



    }
}
