﻿using Excel;
using HRIS.Areas.Common.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Areas.Process.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    public class MonthlyAllowanceUploadController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, AdvanceSalary _em)
        {           

            return View();
        }


        [HttpPost]
        public ActionResult Save()
        {
            var msg = new Object();
            List<MonthlyAllowance> _lstau = new List<MonthlyAllowance>();
            HttpPostedFileBase file = Request.Files["UploadedFile"];
            try
            {
                #region Validation
                if (file == null)
                    ModelState.AddModelError("Validation", "Please upload valid file containing data as per Attdendance  Upload template");
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    try
                    {
                        ProcessUploadAttendace(file, out _lstau);
                        msg = new { success = true, data = _lstau };
                    }
                    catch (Exception ex)
                    {
                        msg = new { success = false, data = _lstau, Message = ex.Message };
                        return Json(msg, JsonRequestBehavior.AllowGet);
                    }
                    return Json(msg, JsonRequestBehavior.AllowGet);
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        
       
        #endregion               
      


        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            msg = new { success = true };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        public FileResult DownloadMATemplate()
        {
            return new FilePathResult(@"~\Content\template\MonthlyAllowanceUpload.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }

        #region private methods

        #region upload function
        private bool ProcessUploadAttendace(HttpPostedFileBase file, out List<MonthlyAllowance> lstau)
        {
            lstau = new List<MonthlyAllowance>();
            byte[] fileBytes = new byte[file.ContentLength];
            var data = file.InputStream.Read(fileBytes, 0, file.ContentLength);
            MemoryStream stream = new MemoryStream(fileBytes);
            IExcelDataReader xlReader = null;
            bool isXlsx = file.ContentType.Contains("openxmlformats");
            xlReader = isXlsx ? ExcelReaderFactory.CreateOpenXmlReader(stream) : ExcelReaderFactory.CreateBinaryReader(stream);
            xlReader.IsFirstRowAsColumnNames = true;
            DataSet dsXL = xlReader.AsDataSet();

            if (dsXL.Tables.Count == 0)
                throw new Exception("The selected file doesn't contain any worksheet");
            else if (dsXL.Tables.IndexOf("MonthlyAllowance") < 0)
                throw new Exception("The selected file doesn't contain any worksheet with the name 'MonthlyAllowance'");


            DataTable dtMonthlyAllowance = dsXL.Tables["MonthlyAllowance"];

            if (dtMonthlyAllowance.Columns.IndexOf("EmployeeCode") < 0)
                throw new Exception("Employee Code column was not found under 'MonthlyAllowance' worksheet");
            else if (dtMonthlyAllowance.Columns.IndexOf("HeadId") < 0)
                throw new Exception("Head Id column was not found under 'MonthlyAllowance' worksheet");
            else if (dtMonthlyAllowance.Columns.IndexOf("Remarks") < 0)
                throw new Exception("Remarks column was not found under 'MonthlyAllowance' worksheet");
             else if (dtMonthlyAllowance.Columns.IndexOf("Amount") < 0)
                throw new Exception("Amount column was not found under 'MonthlyAllowance' worksheet");




            foreach (DataRow dr in dtMonthlyAllowance.Rows)
            {
                try
                {
                    if (dr["EmployeeCode"] == DBNull.Value)
                        lstau.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0,0, "", "Employee Code Column can't be empty"));
                    
                    else if (dr["HeadId"] == DBNull.Value)
                        lstau.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0,0,"", "Head Id column can't be empty"));

                    else if (dr["Remarks"] == DBNull.Value)
                        lstau.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0,0, "", "Allowed Days column can't be empty"));

                   else if (dr["Amount"] == DBNull.Value || Convert.ToDecimal(dr["Amount"]) == 0)
                        lstau.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0,0, "", " Amount column can't be empty"));

                    else
                    {
                        MonthlyAllowance _au = new MonthlyAllowance(
                        dr["EmployeeCode"].ToString(),
                        Convert.ToInt16(dr["HeadId"]),
                        Convert.ToDecimal(dr["Amount"]),
                        dr["Remarks"].ToString(), "");

                        MonthlyAllowance.Upload(_au, Session["UserId"].ToString());
                        lstau.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0,0,"", "Success"));
                    }
                }
                catch (Exception ex)
                {
                    lstau.Add(new MonthlyAllowance(dr["EmployeeCode"].ToString(), 0,0,"", ex.Message));
                }

            }
            return true;
        }
        #endregion

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Monthly Allowance Upload'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        #endregion



    }
}
