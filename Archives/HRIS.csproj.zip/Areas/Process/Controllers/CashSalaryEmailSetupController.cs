﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Process.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class CashSalaryEmailSetupController : Controller
    {

        public ActionResult CSEmail()
        {
            Session["WorkFlowTypeId"] = Request.QueryString["WorkFlowTypeId"];
            return RedirectToActionPermanent("DataForm");
        }

        public ActionResult PREmail()
        {
            Session["WorkFlowTypeId"] = Request.QueryString["WorkFlowTypeId"];
            return RedirectToActionPermanent("DataForm");
        }

        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, CashSalaryEmailSetup _em)
        {

            return View();
        }
                

        [HttpPost]
        public JsonResult Save(CashSalaryEmailSetup e)
        {
            var msg = new Object();
            string Success;
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Convert.ToInt16(Session["WorkFlowTypeId"]) == 1)
                    {
                        CashSalaryEmailSetup.SaveCSE(e);                    
                    }
                    else
                    {
                        CashSalaryEmailSetup.SaveCSE(e);                      
                    }
                         Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();

            ModelState.Clear();
            CashSalaryEmailSetup e = new CashSalaryEmailSetup();
            if (Convert.ToInt16(Session["WorkFlowTypeId"]) == 1)
            {
                e.Details = EmailSetupDetail.GetDTCashSalary(Session["UserId"].ToString());
            }
            else
            {
                e.Details = EmailSetupDetail.GetDTProbationReminder(Session["UserId"].ToString());
            }
           
            
            msg = new { success = true, data = e };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            CashSalaryEmailSetup e = new CashSalaryEmailSetup();
            if (Convert.ToInt16(Session["WorkFlowTypeId"]) == 1)
            {
                e.Details = EmailSetupDetail.GetDTCashSalary(Session["UserId"].ToString());
            }
            else
            {
                e.Details = EmailSetupDetail.GetDTProbationReminder(Session["UserId"].ToString());
            }
           
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

     
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        #region lookup methods
        private void populateLUSessions()
        {            
            Session["lstBranch"] = BranchList.Get(true, Session["UserId"].ToString());
            Session["lstCompany"] = CompanyList.getCompanies(true, Session["UserId"].ToString());
        }
        #endregion

        #region Json Method

        public JsonResult GetBranch()
        {
            return Json((List<BranchList>)Session["lstBranch"], JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCompany()
        {
            return Json((List<CompanyList>)Session["lstCompany"], JsonRequestBehavior.AllowGet);
        }
             
        #endregion


        #region private methods

        private void clearSessions()
        {
            Session.Remove("lstBranch");
            Session.Remove("lstCompany");

        }

        private string getOptionName(short id)
        {
            switch (Convert.ToInt16(id))
            {
                case 1:
                    return "Cash Salary Email Setup";
                case 2:
                    return "Probation Reminder Email Setup";                
                default:
                    return null;
            }
        }

        private ActionResult setAccessOption()
        {
            short wft = Convert.ToInt16(Session["WorkFlowTypeId"]);
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = '" + getOptionName(wft) + "'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();

            Session["FormMode"] = AgilityEnums.formMode.Initialize;            

            return View();
        }


        private void validate(CashSalaryEmailSetup e)
        {
            if (e.Details.Count == 0)
                    ModelState.AddModelError("Validation", "=> Atleast one Detail must exist to perform save operation");

            else if (e.Details.Where(y => string.IsNullOrWhiteSpace(y.BranchCode)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Branch"));

            else if (e.Details.Where(y => !y.CompanyId.HasValue).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company"));

            else if (e.Details.GroupBy(x => new { x.BranchCode, x.CompanyId }).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Branch used must be unique");


            else if (e.Details.Where(y => string.IsNullOrWhiteSpace(y.ContactName)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Contact Name"));

            else if (e.Details.Where(y => string.IsNullOrWhiteSpace(y.EmailTo)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("EmailTo"));

           
            
        }

        #endregion

    }
}
