﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Process.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;


namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class GenerateSalaryController : Controller
    {
        public ActionResult DataForm()
        {
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, Models.MonthlySalary _em)
        {
            return View();
        }
                

        [HttpPost]
        public JsonResult Save(Models.MonthlySalary e)
        {
            var msg = new Object();
            try
            {
                #region Validation
              
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Models.MonthlySalary.Generate(Session["UserId"].ToString(), e.GenerateOnlyNew))
                    {
                        string Success = "Salary for the month of" + Session["CurrentMonth"].ToString() + "-" + Convert.ToInt32(Session["CurrentYear"]) +
					    " generated successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
              

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }


        public JsonResult GetPeriod()
        {
            var msg = new Object();
            Models.MonthlySalary gs = new Models.MonthlySalary();
            gs.CurrentMonth = Session["CurrentMonth"].ToString();
            gs.CurrentYear = Convert.ToInt32(Session["CurrentYear"]);
            msg = new { data = gs };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
     

        #region private methods


        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Generate Current Month Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }
              
        #endregion

    }
}
