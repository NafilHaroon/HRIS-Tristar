﻿using Excel;
using HRIS.Areas.Common.Models;
using HRIS.Areas.Process.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    public class AttendanceUploadController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, AdvanceSalary _em)
        {           

            return View();
        }


        [HttpPost]
        public ActionResult Save()
        {
            var msg = new Object();
            List<AttendanceUpload> _lstau = new List<AttendanceUpload>();
            HttpPostedFileBase file = Request.Files["UploadedFile"];
            try
            {
                #region Validation
                if (file == null)
                    ModelState.AddModelError("Validation", "Please upload valid file containing data as per Attdendance  Upload template");
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    try
                    {
                        ProcessUploadAttendace(file, out _lstau);
                        msg = new { success = true, data = _lstau };
                    }
                    catch (Exception ex)
                    {
                        msg = new { success = false, data = _lstau, Message = ex.Message };
                        return Json(msg, JsonRequestBehavior.AllowGet);
                    }
                    return Json(msg, JsonRequestBehavior.AllowGet);
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public FileResult DownloadAUTemplate()
        {
            return new FilePathResult(@"~\Content\template\AttendanceUpload.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }
       
        #endregion
                
      


        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            msg = new { success = true };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }



        #region private methods

        #region upload function
        private bool ProcessUploadAttendace(HttpPostedFileBase file, out List<AttendanceUpload> lstau)
        {
            lstau = new List<AttendanceUpload>();
            byte[] fileBytes = new byte[file.ContentLength];
            var data = file.InputStream.Read(fileBytes, 0, file.ContentLength);
            MemoryStream stream = new MemoryStream(fileBytes);
            IExcelDataReader xlReader = null;
            bool isXlsx = file.ContentType.Contains("openxmlformats");
            xlReader = isXlsx ? ExcelReaderFactory.CreateOpenXmlReader(stream) : ExcelReaderFactory.CreateBinaryReader(stream);
            xlReader.IsFirstRowAsColumnNames = true;
            DataSet dsXL = xlReader.AsDataSet();

            if (dsXL.Tables.Count == 0)
                throw new Exception("The selected file doesn't contain any worksheet");
            else if (dsXL.Tables.IndexOf("Attendance") < 0)
                throw new Exception("The selected file doesn't contain any worksheet with the name 'Attendance'");


            DataTable dtAttendance = dsXL.Tables["Attendance"];

            if (dtAttendance.Columns.IndexOf("EmployeeCode") < 0)
                throw new Exception("Employee Code column was not found under 'Attendance' worksheet");
            else if (dtAttendance.Columns.IndexOf("AttendanceDate") < 0)
                throw new Exception("Attendance Date column was not found under 'Attendance' worksheet");
            else if (dtAttendance.Columns.IndexOf("AttendanceTime") < 0)
                throw new Exception("Attendance Time column was not found under 'Attendance' worksheet");




            foreach (DataRow dr in dtAttendance.Rows)
            {
                try
                {
                    DateTime _date = new DateTime();
                    if (dr["EmployeeCode"] == DBNull.Value)
                        lstau.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]),  "Employee Code Column can't be empty"));
                    else if (dr["AttendanceDate"] == DBNull.Value)
                        lstau.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Date column can't be empty"));
                    else if (dr["AttendanceTime"] == DBNull.Value)
                        lstau.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Time column can't be empty"));
                    else if (!DateTime.TryParse(dr["AttendanceDate"].ToString(), out _date))
                        lstau.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Date must be a valid Date"));
                    else if (!DateTime.TryParse(dr["AttendanceTime"].ToString(), out _date))
                        lstau.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Attendance Time must be a valid Time"));

                    else
                    {
                        AttendanceUpload _au = new AttendanceUpload(
                        dr["EmployeeCode"].ToString(),
                        Convert.ToDateTime(dr["AttendanceDate"]),
                        Convert.ToDateTime(dr["AttendanceTime"]), "");

                        AttendanceUpload.Upload(_au, Session["UserId"].ToString());
                        lstau.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), "Success"));
                    }
                }
                catch (Exception ex)
                {
                    lstau.Add(new AttendanceUpload(dr["EmployeeCode"].ToString(), Convert.ToDateTime(dr["AttendanceDate"]),
                            Convert.ToDateTime(dr["AttendanceTime"]), ex.Message));
                }

            }
            return true;
        }
        #endregion

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Upload Attendance Data from Excel'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        #endregion



    }
}
