﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Process.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Process.Controllers
{
    [NoCache]
    [Authorize]
    public class ChangeSupervisorController : Controller
    {
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, EmployeeSupervisor _em)
        {
            return View();
        }
                

        [HttpPost]
        public JsonResult Save(EmployeeSupervisor e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (EmployeeSupervisor.Update(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
              

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

     
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        #region lookup methods
        private void populateLUSessions()
        {            
            Session["lstBranch"] = BranchList.Get(true, Session["UserId"].ToString());
            Session["lstDepartment"] = DepartmentList.Get(true);
            Session["lstSupervisor"] = EmployeeList.Get(Session["UserId"].ToString());
        }
        #endregion

        #region Json Method
        public JsonResult GetDepartment()
        {
            return Json((List<DepartmentList>)Session["lstDepartment"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBranch()
        {
            return Json((List<BranchList>)Session["lstBranch"], JsonRequestBehavior.AllowGet);
        }


        public JsonResult GetSupervisors()
        {
            return Json((List<EmployeeList>)Session["lstSupervisor"], JsonRequestBehavior.AllowGet);
        }

             
        #endregion


        #region private methods

        private void clearSessions()
        {
            Session.Remove("lstDepartment");
            Session.Remove("lstBranch");
            Session.Remove("lstSupervisor");

        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Change Supervisor'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        private void validate(EmployeeSupervisor e)
        {
            if (string.IsNullOrEmpty(e.BranchCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Branch"));

            if (string.IsNullOrEmpty(e.DepartmentCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Department"));

            if (!e.SupervisorId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Current Supervisor"));

            if (!e.NewSupervisorId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("New Supervisor"));

            if (e.SupervisorId == e.NewSupervisorId)
                ModelState.AddModelError("Validation","New Supervisor cannot be same as Current Supervisor");

        }

        #endregion

    }
}
