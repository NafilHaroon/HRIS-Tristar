﻿


//document.getElementById("lblSalaryMonth").value = "Generate Salary for the month of  " + currentmonth + " - " + currentyear;

var app = angular.module('HRIS', []);

app.controller('GenerateSalaryController', function ($scope, $http, $window) {

    $scope.load = function () {

        $http({
            method: "POST",
            url: "/GenerateSalary/GetPeriod"
        }).success(function (result) {
            $scope.GenerateSalary = result.data;
            $scope.Value = "Generate Salary for the month of  " + $scope.GenerateSalary.CurrentMonth + " - " + $scope.GenerateSalary.CurrentYear;
        }).catch(function (result) {

        });

       
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/GenerateSalary/Save",
            data: $scope.GenerateSalary
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.GenerateSalary = result.data;      
            }
            else {
               // $scope.GenerateSalary = result.data;
                alert(result.Message);
                $scope.GenerateSalary = {};
            }
            // alert(result.Message);
        }).error(function (result) {
          
        });
    }    

   

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/GenerateSalary/Undo"
        }).success(function (result) {
            $scope.GenerateSalary = {};
            $scope.errors = [];
        }).catch(function (result) {

        });
    }


    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/AdvanceSalary/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }


      
        
});