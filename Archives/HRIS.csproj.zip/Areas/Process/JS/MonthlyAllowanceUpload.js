﻿
function validateFile() {
    var fu = document.getElementById("fuAttachment");

    if (fu.value == "") {
        alert("Please select valid Attendance file to be uploaded before hitting upload button");
        return false;
    }
    else {
        var validExts = new Array(".xlsx", ".xls");
        var fileExt = fu.value.substring(fu.value.lastIndexOf('.'));
        if (validExts.indexOf(fileExt) < 0 && fileExt != "") {
            alert("Invalid file selected, valid files are of " +
                validExts.toString() + " types.");
            $(fu).val("");
            return false;
        }
        else {
            showWaitDialog();
            return true;
        }
    }
};


var app = angular.module('HRIS', []);
app.controller('MonthlyAllowanceUploadController', ['$scope', '$http', function ($scope, $http, $window) {
    $scope.SelectedFileForUpload = null;


    $scope.SaveData = function () {

        var formData = new FormData();
        //File Upload
        var totalFiles = document.getElementById("fuAttachment").files.length;

        for (var i = 0; i < totalFiles; i++) {
            var file = document.getElementById("fuAttachment").files[i];
            formData.append("UploadedFile", file);
        }



        $http({
            url: '/MonthlyAllowanceUpload/Save',
            method: 'POST',
            headers: { "Content-Type": undefined },
            transformRequest: function (data) {
                return formData;//NOTICE THIS RETURN WHICH WAS MISSING
            },
            //
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.MonthlyAllowanceUpload = result.data;
                $('#fuAttachment').val("");

            }
            else {
                $scope.MonthlyAllowanceUpload = result.data;
                $('#fuAttachment').val("");
            }
            //ConvertDate();


        }).catch(function (result) {

        });
      
    }   


    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/MonthlyAllowanceUpload/Undo"
        }).success(function (result) {
            $scope.MonthlyAllowanceUpload = {};
            $('#fuAttachment').val("");
            $scope.errors = [];
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/MonthlyAllowanceUpload/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    //function ConvertDate() {      

    //    for (i = 0; i < $scope.MonthlyAllowanceUpload.length; i++) {
    //        $scope.MonthlyAllowenceUpload[i]["AttendanceDate"] = formattingdate($scope.MonthlyAllowenceUpload[i]["AttendanceDate"]);
    //        $scope.MonthlyAllowenceUpload[i]["AttendanceTime"] = formattingTime($scope.MonthlyAllowenceUpload[i]["AttendanceTime"]);

    //    }
        
    //}


    $scope.exportData = function () {      
            var blob = new Blob([document.getElementById('exportable').innerHTML], {
                type: "application/vnd.ms-excel"
            });
            saveAs(blob, "MonthlyAllowanceUpload.xls" );
       
    };
}])