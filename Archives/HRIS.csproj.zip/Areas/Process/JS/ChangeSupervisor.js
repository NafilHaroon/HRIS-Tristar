﻿
//function setBranchDropDown(formMode) {
//    if (formMode == "Recall") {
//        document.getElementById("ddbranch").disabled = false;
//        document.getElementById("ddDepartment").disabled = false;
//        document.getElementById("ddCSupervisor").disabled = false;
//        document.getElementById("ddNSupervisor").disabled = false;
//    }
//    else {
//        document.getElementById("ddbranch").disabled = true;
//        document.getElementById("ddDepartment").disabled = true;
//        document.getElementById("ddCSupervisor").disabled = true;
//        document.getElementById("ddNSupervisor").disabled = true;
//    }
//}


var app = angular.module('HRIS', []);

app.controller('ChangeSupervisorController', function ($scope, $http, $window) {

    loaddropdown();
    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/ChangeSupervisor/Save",
            data: $scope.ChangeSupervisor
        }).success(function (result) {
            
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.ChangeSupervisor = result.data;      
            }
            else {
               // $scope.ChangeSupervisor = result.data;
                alert(result.Message);
                $scope.ChangeSupervisor = {};
            }
        }).error(function (result) {
          
        });
    }    

   

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/ChangeSupervisor/Undo"
        }).success(function (result) {
            $scope.ChangeSupervisor = {};
            $scope.errors = [];
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/ChangeSupervisor/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

   

    //$scope.Recall = function () {
    //    $http({
    //        method: "POST",
    //        url: "/CashSalaryEmailSetup/Recall"
    //    }).success(function (result) {
    //        $scope.errors = [];
    //        setFormControls("Recall");
    //        setBranchDropDown("Recall");
    //    }).catch(function (result) {

    //    });
    //}





    function loaddropdown()
    {

        $http.get('/ChangeSupervisor/GetDepartment').then(function (d) {
            $scope.Departmentlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/ChangeSupervisor/GetBranch').then(function (d) {
            $scope.Branchlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/ChangeSupervisor/GetSupervisors').then(function (d) {
            $scope.GetEmployeelist = d.data;
        }, function () {
            alert('failed');
        });

    }   
        
});