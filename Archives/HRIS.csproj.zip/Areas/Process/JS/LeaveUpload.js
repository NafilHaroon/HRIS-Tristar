﻿$(function () {  

    $('#FirstDay').datepicker();
});



function validateFile() {
    var fu = document.getElementById("fuAttachment");
    var fdate = document.getElementById("FirstDay");
    
    if (fu.value == "") {
        alert("Please select valid Leave file to be uploaded before hitting upload button");
        return false;
    }

    else if (fdate.value == "") {
        alert("Please select valid First Day to be uploaded before hitting upload button");
        return false;
    }

    else {
        var validExts = new Array(".xlsx", ".xls");
        var fileExt = fu.value.substring(fu.value.lastIndexOf('.'));
        if (validExts.indexOf(fileExt) < 0 && fileExt != "") {
            alert("Invalid file selected, valid files are of " +
                validExts.toString() + " types.");
            $(fu).val("");
            return false;
        }
        else {
            showWaitDialog();
            return true;
        }
    }
};


var app = angular.module('HRIS', []);
app.controller('LeaveUploadController', ['$scope', '$http', function ($scope, $http, $window) {
    $scope.SelectedFileForUpload = null;


    // Save excel data to our database
    $scope.SaveData = function () {

        var formData = new FormData();
        //File Upload
        var totalFiles = document.getElementById("fuAttachment").files.length;

        for (var i = 0; i < totalFiles; i++) {
            var file = document.getElementById("fuAttachment").files[i];
            formData.append("UploadedFile", file);
        }

        formData.append("DFirstDay", $('#FirstDay').val());


        $http({
            url: "/LeaveUpload/Save",
            method: "POST",
            headers: { "Content-Type": undefined },
            transformRequest: function (data) {
                return formData;//NOTICE THIS RETURN WHICH WAS MISSING
            },
            //
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.LeaveUpload = result.data;
                $('#fuAttachment').val("");
            }
            else {
                $scope.LeaveUpload = result.data;
                $('#fuAttachment').val("");
            }
            ConvertDate();

        }).catch(function (result) {

        });

    }


    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/LeaveUpload/Undo"
        }).success(function (result) {
            $scope.LeaveUpload = {};
            $scope.errors = [];
            $('#fuAttachment').val("");
          
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/LeaveUpload/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    function ConvertDate() {
        for (i = 0; i < $scope.LeaveUpload.length; i++) {
            $scope.LeaveUpload[i]["LeaveDate"] = formattingdate($scope.LeaveUpload[i]["LeaveDate"]);

        }
    }

    $scope.exportData = function () {
        var blob = new Blob([document.getElementById('exportable').innerHTML], {
            type: "application/vnd.ms-excel"

        });
        saveAs(blob, "LeaveData.xls");
    };
}])