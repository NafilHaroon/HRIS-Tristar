﻿


var app = angular.module('HRIS', []);

app.controller('PostSalaryController', function ($scope, $http, $window) {

    $scope.load = function () {

        $http({
            method: "POST",
            url: "/PostSalary/GetPeriod"
        }).success(function (result) {
            $scope.GenerateSalary = result.data;
            $scope.Value = "Post Salary  for the month of  " + $scope.GenerateSalary.CurrentMonth + " - " + $scope.GenerateSalary.CurrentYear;
        }).catch(function (result) {

        });


    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/PostSalary/Save",
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]      
            }
            else {
                alert(result.Message);
            }
        }).error(function (result) {
          
        });
    }    

   

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/PostSalary/Undo"
        }).success(function (result) {
            $scope.errors = [];
        }).catch(function (result) {

        });
    }


    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/PostSalary/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }
});