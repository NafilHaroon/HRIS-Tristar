﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class EmployeeSupervisor : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short? ChangeSupervisorId { get; set; }  
        public short? SupervisorId { get; set; }
        public string BranchCode { get; set; }
        public string DepartmentCode { get; set; }
        public short? NewSupervisorId { get; set; }
        #endregion

        #region constructor
        public EmployeeSupervisor()
        {
            
            
        }
        #endregion

        #region internal methods

        internal static bool Update(EmployeeSupervisor _es, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("ChangeSupervisor"))
                {
                    db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _es.BranchCode);
                    db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, _es.DepartmentCode);
                    db.AddInParameter(dbCommand, "CurrentSupervisorId", SqlDbType.SmallInt, _es.SupervisorId);
                    db.AddInParameter(dbCommand, "NewSupervisorId", SqlDbType.SmallInt, _es.NewSupervisorId);
                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);

                    db.ExecuteNonQuery(dbCommand);

                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
    }
}