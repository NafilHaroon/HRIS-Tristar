﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class LeaveUpload: IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }

        [Display(Name = "Leave Date")]
        public DateTime? LeaveDate { get; set; }
        [Display(Name = "Leave Time")]
        public DateTime? LeaveTime { get; set; }
        [Display(Name = "Status")]
        public string Status { get; set; }
        [Display(Name = "FirstDay")]
        public DateTime? FirstDay { get; set; }
        [Display(Name = "UploadIndicator")]
        public string UploadIndicator { get; set; }
        
      
        #endregion

        #region Constructor

         public LeaveUpload()
        {

        }
        public LeaveUpload(string _EmployeeCode,
            DateTime _LeaveDate, DateTime _LeaveTime,  string _UploadIndicator, string _status)
        {
            EmployeeCode = _EmployeeCode;
            LeaveDate = _LeaveDate;
            LeaveTime = _LeaveTime;
            UploadIndicator=_UploadIndicator;
            Status = _status;
        }
        #endregion

        #region internal methods
        internal static bool Upload(LeaveUpload _leave, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("SaveLeaveUploadData"))
                {
                    db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _leave.EmployeeCode);
                    db.AddInParameter(dbCommand, "DateFrom", SqlDbType.DateTime, _leave.LeaveDate);
                    db.AddInParameter(dbCommand, "DateTo", SqlDbType.DateTime, _leave.LeaveTime);
                    db.AddInParameter(dbCommand, "UploadIndicator", SqlDbType.VarChar, _leave.UploadIndicator);
                    db.ExecuteNonQuery(dbCommand);
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}