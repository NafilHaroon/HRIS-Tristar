﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class MonthlyAllowance: IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }
        [Display(Name = "HeadId")]
        public short HeadId { get; set; }
        [Display(Name = "Amount")]
        public decimal Amount { get; set; }
        [Display(Name = "Remarks")]
        public string  Remarks { get; set; }       
        [Display(Name = "Status")]
        public string Status { get; set; }
      
        #endregion

        #region Constructor

         public MonthlyAllowance()
        {

        }
         public MonthlyAllowance(string _EmployeeCode, short _HeadId, decimal _Amount, string _Remarks, string _status)
        {
            EmployeeCode = _EmployeeCode;
            HeadId = _HeadId;
            Amount = _Amount;
            Remarks = _Remarks;
            Status = _status;
        }
        #endregion

        #region internal methods
        internal static bool Upload(MonthlyAllowance _ma, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("SaveMonthlyAllowanceUploadData"))
                {
                    db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _ma.EmployeeCode);
                    db.AddInParameter(dbCommand, "HeadId", SqlDbType.SmallInt, _ma.HeadId);
                    db.AddInParameter(dbCommand, "Amount", SqlDbType.Float, _ma.Amount);
                    db.AddInParameter(dbCommand, "Remarks", SqlDbType.VarChar, _ma.Remarks);
                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}