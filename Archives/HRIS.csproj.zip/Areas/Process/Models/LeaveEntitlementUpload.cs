﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Process.Models
{
    public class LeaveEntitlement: IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }
        [Display(Name = "Due Date")]
        public DateTime? DueDate { get; set; }
        [Display(Name = "Leave Id")]
        public short? LeaveId { get; set; }
        [Display(Name = "Allowed Days")]
        public short? AllowedDays { get; set; }
       
        [Display(Name = "Status")]
        public string Status { get; set; }
      
        #endregion

        #region Constructor

         public LeaveEntitlement()
        {

        }
        public LeaveEntitlement(string _EmployeeCode,
            DateTime _DueDate,  short _LeaveId, short _AllowedDays, string _status)
        {
            EmployeeCode = _EmployeeCode;
            DueDate = _DueDate;
            LeaveId = _LeaveId;
            AllowedDays=_AllowedDays;
            Status = _status;
        }
        #endregion

        #region internal methods

        internal static bool Upload(LeaveEntitlement _le, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("SaveLeaveEntitlementUploadData"))
                {
                    db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _le.EmployeeCode);
                    db.AddInParameter(dbCommand, "DueDate", SqlDbType.DateTime, _le.DueDate);
                    db.AddInParameter(dbCommand, "LeaveId", SqlDbType.SmallInt, _le.LeaveId);
                    db.AddInParameter(dbCommand, "AllowedDays", SqlDbType.SmallInt, _le.AllowedDays);
                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}