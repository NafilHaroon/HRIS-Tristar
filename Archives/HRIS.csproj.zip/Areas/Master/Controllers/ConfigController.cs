﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class ConfigController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
           
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, Config b, FormCollection formCollection)
        {               
            return View();
        }


        [HttpPost]
        public JsonResult LoadData()
        {
            var msg = new Object();
            Config cn = Config.Get();
            msg = new { success = true, data = cn};
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        
        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(Config b, List<Config> e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(b);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Config.Save(b, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = e, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(), Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
    

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }
              
     

        #endregion

        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstLoan"] = SalaryHeadList.Get(true,3);
            Session["lstAdvance"] = SalaryHeadList.Get(true, 3);
            Session["lstAbsent"] = SalaryHeadList.Get(true, 4);
        }
        #endregion

        #region private methods

        public JsonResult GetLoan()
        {
            return Json((List<SalaryHeadList>)Session["lstLoan"], JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetAdvance()
        {
            return Json((List<SalaryHeadList>)Session["lstAdvance"], JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetAbsent()
        {
            return Json((List<SalaryHeadList>)Session["lstAbsent"], JsonRequestBehavior.AllowGet);
        }

       

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Config'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;

           
            return View();
        }

        private void validate(Config b)
        {
            if (!b.AbsentDeductionId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Absent Deduction"));

            if (!b.AdvanceDeductionId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Advance Deduction"));

            if (!b.LoanDeductionId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Loan Deduction"));

        }
        #endregion
    }
}
