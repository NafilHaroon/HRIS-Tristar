﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class AllocationTemplateController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, AllocationTemplate _em, FormCollection formCollection)
        {
            return View();
        }

       

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            AllocationTemplate e = new AllocationTemplate();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(AllocationTemplate e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (AllocationTemplate.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {
                AllocationTemplate cn = AllocationTemplate.Get(_keyId);

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

      
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstDivision"] = DivisionList.Get();           
            //populateViewBags();
        }

        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(AllocationTemplateList.GetDT(false), "../Master/AllocationTemplate");
            Session["SearchKey"] = "TemplateId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(short _keyId)
        {
            AllocationTemplate _as = new AllocationTemplate();
            _as.TemplateId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }

        #endregion

        #region Json Method

        public JsonResult GetDivision()
        {
            return Json((List<DivisionList>)Session["lstDivision"], JsonRequestBehavior.AllowGet);
        }

      
        #endregion

        #region private methods

        private void clearSessions()
        {
            Session.Remove("lstDivision");
        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Allocation Template'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }
        

        private void validate(AllocationTemplate at)
        {
            if (string.IsNullOrEmpty(at.TemplateName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Template Name"));

            if(at.Details.Count==0)
            {
                ModelState.AddModelError("Validation", "=> Atleast one Division must exist in Template to perform save operation");
            }

            else if (at.Details.Where(x => !x.DivisionId.HasValue).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Division"));

            else if (at.Details.GroupBy(x => x.DivisionId).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Division used in Template must be unique");

            else if (at.Details.Where(x => x.Percentage <= 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Percentage"));

            var SumP = at.Details.Sum(x => x.Percentage);
            if (SumP != 100)
                ModelState.AddModelError("Validation", "=> The Division Percentage total must be 100% to save the record. Please complete the division allocation before saving");
          
        }

        #endregion

    }
}
