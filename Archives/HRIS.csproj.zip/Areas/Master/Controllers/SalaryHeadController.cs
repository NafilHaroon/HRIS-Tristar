﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class SalaryHeadController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, SalaryHead b, FormCollection formCollection)
        {               
            return View();
        }     

      
        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            SalaryHead _as = new SalaryHead();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = _as, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(SalaryHead e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (SalaryHead.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = e, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {
                SalaryHead cn = SalaryHead.Get(_keyId);

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

      
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(SalaryHeadList.GetDT(false, 0), "../Master/SalaryHead");
            Session["SearchKey"] = "HeadId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }


        public ActionResult GetId(short _keyId)
        {
            SalaryHead _as = new SalaryHead();
            _as.HeadId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }
        #endregion


        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstHeadType"] = HeadTypeList.Get();
            Session["lstEmployeeType"] = EmployeeTypeList.Get();
            //populateViewBags();
        }
        #endregion


        #region Json Method
        public JsonResult GetHeadType()
        {
            return Json((List<HeadTypeList>)Session["lstHeadType"], JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetEmployeeType()
        {
            return Json((List<EmployeeTypeList>)Session["lstEmployeeType"], JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region private methods

        private void clearSessions()
        {
            Session.Remove("lstHeadType");
            Session.Remove("lstEmployeeType");
        }
       
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Salary Head'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;           
            return View();
        }


        private void validate(SalaryHead sh)
        {
            if (string.IsNullOrEmpty(sh.HeadName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Head Name"));

            if (!sh.HeadTypeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("HeadTypeId"));

            //if (string.IsNullOrEmpty(sh.S21PositiveAccount))
            //    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("S21 Positive Account"));

            //if (string.IsNullOrEmpty(sh.S21NegativeAccount))
            //    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("S21 Negative Account"));

            if (sh.DefaultAmount <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Default Amount"));

            if (sh.Details.Count==0)
            {
                ModelState.AddModelError("Validation", "=> Atleast one Employee Type must exist in Salary Head to perform save operation");
            }

            if (sh.Details.Where(x => !x.EmployeeTypeId.HasValue).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Employee Type"));

            if (sh.Details.GroupBy(x => x.EmployeeTypeId).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Employee Type must be specified only once in specific Salary Head ");

            if (sh.Details.Where(x => string.IsNullOrWhiteSpace(x.S21NegativeAccount)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("S21NegativeAccount"));

             if (sh.Details.Where(x => string.IsNullOrWhiteSpace(x.S21PositiveAccount)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("S21PositiveAccount"));


        }
        #endregion
    }
}
