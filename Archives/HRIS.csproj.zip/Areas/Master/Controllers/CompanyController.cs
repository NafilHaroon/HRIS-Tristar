﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.ProvidentFund.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class CompanyController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
           
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, Company b, FormCollection formCollection)
        {               
            return View();
        }     

        
        
        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            Company _as = new Company();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = _as, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(Company e)
        {
            var msg = new Object();
            try
            {
                if (e.CompanyLogo != null)
                {
                    string imageBase64Data = Convert.ToBase64String(e.CompanyLogo);
                    e.image = imageBase64Data;
                }
                #region Validation
                 validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Company.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = e, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(), Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {
                Company cn = Company.Get(_keyId);
                if (cn.CompanyLogo != null)
                {
                    string imageBase64Data = Convert.ToBase64String(cn.CompanyLogo);
                    cn.image = imageBase64Data;
                    cn.CompanyLogo = null;
                }
                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

      
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(CompanyList.GetDT(false, Session["UserId"].ToString()), "../Master/Company");
            Session["SearchKey"] = "CompanyId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(short _keyId)
        {
            Company _as = new Company();
            _as.CompanyId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }


        #endregion

        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstPFReceivable"] = CoAList.getPFReceivableAccountList(Session["UserId"].ToString());
            
        }
        #endregion



         #region json method

        public JsonResult GetPFReceivableList()
        {
            return Json((List<CoAList>)Session["lstPFReceivable"], JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region private methods


        private void clearSessions()
        {
            Session.Remove("lstPFReceivable");

        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Company'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            populateLUSessions();
           
            return View();
        }

        private void validate(Company c)
        {
            if (string.IsNullOrEmpty(c.CompanyName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Name"));

            if (string.IsNullOrEmpty(c.CompanyAddress))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Address"));

            if (string.IsNullOrEmpty(c.NTN))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("NTN"));


            if (string.IsNullOrEmpty(c.EOBIRegistrationNumber))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("EOBI Registration #"));           


        }
        #endregion
    }
}
