﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class BankController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, Bank b, FormCollection formCollection)
        {               
            return View();
        }     

                
        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            Bank _as = new Bank();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = _as, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(Bank b )
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(b);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Bank.Save(b, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = b, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = b, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(), Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = b, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {
                Bank cn = Bank.Get(_keyId);

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

      
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        
        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(BankList.GetDT(false), "../Master/Bank");
            Session["SearchKey"] = "BankId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }


        public ActionResult GetId(short _keyId)
        {
            Bank _as = new Bank();
            _as.BankId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }

        #endregion


        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstCompany"] = CompanyList.getCompanies(true, Session["UserId"].ToString());
         
        }
        #endregion

        #region Json Method
        public JsonResult GetCompany()
        {
            return Json((List<CompanyList>)Session["lstCompany"], JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region private methods        


        private void clearSessions()
        {
            Session.Remove("lstCompany");
        }
       

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Bank'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;

           
            return View();
        }

        private void validate(Bank b)
        {
            if (string.IsNullOrEmpty(b.BankName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Bank Name"));

            if (!b.CompanyId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company Code"));

            if (string.IsNullOrEmpty(b.AccountNumber))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Account #"));

            if (string.IsNullOrEmpty(b.Address))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Address"));

            if (string.IsNullOrEmpty(b.ContactPerson))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("ContactPerson"));

        }
        #endregion
    }
}
