﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class UserProfileController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, Grade _grd, FormCollection formCollection)
        {
            return View();
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(UserProfile up)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validateUserProfile(up);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {

                    if (UserProfile.Save(up, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = up, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = up, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(), 
                        Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = up, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(string _keyId)
        {
            var msg = new Object();
            try
            {

                UserProfile _user = UserProfile.Get(_keyId);

                if (_user == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The Users Id entered doesn't exist or you donot have permission to access it");
                }
                else
                {
                    if (Convert.ToInt16(_user.UserLevel) >= Convert.ToInt16(Session["UserLevel"]) && Convert.ToInt16(Session["UserLevel"]) != 3)
                    {
                        ModelState.AddModelError("Validation", "Sorry " + Session["UserId"].ToString() + "! You are not authorized to modify " +
                            "this user profile. You can only modify profile for user below your user level");                        
                    }
                }

                if (!ModelState.IsValid)
                {    
                    Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                    msg = new
                    {
                        success = false,
                        data = _user,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }

                if (ModelState.IsValid)
                {
                     Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                    _user.UserLevel = "Level" + _user.UserLevel + "User";
                    msg = new { success = true, data = _user, Session = Session["FormMode"].ToString() };
                }
            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(UserList.GetDTUsers(true), "../Master/UserProfile");
            Session["SearchKey"] = "UserId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(string  _keyId)
        {
            UserProfile _as = new UserProfile();
            _as.UserId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }
        #endregion

        #region private methods


        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'User Management'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;


            return View();
        }


        private void validateUserProfile(UserProfile _up)
        {
            if (_up.Options.Where(x => !x.AllowAccess && (x.AllowAdd || x.AllowEdit)).Any())
                ModelState.AddModelError("Validation", "=> Please put check on Allow access when you request Allow Add or Allow Edit else remove check from Allow Add / Edit where Allow access is not turned on");
        }
        #endregion
    }
}
