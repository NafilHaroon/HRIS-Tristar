﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class EmployeeController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, Employee _em, FormCollection formCollection)
        {
            return View();
        }                

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            Employee e = new Employee();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Save(Employee emp)
        {
            var msg = new Object();
            try
            {
                if (emp.ProfileImage != null)
                {
                    string imageBase64Data = Convert.ToBase64String(emp.ProfileImage);
                    emp.image = imageBase64Data;
                }

                #region Validation

                if (Session["DocAttachment"] != null)
                    emp.EmpAttachmentDetails = (List<EmpAttachment>)Session["DocAttachment"];
                else
                    emp.EmpAttachmentDetails = new List<EmpAttachment>();

                validate(emp);

                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                   

                    if (Employee.Save(emp, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = emp, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = emp,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = emp, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }      

        public JsonResult Get(string  _keyId)
        {
            var msg = new Object();
            try
            {

                Employee cn = Employee.Get(_keyId);
                if (cn.ProfileImage != null)
                {
                    string imageBase64Data = Convert.ToBase64String(cn.ProfileImage);
                    cn.image = imageBase64Data;
                    cn.ProfileImage = null;
                }

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }                

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

                Session["DocAttachment"] = cn.EmpAttachmentDetails;

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Delete(string _keyId)
        {
            try
            {
                if (Convert.ToBoolean(Session["AllowDelete"]))
                {
                    if (Employee.Delete(_keyId))
                    {
                        TempData["alertMessage"] = "Employee Id " + _keyId + " deleted successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    }
                }
                return Json(new { success = true, errorMsg = string.Empty }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(EmployeeList.GetDT(Session["UserId"].ToString()), "../Master/Employee");
            Session["SearchKey"] = "EmployeeCode";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(string _keyId)
        {
            Employee _as = new Employee();
            _as.EmployeeCode = _keyId;
            _as.BSSession = Convert.ToInt16(Session["BasicSalaryId"]);
            _as.PFSession = Convert.ToInt16(Session["ProvidentFundId"]);
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }

        #endregion

        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstCompany"] = CompanyList.getCompanies(true, Session["UserId"].ToString());
            Session["lstBranch"] = BranchList.Get(true, Session["UserId"].ToString());
            Session["lstDepartment"] = DepartmentList.Get(true);
            Session["lstSupervisor"] = EmployeeList.Get(Session["UserId"].ToString());
            Session["lstReplaceEmployee"] = EmployeeList.GetInActive();
            Session["lstEmployeeStatus"] = EmpStatus.Get();
            Session["lstJobNature"] = JobNature.Get();
            Session["lstMaritalStatus"] = MaritalStatus.Get();
            Session["lstGrade"] = GradeList.Get(true, Session["UserId"].ToString());
            Session["lstQualification"] = QualificationList.Get();
            Session["lstPaymentMode"] = PaymentModeList.Get();
            Session["lstBank"] = BankList.Get(true);
            Session["lstLeave"] = LeaveList.Get(true);
            Session["lstAsset"] = AssetList.Get();
            Session["lstRelation"] = RelationList.Get();
            Session["lstMedicalPlan"] = MedicalPlanList.Get();
            Session["lstSalaryHead"] = SalaryHeadList.Get(true, 0);
            Session["lstAttachment"] = AttachmentTypeList.Get(true);
            Session["lstATemplate"] = AllocationTemplateList.Get(true);
            Session["lstEmployeeType"] = EmployeeTypeList.Get();
            //populateViewBags();
        }
        #endregion

        #region Json Method
        public JsonResult GetCompany()
        {
            return Json((List<CompanyList>)Session["lstCompany"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBranch()
        {
            return Json((List<BranchList>)Session["lstBranch"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetDepartment()
        {
            return Json((List<DepartmentList>)Session["lstDepartment"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEmployees()
        {
            return Json((List<EmployeeList>)Session["lstSupervisor"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetInActiveEmployee()
        {
            return Json((List<EmployeeList>)Session["lstReplaceEmployee"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEmployeeStatus()
        {
            return Json((List<EmpStatus>)Session["lstEmployeeStatus"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetJobNature()
        {
            return Json((List<JobNature>)Session["lstJobNature"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMaritalStatus()
        {
            return Json((List<MaritalStatus>)Session["lstMaritalStatus"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetGrade()
        {
            return Json((List<GradeList>)Session["lstGrade"], JsonRequestBehavior.AllowGet);
        }


        public JsonResult GetQualification()
        {
            return Json((List<QualificationList>)Session["lstQualification"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPaymentMode()
        {
            return Json((List<PaymentModeList>)Session["lstPaymentMode"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBank()
        {
            return Json((List<BankList>)Session["lstBank"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetLeave()
        {
            return Json((List<LeaveList>)Session["lstLeave"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAsset()
        {
            return Json((List<AssetList>)Session["lstAsset"], JsonRequestBehavior.AllowGet);
        }


        public JsonResult GetRelation()
        {
            return Json((List<RelationList>)Session["lstRelation"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMedicalPlan()
        {
            return Json((List<MedicalPlanList>)Session["lstMedicalPlan"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetSalaryHead()
        {
            return Json((List<SalaryHeadList>)Session["lstSalaryHead"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAttachmentType()
        {
            return Json((List<AttachmentTypeList>)Session["lstAttachment"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAllocationTemplate()
        {
            return Json((List<AllocationTemplateList>)Session["lstATemplate"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEmployeeType()
        {
            return Json((List<EmployeeTypeList>)Session["lstEmployeeType"], JsonRequestBehavior.AllowGet);
        }
        #endregion


        //public JsonResult GetCompany()
        //{            
        //    return Json(getCompanyList(), JsonRequestBehavior.AllowGet);
        //}

        #region private methods

        private void clearSessions()
        {
            Session.Remove("lstCompany");
            Session.Remove("lstDepartment");
            Session.Remove("lstBranch");
            Session.Remove("lstSupervisor");
            Session.Remove("lstReplaceEmployee");
            Session.Remove("lstEmployeeStatus");
            Session.Remove("lstJobNature");
            Session.Remove("lstMaritalStatus");
            Session.Remove("lstGrade");
            Session.Remove("lstQualification");
            Session.Remove("lstPaymentMode");
            Session.Remove("lstBank");
            Session.Remove("lstLeave");
            Session.Remove("lstRelation");
            Session.Remove("lstMedicalPlan");
            Session.Remove("lstSalaryHead");
            Session.Remove("lstAttachment");
            Session.Remove("lstATemplate");
            Session.Remove("DocAttachment");
            Session.Remove("lstEmployeeType");

        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Employee'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            Employee e = new Employee();
            e.BSSession = Convert.ToInt16(Session["BasicSalaryId"]);
            e.PFSession = Convert.ToInt16(Session["ProvidentFundId"]);
            return View();
        }   

        private void validate(Employee e)
        {
            if (string.IsNullOrEmpty(e.EmployeeName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Employee Name"));

            if (string.IsNullOrEmpty(e.BranchCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Branch"));

            if (string.IsNullOrEmpty(e.DepartmentCode))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Department"));

            if (string.IsNullOrEmpty(e.GradeId))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Grade"));

            if (string.IsNullOrEmpty(e.Designation))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Designation"));

            if (e.image == null)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("ProfileImage"));


            if (string.IsNullOrEmpty(e.HeadName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Father/Husband Name"));

            if (!e.SupervisorId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Supervisor"));

            if (!e.EmployeeTypeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Employee Type"));

            if (!e.StatusCode.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Status"));

            if (!e.JobNatureId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Job Nature"));


            if (e.HiringType == 2 && !e.ReplacementEmployeeId.HasValue)
                ModelState.AddModelError("Validation", "Please select valid employee name from drop down against which this replacement is hired");

            if (e.HiringType == 3 && !e.ReplacementEmployeeId.HasValue)
                ModelState.AddModelError("Validation", "Please select valid employee name from drop down against which this replacement is hired");

            if (e.JoiningDate.Value > e.ConfirmationDueDate.Value)
            {
                ModelState.AddModelError("Validation", "The Confirmation Due Date can't be older than Joining Date");
            }

            if (e.IsConfirmed)
            {
                if (e.JoiningDate.Value > e.ConfirmationDate.Value)
                {
                    ModelState.AddModelError("Validation", "The confirmation data can't be older than joining date");

                }
                //else if (e.EmpEmergencyContactDetails.Count == 0)
                //{
                //    ModelState.AddModelError("Validation", "Next of Kin Name and Relation ship is mandatory to be saved for confirmed Employee. Please provide valid data before proceeding");
                //    return;
                //}
            }

            if (e.LifeInsurance <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Life Insurance"));


            if (!e.EmpDetails.MaritalStatusId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Marital Status"));

            if (!e.EmpDetails.GenderId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Gender"));

            if (string.IsNullOrEmpty(e.EmpDetails.FamilyNumber))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Family #"));


            if (string.IsNullOrEmpty(e.EmpDetails.PermanentAddress))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Permanent Address"));

            if (string.IsNullOrEmpty(e.EmpDetails.ResidentialAddress))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Residential Address"));

            if (!string.IsNullOrWhiteSpace(e.EmpDetails.Email))
            {
                string emailFormat = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
                if (!Regex.IsMatch(e.EmpDetails.Email, emailFormat))
                    ModelState.AddModelError("Validation", AgilityHelper.EmailFormat("Email Address"));
            }

            if (string.IsNullOrWhiteSpace(e.EmpDetails.CellNumber))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Mobile #"));
            else if (!Regex.IsMatch(e.EmpDetails.CellNumber, @"^\(?([0-9]{4})\)?[-]?([0-9]{7})$"))
                ModelState.AddModelError("Validation", AgilityHelper.CallFormat("Mobile #"));

            if (!e.EmpDetails.WorkingSinceDate.HasValue)
            {
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Working Since Date"));
            }

            if (!string.IsNullOrWhiteSpace(e.EmpDetails.PhoneNumber))
            {
                if (!Regex.IsMatch(e.EmpDetails.PhoneNumber, @"^\(?([0-9]{3,4})\)?[-]?([0-9]{6,7})$"))
                    ModelState.AddModelError("Validation", AgilityHelper.CallFormat("Phone #"));
            }

            if (string.IsNullOrWhiteSpace(e.EmpDetails.CNICNumber))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("CNIC #"));
            else if (!string.IsNullOrWhiteSpace(e.EmpDetails.CNICNumber) && !Regex.IsMatch(e.EmpDetails.CNICNumber, @"^\(?([0-9]{5})\)?[-]?([0-9]{7})?[-]?([0-9]{1})$"))
                ModelState.AddModelError("Validation", "=> Please enter CNIC # in valid format like xxxxx-xxxxxxx-x");


            if (e.EmpLeaveDetails.Count > 0)
            {
                if (e.EmpLeaveDetails.Where(x => !x.DueDate.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("DueDate"));

                if (e.EmpLeaveDetails.Where(x => x.AllowedDays <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Allowed Days"));

                if (e.EmpLeaveDetails.GroupBy(x => x.LeaveId).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Leave used in Employee Leave must be unique");

            }

            if (e.EmpAssetDetails.Count > 0)
            {
                if (e.EmpAssetDetails.Where(x => !x.AssetId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Asset"));

                if (e.EmpAssetDetails.Where(x => string.IsNullOrEmpty(x.RegistrationNumber)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Registration #"));

                if (e.EmpAssetDetails.Where(x => string.IsNullOrEmpty(x.Model)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Model"));

                if (e.EmpAssetDetails.Where(x => x.BaseValue <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("BaseValue"));

                if (e.EmpAssetDetails.Where(x => x.Limit <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Limit"));

                if (e.EmpAssetDetails.GroupBy(x => new { x.AssetId,x.RegistrationNumber }).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Asset and Reg # used in Employee Asset must be unique");

            }

            if (e.EmpAttachmentDetails.Count > 0)
            {
                if (e.EmpAttachmentDetails.Where(x => !x.AttachmentTypeId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Attachment Type"));

                //if (e.EmpAttachmentDetails.GroupBy(x => x.AttachmentTypeId ).Any(grp => grp.Count() > 1))
                //    ModelState.AddModelError("Validation", "=> Doc Attachment used in Employee Doc must be unique");

               
                if (e.EmpAttachmentDetails.Where(x => x.ExpiryDate.HasValue).Where(z => z.ExpiryDate.Value.Date < DateTime.Now.Date).Count() > 0)
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtCurrent("Expiry Date"));

                ValidateAttachments(e.EmpAttachmentDetails, (List<AttachmentTypeList>)Session["lstAttachment"]);
            }

            if (e.EmpCostAllocatioDetails.Count > 0)
            {
                if (e.EmpCostAllocatioDetails.Where(x => string.IsNullOrEmpty(x.BranchCode)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Branch"));

                if (e.EmpCostAllocatioDetails.Where(x => !x.TemplateId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Template"));

                 if (e.EmpCostAllocatioDetails.Where(x => x.Percentage <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Percentage"));

                  var SumP = e.EmpCostAllocatioDetails.Sum(x => x.Percentage);
                 if (SumP > 100)
                ModelState.AddModelError("Validation", "=> The  Percentage  must not exceed 100% to save the record. ");

                if (e.EmpCostAllocatioDetails.GroupBy(x => new { x.BranchCode, x.TemplateId }).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Branch & Template used in Employee Cost Allocation must be unique");
            }

            if (e.EmpEmergencyContactDetails.Count > 0)
            {
                if (e.EmpEmergencyContactDetails.Where(x => string.IsNullOrEmpty(x.NoKContactNo)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("NoKContactNo"));

                if (e.EmpEmergencyContactDetails.Where(x => string.IsNullOrEmpty(x.NoKName)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("NoKName"));

                if (e.EmpEmergencyContactDetails.Where(x => !x.RelationId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Relation"));


                if (e.EmpEmergencyContactDetails.Where(x => !string.IsNullOrEmpty(x.NoKContactNo)).Any())
                {
                    if (e.EmpEmergencyContactDetails.Where(x => !Regex.IsMatch(x.NoKContactNo, @"^\(?([0-9]{3,4})\)?[-]?([0-9]{6,7})$")).Any())
                        ModelState.AddModelError("Validation", AgilityHelper.CallFormat("Phone #"));
                }

                if (e.EmpEmergencyContactDetails.GroupBy(x => new { x.RelationId, x.NoKContactNo }).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Relation and Contact # used in Employee Emergency Conatct must be unique");
            }

            if (e.EmpFamilyMemberDetails.Count > 0)
            {
                if (e.EmpFamilyMemberDetails.Where(x => string.IsNullOrEmpty(x.PersonName)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("PersonName"));
                
                 if (e.EmpFamilyMemberDetails.Where(x => !x.MedicalPlanId.HasValue).Any())
                     ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("MedicalPlan"));

                if (e.EmpFamilyMemberDetails.Where(x => !x.RelationId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Relation"));

                if (e.EmpFamilyMemberDetails.Where(x => x.MedicalCost <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Medical Cost"));

                if (e.EmpFamilyMemberDetails.Where(x => !x.DOB.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("DOB"));

                //if (e.EmpFamilyMemberDetails.GroupBy(x => new { x.RelationId, x.MedicalPlanId }).Any(grp => grp.Count() > 1))
                //    ModelState.AddModelError("Validation", "=> Relation  & Medical Plan used in Employee Fmaily Member must be unique");
            }

            if (e.EmpSalaryMonthlyDetails.Count == 0)
                ModelState.AddModelError("Validation", "=> At Least One Row should be added in Monthly Salary Grid before saving");

            if (e.EmpSalaryMonthlyDetails.Count > 0)
            {
                if (e.EmpSalaryMonthlyDetails.Where(x => !x.HeadId.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Salary Head"));

                if (e.EmpSalaryMonthlyDetails.Where(x => x.Amount <= 0).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Amount"));


                if (e.EmpSalaryMonthlyDetails.GroupBy(x => x.HeadId).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> Salary Head used in Employee Monthly Salary must be unique");



                if (e.EmpSalaryMonthlyDetails.Where(x => x.TotalSalary <= 0).Any())
                    ModelState.AddModelError("Validation", "=> Sum of Total Salary cannot be Zero or less then zero ");


                

            }
        }

        internal static bool ValidateAttachments(List<EmpAttachment> _attachments,
           List<AttachmentTypeList> _wfat, bool _includeNewLine = true)
        {
            try
            {
                if (_wfat != null && _wfat.Count() > 0)
                {
                    IEnumerable<object> _result = (IEnumerable<object>)
                        (from dox in _wfat
                         join supporting in _attachments.Where(a => !a.IsDeleted) on
                         dox.AttachmentTypeId equals supporting.AttachmentTypeId
                         into ps
                         from supporting in ps.DefaultIfEmpty()
                         select new
                         {
                             AttachmentTypeName = dox.AttachmentTypeName,
                             Mandatory = dox.Mandatory,
                             FileName = supporting == null ? "(No File)" : supporting.AttachmentName
                         }).Where(a => a.Mandatory && a.FileName == "(No File)");

                    if (_result.Count() > 0)
                    {
                        string missingDox = "";
                        foreach (dynamic item in _result)
                        {
                            missingDox += "'" + item.AttachmentTypeName + "', ";
                        }
                        throw new Exception("Mandatory attachment(s) are missing, Please enclose following missing attachment(s) and try again" +
                            (_includeNewLine ? Environment.NewLine : " ") + missingDox);
                    }

                }
                return true;
            }
            catch (Exception)
            { throw; }
        }

        [HttpPost]
        public ActionResult SaveAttachment()
        {
            var msg = new Object();

            EmpAttachment ead = new EmpAttachment();
            List<EmpAttachment> lstDetail = new List<EmpAttachment>();
            lstDetail = (List<EmpAttachment>)Session["DocAttachment"];
            if (Request.Form["DExpiryDate"] != "")
            ead.ExpiryDate = Convert.ToDateTime(Request.Form["DExpiryDate"]);
            ead.AttachmentTypeId = Convert.ToInt16(Request.Form["AttachmentTypeId"]);
            ead.IsNew = true;
            ead.IsDeleted = false;

            HttpPostedFileBase file = Request.Files["UploadedFile"];

            if (file.ContentLength / 1000 > 1024)
            {
                throw new Exception("Upload File size exceed the maximum file size allowed for which is 1024 KB ");
            }

            if ((file != null) && (file.ContentLength > 0) && !string.IsNullOrEmpty(file.FileName))
            {
                ead.AttachmentContentType = file.ContentType;
                ead.AttachmentContent = new byte[file.ContentLength];
                ead.AttachmentName = Path.GetFileName(file.FileName);
               
                file.InputStream.Read(ead.AttachmentContent, 0, file.ContentLength);
            }

            else
                throw new Exception("File is mandatory for Employee ");

            lstDetail.Add(ead);           
            Session["DocAttachment"] = lstDetail;


            msg = new { success = true, data = lstDetail.Where(a => !a.IsDeleted).ToList() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

         [HttpPost]
        public ActionResult DeleteAttachment(int _keyId)
        {
            var msg = new Object();
            List<EmpAttachment> lstDetail = new List<EmpAttachment>();
            try
            {               
               
                lstDetail = (List<EmpAttachment>)Session["DocAttachment"];
                EmpAttachment _att = lstDetail.Where(m => m.AttachmentTypeId == _keyId).FirstOrDefault();
                //if (lstDetail != null)
                //{
                //    lstDetail.Remove(_att);
                //    Session["DocAttachment"] = lstDetail;
                //}

                if (_att != null)
                {
                    if (_att.IsNew)
                        lstDetail.Remove(_att);
                    else
                    {
                        _att.IsDeleted = true;
                        _att.AttachmentContent = null;
                    }
                    Session["DocAttachment"] = lstDetail;
                }
                msg = new { success = true, data = lstDetail.Where(a => !a.IsDeleted).ToList() };
              
            }
            catch (Exception ex)
            {
                msg = new { success = false, data = lstDetail.Where(a => !a.IsDeleted).ToList(), Message = ex.Message };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        //public ActionResult ViewAttachment(int id)
        //{
        //    EmpAttachmentDetail att = new EmpAttachmentDetail();

        //    List<EmpAttachmentDetail> lstDetail = new List<EmpAttachmentDetail>();
        //    lstDetail = (List<EmpAttachmentDetail>)Session["DocAttachment"];
        //    if (lstDetail != null)
        //    {
        //        EmpAttachmentDetail _att = lstDetail.Where(m => m.AttachmentTypeId == id && !m.IsDeleted).FirstOrDefault();
        //        if (_att != null)
        //        {
        //            MemoryStream ms = new MemoryStream();
        //            ms.Write(_att.AttachmentContent, 0, _att.AttachmentContent.Length);
        //            ms.Position = 0;
        //            Response.AddHeader("Content-Disposition", "attachment; filename=" + _att.AttachmentName);
        //            return new FileStreamResult(ms, _att.AttachmentContentType);
        //        }
        //        throw new Exception("Required file not found!");
        //    }
        //    else
        //        throw new Exception("No file exist in Attachment list for this request");
        //}

         
        public ActionResult ViewAttachment(int _KeyId)
        {
            List<EmpAttachment> lstDetail = new List<EmpAttachment>();
            lstDetail = (List<EmpAttachment>)Session["DocAttachment"];
            if (lstDetail != null)
            {
                EmpAttachment att = lstDetail.Where(m => m.AttachmentTypeId == _KeyId && !m.IsDeleted).FirstOrDefault();
                if (att != null)
                {
                    MemoryStream ms = new MemoryStream();
               
                    ms.Write(att.AttachmentContent, 0, att.AttachmentContent.Length);
                    ms.Position = 0;
                    Response.AddHeader("Content-Disposition", "attachment; filename=" + att.AttachmentName);
           
                    return new FileStreamResult(ms, att.AttachmentContentType);
                }
                throw new Exception("Required file not found!");
            }
            else
                throw new Exception("No file exist in Attachment list for this request");


        }


        #endregion
    }
}
