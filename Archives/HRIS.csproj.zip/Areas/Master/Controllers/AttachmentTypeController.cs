﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Master.Controllers
{
    [NoCache]
    [Authorize]
    public class AttachmentTypeController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
           
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, AttachmentType b, FormCollection formCollection)
        {               
            return View();
        }     

       
        
        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            AttachmentType _as = new AttachmentType();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = _as, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(AttachmentType dat)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(dat);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (AttachmentType.Save(dat, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = dat, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = dat, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(), Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = dat, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {
                AttachmentType cn = AttachmentType.Get(_keyId);

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

      
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(AttachmentTypeList.GetDT(false), "../Master/DocumentAttachmentType");
            Session["SearchKey"] = "AttachmentTypeId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(short _keyId)
        {
            AttachmentType _as = new AttachmentType();
            _as.AttachmentTypeId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }

        #endregion

      

        #region private methods           

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Document Attachment Type'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            Session["FormMode"] = AgilityEnums.formMode.Initialize;

           
            return View();
        }

        private void validate(AttachmentType dat)
        {
            if (string.IsNullOrEmpty(dat.AttachmentTypeName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Attachment Type Name"));
                        
        }
        #endregion
    }
}
