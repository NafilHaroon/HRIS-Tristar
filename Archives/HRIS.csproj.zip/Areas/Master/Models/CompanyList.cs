﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class CompanyList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Company Id")]
        public short CompanyId { get; set; }
        public string CompanyCode { get; set; }
        [DataMember(Order = 1)]
        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }
        [DataMember(Order = 2)]
        public bool IsActive { get; set; }

        #endregion

        #region constructor
        public CompanyList()
        {
        }

        public CompanyList(short _CompanyId, string _CompanyName, string _CompanyCode, bool _isActive = true)
        {
            CompanyId = _CompanyId;
            CompanyName = _CompanyName;
            CompanyCode = _CompanyCode;
            IsActive = _isActive;

        }
        #endregion

        #region internal methods
        internal static List<CompanyList> Get(bool _activeOnly, string _userid)
        {
            return Get(_activeOnly, _userid);
        }

        internal static DataTable GetDT(bool _activeOnly, string _userid)
        {
            return AgilityHelper.ListToDataTable(getCompanies(_activeOnly, _userid));
        }
        #endregion


        #region internal methods
        internal static List<CompanyList> getCompanies(bool _activeOnly, string _userId = null)
        {
            List<CompanyList> lstCompany = new List<CompanyList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getCompanyList"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _activeOnly);
                if (_userId != null)
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstCompany.Add(new CompanyList(
                              Convert.ToInt16(dr["CompanyId"]),
                                dr["CompanyName"].ToString(),
                                 dr["CompanyCode"].ToString(),
                                 Convert.ToBoolean(dr["IsActive"])));
                        }
                    }
                }
            }
            return lstCompany;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}