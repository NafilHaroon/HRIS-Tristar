﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class EmployeeTypeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short EmployeeTypeId { get; set; }
        public string EmployeeTypeName { get; set; }

        #endregion

        #region constructor
        public EmployeeTypeList()
        {
        }

        public EmployeeTypeList(short _EmployeeTypeId, string _EmployeeTypeName)
        {
            EmployeeTypeId = _EmployeeTypeId;
            EmployeeTypeName = _EmployeeTypeName;

        }
        #endregion

        #region internal methods
        internal static List<EmployeeTypeList> Get()
        {
            return getEmployeeTypes();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getEmployeeTypes());
        }
        #endregion

        #region private methods
        private static List<EmployeeTypeList> getEmployeeTypes()
        {
            List<EmployeeTypeList> lstEmployeeType = new List<EmployeeTypeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeTypeList"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstEmployeeType.Add(new EmployeeTypeList(
                             Convert.ToInt16(dr["EmployeeTypeId"]),
                                dr["EmployeeTypeName"].ToString()));
                        }
                    }
                }
            }
            return lstEmployeeType;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}