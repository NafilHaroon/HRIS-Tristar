﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class BankList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Bank Id")]
        public short BankId { get; set; }
        [DataMember(Order = 1)]
        [Display(Name = "Bank Name")]
        public string BankName { get; set; }
        [DataMember(Order = 3)]
        public bool IsActive { get; set; }

        #endregion

        #region constructor
        public BankList()
        {
        }

        public BankList(short _BankId, string _BankName, bool _isActive = true)
        {
            BankId = _BankId;
            BankName = _BankName;
            IsActive = _isActive;

        }
        #endregion

        #region internal methods
        internal static List<BankList> Get(bool _isActive = true)
        {
            return getBanks(_isActive);
        }

        internal static DataTable GetDT(bool _isActive = true)
        {
            return AgilityHelper.ListToDataTable(getBanks(_isActive));
        }
        #endregion

        #region private methods
        private static List<BankList> getBanks(bool isActive)
        {
            List<BankList> lstBank = new List<BankList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getBankList"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, isActive);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstBank.Add(new BankList(
                              Convert.ToInt16(dr["BankId"]),
                                dr["BankName"].ToString(),
                                 Convert.ToBoolean(dr["IsActive"])));
                        }
                    }
                }
            }
            return lstBank;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}