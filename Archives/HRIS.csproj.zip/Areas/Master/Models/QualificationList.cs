﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class QualificationList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short QualificationId { get; set; }
        public string QualificationName { get; set; }

        #endregion

        #region constructor
        public QualificationList()
        {
        }

        public QualificationList(short _QualificationId, string _QualificationName)
        {
            QualificationId = _QualificationId;
            QualificationName = _QualificationName;

        }
        #endregion

        #region internal methods
        internal static List<QualificationList> Get()
        {
            return getQualifications();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getQualifications());
        }
        #endregion

        #region private methods
        private static List<QualificationList> getQualifications()
        {
            List<QualificationList> lstQualification = new List<QualificationList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getQualificationList"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstQualification.Add(new QualificationList(
                             Convert.ToInt16(dr["QualificationId"]),
                                dr["QualificationName"].ToString()));
                        }
                    }
                }
            }
            return lstQualification;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}