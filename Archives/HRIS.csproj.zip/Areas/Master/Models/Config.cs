﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Config : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "LoanDeductionId")]
        public short? LoanDeductionId { get; set; }
        [Display(Name = "AdvanceDeductionId")]
        public short? AdvanceDeductionId { get; set; }
        [Display(Name = "AbsentDeductionId")]
        public short? AbsentDeductionId { get; set; }
        [Display(Name = "ProvidentFundId")]
        public short? ProvidentFundId { get; set; }
        [Display(Name = "BasicSalaryId")]
        public short? BasicSalaryId { get; set; }
        [Display(Name = "Email Text")]
        public string EmailText { get; set; }
        [Display(Name = "Month")]
        public string CurrentMonth { get; set; }
        [Display(Name = "Year")]
        public int CurrentYear { get; set; }
        #endregion

        #region Constructor
        public Config()
        {
 
        }
        #endregion

        #region internal methods
        internal static Config Get()
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetConfigDetail"))
                {
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables[0].Rows.Count > 0)
                        {
                            using (Config fp = new Config())
                            {
                                DataRow dr = ds.Tables[0].Rows[0];
                                fp.CurrentMonth = dr["CurrentMonth"].ToString();
                                fp.CurrentYear = Convert.ToInt32(dr["CurrentYear"]);
                                fp.AbsentDeductionId = Convert.ToInt16(dr["AbsentDeductionId"]);
                                fp.BasicSalaryId = Convert.ToInt16(dr["BasicSalaryId"]);
                                fp.ProvidentFundId = Convert.ToInt16(dr["ProvidentFundId"]);
                                fp.AdvanceDeductionId = Convert.ToInt16(dr["AdvanceDeductionId"]);
                                fp.LoanDeductionId = Convert.ToInt16(dr["LoanDeductionId"]);
                                fp.EmailText = dr["EmailText"].ToString();
                                return fp;
                            }
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            { throw; }
        }

        //internal static Config GetCurrentPeriod()
        //{
        //    try
        //    {
        //        using (DbCommand dbCommand = db.GetStoredProcCommand("getCurrentPeriod"))
        //        {
        //            using (DataSet ds = db.ExecuteDataSet(dbCommand))
        //            {
        //                if (ds != null && ds.Tables[0].Rows.Count > 0)
        //                {
        //                    using (Config fp = new Config())
        //                    {
        //                        DataRow dr = ds.Tables[0].Rows[0];
        //                        fp.CurrentMonth = dr["CurrentMonth"].ToString();
        //                        fp.CurrentYear = Convert.ToInt32(dr["CurrentYear"]);
        //                        return fp;
        //                    }
        //                }
        //                else
        //                    return null;
        //            }
        //        }
        //    }
        //    catch (Exception)
        //    { throw; }
        //}
        internal static bool Save(Config _cfg, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveConfig"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "LoanDeductionId", SqlDbType.TinyInt, _cfg.LoanDeductionId);
                    db.AddInParameter(dbCommand, "AdvanceDeductionId", SqlDbType.TinyInt, _cfg.AdvanceDeductionId);
                    db.AddInParameter(dbCommand, "AbsentDeductionId", SqlDbType.TinyInt, _cfg.AbsentDeductionId);
                    db.AddInParameter(dbCommand, "EmailText", SqlDbType.VarChar, _cfg.EmailText);  
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}