﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Branch : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Branch Code")]
        public string BranchCode { get; set; }
        [Display(Name = "Branch Name")]
        public string BranchName { get; set; }
        [Display(Name = "SS (%)")]
        public double SSPercentage { get; set; }
        [Display(Name = "SS Max Amount")]
        public double SSMaxAmount { get; set; }
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public Branch()
        {
            AuditTrail = new Footer();
            IsActive = true;
        }
        #endregion

        #region internal methods
        internal static Branch Get(string _branchCode)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetBranchByCode"))
            {
                db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _branchCode);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (Branch _bran = new Branch())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _bran.BranchCode = dr["BranchCode"].ToString();
                            _bran.BranchName = dr["BranchName"].ToString();
                            _bran.SSPercentage = Convert.ToDouble(dr["SocialSecurityPercentage"]);
                            _bran.SSMaxAmount = Convert.ToDouble(dr["SocialSecurityMaxAmount"]);
                            _bran.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _bran.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _bran.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _bran.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _bran.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                            return _bran;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(Branch _bran, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveBranch"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _bran.BranchCode);
                    db.AddInParameter(dbCommand, "SSPercentage", SqlDbType.Float, _bran.SSPercentage);
                    db.AddInParameter(dbCommand, "SSMaxAmount", SqlDbType.Float, _bran.SSMaxAmount);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _bran.AuditTrail.UpdatedOn);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
