﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class AttachmentType : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Doc Id")]
        public short? AttachmentTypeId { get; set; }
        [Display(Name = "Doc Type Name")]
        public string AttachmentTypeName { get; set; }
        [Display(Name = "Mandatory")]
        public bool Mandatory { get; set; }
        [Display(Name = "Expiry Date Required")]
        public bool ExpiryDateRequired { get; set; }
        [Display(Name = "IsActive")]
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public AttachmentType()
        {
            AuditTrail = new Footer();
            IsActive = true;
        }
        #endregion

        #region internal methods
        internal static AttachmentType Get(short _typeId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetDocumentAttachmentTypeByCode"))
            {
                db.AddInParameter(dbCommand, "AttachmentTypeId", SqlDbType.TinyInt, _typeId);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (AttachmentType _at = new AttachmentType())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _at.AttachmentTypeId = _typeId;
                            _at.AttachmentTypeName = dr["AttachmentTypeName"].ToString();
                            _at.Mandatory = Convert.ToBoolean(dr["Mandatory"]);
                            _at.ExpiryDateRequired = Convert.ToBoolean(dr["ExpiryDateRequired"]);
                            _at.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _at.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _at.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _at.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _at.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                         

                            return _at;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(AttachmentType _at, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveDocumentAttachmentType"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "AttachmentTypeId", SqlDbType.TinyInt, _at.AttachmentTypeId);
                    db.AddInParameter(dbCommand, "AttachmentTypeName", SqlDbType.VarChar, _at.AttachmentTypeName);
                    db.AddInParameter(dbCommand, "Mandatory", SqlDbType.Float, _at.Mandatory);
                    db.AddInParameter(dbCommand, "ExpiryDateRequired", SqlDbType.Float, _at.ExpiryDateRequired);
                    db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _at.IsActive);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _at.AuditTrail.UpdatedOn);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
