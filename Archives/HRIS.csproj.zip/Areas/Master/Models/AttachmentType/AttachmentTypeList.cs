﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class AttachmentTypeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Attachment Type")]
        public short AttachmentTypeId { get; set; }
        [DataMember(Order = 1)]
        [Display(Name = "Attachment Type Name")]
        public string AttachmentTypeName { get; set; }
        [DataMember(Order = 2)]
        [Display(Name = "Mandatory")]
        public bool Mandatory { get; set; }
        [DataMember(Order = 3)]
        [Display(Name = "Expiry Date Required")]
        public bool ExpiryDateRequired { get; set; }
        [DataMember(Order = 4)]
        public bool IsActive { get; set; }
        #endregion

        #region constructor
        public AttachmentTypeList(short _typeId, string _typeName, bool _mandatory,
            bool _expiryDateRequired, bool _isActive = true)
        {
            AttachmentTypeId = _typeId;
            AttachmentTypeName = _typeName;
            Mandatory = _mandatory;
            ExpiryDateRequired = _expiryDateRequired;
            IsActive = _isActive;
        }
        #endregion

        #region internal methods
        internal static List<AttachmentTypeList> Get(bool _isActive = true)
        {
            return getAttachmentTypes(_isActive);
        }

        internal static DataTable GetDT(bool _isActive = true)
        {
            return AgilityHelper.ListToDataTable(getAttachmentTypes(_isActive));
        }
        #endregion

        #region private methods
        private static List<AttachmentTypeList> getAttachmentTypes(bool isActive)
        {
            List<AttachmentTypeList> lstAT = new List<AttachmentTypeList>();

            DbCommand dbCommand = db.GetStoredProcCommand("getDocumentAttachmentTypeList");
            db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, isActive);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstAT.Add(new AttachmentTypeList(
                             Convert.ToInt16(dr["AttachmentTypeId"]),
                                dr["AttachmentTypeName"].ToString(),
                                  Convert.ToBoolean(dr["Mandatory"]),
                                   Convert.ToBoolean(dr["ExpiryDateRequired"]),
                                   Convert.ToBoolean(dr["IsActive"])));
                    }
                }
            }
            return lstAT;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}
