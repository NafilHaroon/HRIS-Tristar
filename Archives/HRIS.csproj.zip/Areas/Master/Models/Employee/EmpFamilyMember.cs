﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpFamilyMember : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Relation")]
        public short? RelationId { get; set; }
        [Display(Name = "Person Name")]
        public string PersonName { get; set; }
        [Display(Name = "Medical Plan")]
        public short? MedicalPlanId { get; set; }
        [Display(Name = "Medical Cost")]
        public double MedicalCost { get; set; }
        [Display(Name = "DOB")]
        public DateTime? DOB { get; set; }
        [Display(Name = "EffectiveDate")]
        public DateTime? EffectiveDate { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }
       

        #endregion

        #region constructor
        public EmpFamilyMember()
        {
            DetailId = 1;
            var myDate = DateTime.Now;
            DOB = myDate.AddYears(-18);
            Status ="Added";
        }
        public EmpFamilyMember(int _detailId, short _RelationId, string _PersonName, short _MedicalPlanId,
            double _MedicalCost, DateTime _DOB, DateTime _EffectiveDate, 
            string  _itemState = "UnChanged")
        {
            
            DetailId = _detailId;
            RelationId = _RelationId;
            PersonName = _PersonName;
            MedicalPlanId = _MedicalPlanId;
            MedicalCost = _MedicalCost;
            DOB = _DOB;
            EffectiveDate = _EffectiveDate;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<EmpFamilyMember> Get(short _empid)
        {
            try
            {
                List<EmpFamilyMember> lstEMD = new List<EmpFamilyMember>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeFamilyDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empid);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                           
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstEMD.Add(new EmpFamilyMember(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["RelationId"]),
                                    dr["PersonName"].ToString(),
                                     Convert.ToInt16(dr["MedicalPlanId"]),
                                    Convert.ToDouble(dr["MedicalCost"]),
                                    Convert.ToDateTime(dr["DOB"]),
                                    Convert.ToDateTime(dr["EffectiveDate"])));
                            }
                        }
                    }                  
                }
                return lstEMD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpFamilyMember> _details, List<EmpFamilyMember> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpFamilyMember eld in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeFamilyDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "RelationId", SqlDbType.TinyInt, eld.RelationId);
                        db.AddInParameter(dbCommand, "PersonName", SqlDbType.VarChar, eld.PersonName);
                        db.AddInParameter(dbCommand, "MedicalPlanId", SqlDbType.TinyInt, eld.MedicalPlanId);
                        db.AddInParameter(dbCommand, "MedicalCost", SqlDbType.Float, eld.MedicalCost);
                        db.AddInParameter(dbCommand, "DOB", SqlDbType.SmallDateTime, eld.DOB);
                        db.AddInParameter(dbCommand, "EffectiveDate", SqlDbType.SmallDateTime, eld.EffectiveDate);    

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            eld.Status == "Added" ? "I" : (
                            eld.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpFamilyMember> getChanges(List<EmpFamilyMember> _details,
         List<EmpFamilyMember> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmpFamilyMember> editedItems = (IEnumerable<EmpFamilyMember>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmpFamilyMember>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}