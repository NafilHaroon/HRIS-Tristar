﻿using HRIS.Areas.Common.Models;
using HRIS.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
namespace HRIS.Areas.Master.Models
{
    public class Employee : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Employee Id")]
        public short? EmployeeId { get; set; }
        [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }
        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }
        [Display(Name = "Head Name")]
        public string HeadName { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Supervisor")]
        public short? SupervisorId { get; set; }
        [Display(Name = "Branch")]
        public string BranchCode { get; set; }
        [Display(Name = "Department")]
        public string DepartmentCode { get; set; }
        [Display(Name = "Grade")]
        public string GradeId { get; set; }
        [Display(Name = "Designation")]
        public string Designation { get; set; }
        [Display(Name = "Hiring Type")]
        public short? HiringType { get; set; }
        [Display(Name = "Replacement Employee")]
        public short? ReplacementEmployeeId { get; set; }
        [Display(Name = "Job Nature")]
        public short? JobNatureId { get; set; }
        [Display(Name = "Joining Date")]
        public DateTime? JoiningDate { get; set; }
        [Display(Name = "Confirmation Due Date")]
        public DateTime? ConfirmationDueDate { get; set; }
        [Display(Name = "Confirmation Date")]
        public DateTime? ConfirmationDate { get; set; }
        [Display(Name = "Seperation Date")]
        public DateTime? SeparationDate { get; set; }    
        [Display(Name = "Employee Status")]
        public short? StatusCode { get; set; }
        public string ReasonForSeperation { get; set; }
        public string ValidationError { get; set; }
        public bool IsConfirmed { get; set; }
        [Display(Name = "Supervisor")]
        public short? NewSupervisorId { get; set; }
        [Display(Name = "Life Insurance")]
        public double LifeInsurance { get; set; }
        public short BSSession { get; set; }
        public short PFSession { get; set; }
        [Display(Name = "Employee Type")]
        public short? EmployeeTypeId { get; set; }

        public EmpDetail EmpDetails { get; set; }
        public List<EmpSalary> EmpSalaryMonthlyDetails { get; set; }
        public List<EmpSalary> donotUseEmpSMDetails { get; set; }
        //public List<EmpSalaryNonMonthlyDetail> EmpSalaryNonMonthlyDetails { get; set; }
        //public List<EmpSalaryNonMonthlyDetail> donotUseEmpSNMDetails { get; set; }
        public List<EmpCostAllocation> EmpCostAllocatioDetails { get; set; }
        public List<EmpCostAllocation> donotUseEmpCADetails { get; set; }
        public List<EmpEmergencyContact> EmpEmergencyContactDetails { get; set; }
        public List<EmpEmergencyContact> donotUseEmpEmergencyContactDetails { get; set; }
        public List<EmpFamilyMember> EmpFamilyMemberDetails { get; set; }
        public List<EmpFamilyMember> donotUseEmpFMDetails { get; set; }
        public List<EmpLeave> EmpLeaveDetails { get; set; }
        public List<EmpLeave> donotUseEmpLDetails { get; set; }
        public List<EmpAsset> EmpAssetDetails { get; set; }
        public List<EmpAsset> donotUseEmpADetails { get; set; }

        public List<EmpAttachment> EmpAttachmentDetails { get; set; }
        //public List<EmpAttachmentDetail> donotUseEmpATTDetails { get; set; }

        public byte[] ProfileImage { get; set; }
        public string image { get; set; }
       // public HttpPostedFile image { get; set; }   

        public Footer AuditTrail { get; set; }
        #endregion

        #region constructor
        public Employee()
        {
            AuditTrail = new Footer();
            JoiningDate = DateTime.Now;
            ConfirmationDueDate = DateTime.Now;
            EmpDetails = new EmpDetail();
            EmpLeaveDetails = new List<EmpLeave>();
            donotUseEmpLDetails = new List<EmpLeave>();
            EmpAssetDetails = new List<EmpAsset>();
            donotUseEmpADetails = new List<EmpAsset>();
            EmpEmergencyContactDetails = new List<EmpEmergencyContact>();
            donotUseEmpEmergencyContactDetails = new List<EmpEmergencyContact>();
            EmpFamilyMemberDetails = new List<EmpFamilyMember>();
            donotUseEmpFMDetails = new List<EmpFamilyMember>();
            EmpSalaryMonthlyDetails = new List<EmpSalary>();
            donotUseEmpSMDetails = new List<EmpSalary>();
            //EmpSalaryNonMonthlyDetails = new List<EmpSalaryNonMonthlyDetail>();
            //donotUseEmpSNMDetails = new List<EmpSalaryNonMonthlyDetail>();
            EmpCostAllocatioDetails = new List<EmpCostAllocation>();
            donotUseEmpCADetails = new List<EmpCostAllocation>();
            EmpAttachmentDetails = new List<EmpAttachment>();
            //donotUseEmpATTDetails = new List<EmpAttachmentDetail>();
        }
        #endregion

        #region internal methods


        internal static Employee Get(string _employeecode)
        {
            try
            {
                using (DbCommand dbCommandDetail = db.GetStoredProcCommand("getEmployeeByCode"))
                {
                    db.AddInParameter(dbCommandDetail, "EmployeeCode", SqlDbType.VarChar, _employeecode);
                    using (DataSet ds = db.ExecuteDataSet(dbCommandDetail))
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            Employee _cn = new Employee();
                            DataRow dr = ds.Tables[0].Rows[0];
                            _cn.EmployeeCode = dr["EmployeeCode"].ToString();
                            _cn.EmployeeId = Convert.ToInt16(dr["EmployeeId"]);
                            _cn.EmployeeName = dr["EmployeeName"].ToString();
                            _cn.HeadName = dr["HeadName"].ToString();
                            _cn.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                            _cn.SupervisorId = Convert.ToInt16(dr["SupervisorId"]);
                            _cn.BranchCode = dr["BranchCode"].ToString();
                            _cn.DepartmentCode = dr["DepartmentCode"].ToString();
                            _cn.GradeId = dr["GradeId"].ToString();
                            _cn.Designation = dr["Designation"].ToString();

                            _cn.HiringType = Convert.ToInt16(dr["HiringType"]);

                            if (dr["ReplacementEmployeeId"] != DBNull.Value)
                            {
                                if (_cn.HiringType==2)
                                    _cn.ReplacementEmployeeId =Convert.ToInt16(dr["ReplacementEmployeeId"]);
                                //else
                                //    cmbReplacementEmployeePromotion.SelectedValue = dr["ReplacementEmployeeCode"].ToString();
                            }

                            _cn.JobNatureId = Convert.ToInt16(dr["JobNatureId"]);
                            _cn.JoiningDate = Convert.ToDateTime(dr["JoiningDate"]);

                            if (dr["ConfirmationDueDate"] != DBNull.Value)
                            {
                                _cn.ConfirmationDueDate = Convert.ToDateTime(dr["ConfirmationDueDate"]);
                            }                        

                            if (dr["ConfirmationDate"] != DBNull.Value)
                            {
                                _cn.ConfirmationDate = Convert.ToDateTime(dr["ConfirmationDate"]);
                                _cn.IsConfirmed = true;
                            }
                            else
                                _cn.IsConfirmed = false;

                            _cn.StatusCode = Convert.ToInt16(dr["StatusCode"]);

                            if (_cn.StatusCode != 1)
                            {
                                _cn.SeparationDate = Convert.ToDateTime(dr["SeparationDate"]);
                                _cn.ReasonForSeperation = dr["ReasonForSeparation"].ToString();
                            }     
                            _cn.StatusCode = Convert.ToInt16(dr["StatusCode"]);

                            _cn.LifeInsurance = Convert.ToDouble(dr["LifeInsurance"]);
                            _cn.EmployeeTypeId = Convert.ToInt16(dr["EmployeeTypeId"]);

                            if (dr["ProfileImage"] != DBNull.Value)
                                _cn.ProfileImage = (byte[])dr["ProfileImage"];

                            _cn.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _cn.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _cn.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _cn.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);

                            _cn.EmpDetails = EmpDetail.Get(_cn.EmployeeId.Value);

                            _cn.donotUseEmpLDetails = EmpLeave.Get(_cn.EmployeeId.Value);
                            _cn.EmpLeaveDetails = _cn.donotUseEmpLDetails.Clone();

                            _cn.donotUseEmpEmergencyContactDetails = EmpEmergencyContact.Get(_cn.EmployeeId.Value);
                            _cn.EmpEmergencyContactDetails = _cn.donotUseEmpEmergencyContactDetails.Clone();

                            _cn.donotUseEmpFMDetails = EmpFamilyMember.Get(_cn.EmployeeId.Value);
                            _cn.EmpFamilyMemberDetails = _cn.donotUseEmpFMDetails.Clone();

                            _cn.donotUseEmpADetails = EmpAsset.Get(_cn.EmployeeId.Value);
                            _cn.EmpAssetDetails = _cn.donotUseEmpADetails.Clone();

                            _cn.donotUseEmpSMDetails = EmpSalary.Get(_cn.EmployeeId.Value);
                            _cn.EmpSalaryMonthlyDetails = _cn.donotUseEmpSMDetails.Clone();

                            //_cn.donotUseEmpSNMDetails = EmpSalaryNonMonthlyDetail.Get(_cn.EmployeeId.Value);
                            //_cn.EmpSalaryNonMonthlyDetails = _cn.donotUseEmpSNMDetails.Clone();

                            _cn.donotUseEmpCADetails = EmpCostAllocation.Get(_cn.EmployeeId.Value);
                            _cn.EmpCostAllocatioDetails = _cn.donotUseEmpCADetails.Clone();

                            _cn.EmpAttachmentDetails = EmpAttachment.Get(_cn.EmployeeId.Value);

                            //_cn.donotUseEmpATTDetails = EmpAttachmentDetail.Get(_cn.EmployeeId.Value);
                            //_cn.EmpAttachmentDetails = _cn.donotUseEmpATTDetails.Clone();

                            return _cn;
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Save(Employee _emp, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployee"))
            {
                db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _emp.EmployeeId);
                db.AddInParameter(dbCommand, "EmployeeCode", SqlDbType.VarChar, _emp.EmployeeCode);
                db.AddInParameter(dbCommand, "EmployeeName", SqlDbType.VarChar, _emp.EmployeeName);
                db.AddInParameter(dbCommand, "HeadName", SqlDbType.VarChar, _emp.HeadName);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _emp.CompanyId);
                db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _emp.BranchCode);
                db.AddInParameter(dbCommand, "SupervisorId", SqlDbType.SmallInt, _emp.SupervisorId);
                db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, _emp.DepartmentCode);
                db.AddInParameter(dbCommand, "GradeId", SqlDbType.VarChar, _emp.GradeId);
                db.AddInParameter(dbCommand, "Designation", SqlDbType.VarChar, _emp.Designation);
                db.AddInParameter(dbCommand, "HiringType", SqlDbType.SmallInt, _emp.HiringType);
                db.AddInParameter(dbCommand, "ReplacementEmployeeId", SqlDbType.SmallInt, _emp.ReplacementEmployeeId);
                db.AddInParameter(dbCommand, "JobNatureId", SqlDbType.SmallInt, _emp.JobNatureId);
                db.AddInParameter(dbCommand, "JoiningDate", SqlDbType.DateTime, _emp.JoiningDate);
                db.AddInParameter(dbCommand, "ConfirmationDueDate", SqlDbType.DateTime, _emp.ConfirmationDueDate);
                db.AddInParameter(dbCommand, "ConfirmationDate", SqlDbType.DateTime, _emp.ConfirmationDate);
                db.AddInParameter(dbCommand, "SeparationDate", SqlDbType.DateTime, _emp.SeparationDate);
                db.AddInParameter(dbCommand, "ReasonForSeperation", SqlDbType.DateTime, _emp.ReasonForSeperation);
                db.AddInParameter(dbCommand, "StatusCode", SqlDbType.SmallInt, _emp.StatusCode);
                db.AddInParameter(dbCommand, "LifeInsurance", SqlDbType.Float, _emp.LifeInsurance);
                db.AddInParameter(dbCommand, "EmployeeTypeId", SqlDbType.SmallInt, _emp.EmployeeTypeId);
                db.AddInParameter(dbCommand, "ProfileImage", SqlDbType.VarBinary, _emp.ProfileImage);
               

                db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                db.AddOutParameter(dbCommand, "newEmployeeCode", SqlDbType.VarChar, 32);
                db.AddOutParameter(dbCommand, "newEmployeeId", SqlDbType.SmallInt, 32);
                db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _emp.AuditTrail.UpdatedOn);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        _emp.EmployeeCode = dbCommand.Parameters["@newEmployeeCode"].Value.ToString();
                        _emp.EmployeeId = Convert.ToInt16(dbCommand.Parameters["@newEmployeeId"].Value);

                        EmpDetail.Save(_emp.EmployeeId.Value, _emp.EmpDetails, _userId, transaction);
                        EmpLeave.Save(_emp.EmployeeId.Value, _emp.EmpLeaveDetails, _emp.donotUseEmpLDetails, _userId, transaction);
                        EmpFamilyMember.Save(_emp.EmployeeId.Value, _emp.EmpFamilyMemberDetails, _emp.donotUseEmpFMDetails, _userId, transaction);
                        EmpEmergencyContact.Save(_emp.EmployeeId.Value, _emp.EmpEmergencyContactDetails, _emp.donotUseEmpEmergencyContactDetails, _userId, transaction);
                        EmpAsset.Save(_emp.EmployeeId.Value, _emp.EmpAssetDetails, _emp.donotUseEmpADetails, _userId, transaction);
                        EmpSalary.Save(_emp.EmployeeId.Value, _emp.EmpSalaryMonthlyDetails, _emp.donotUseEmpSMDetails, _userId, transaction);
                        //EmpSalaryNonMonthlyDetail.Save(_emp.EmployeeCode, _emp.EmpSalaryNonMonthlyDetails, _emp.donotUseEmpSNMDetails, _userId, transaction);
                        EmpCostAllocation.Save(_emp.EmployeeId.Value, _emp.EmpCostAllocatioDetails, _emp.donotUseEmpCADetails, _userId, transaction);

                        if (_emp.EmpAttachmentDetails.Count>0)
                        {
                            EmpAttachment.Save(_emp.EmployeeId.Value, _emp.EmpAttachmentDetails, _userId, transaction);
                        }                        


                        _emp.EmpLeaveDetails.ForEach(o => o.Status = "UnChanged");
                        _emp.donotUseEmpLDetails = _emp.EmpLeaveDetails.Clone();

                        _emp.EmpFamilyMemberDetails.ForEach(o => o.Status = "UnChanged");
                        _emp.donotUseEmpFMDetails = _emp.EmpFamilyMemberDetails.Clone();

                        _emp.EmpEmergencyContactDetails.ForEach(o => o.Status =  "UnChanged");
                        _emp.donotUseEmpEmergencyContactDetails = _emp.EmpEmergencyContactDetails.Clone();

                        _emp.EmpAssetDetails.ForEach(o => o.Status = "UnChanged");
                        _emp.donotUseEmpADetails = _emp.EmpAssetDetails.Clone();

                        _emp.EmpSalaryMonthlyDetails.ForEach(o => o.Status = "UnChanged");
                        _emp.donotUseEmpSMDetails = _emp.EmpSalaryMonthlyDetails.Clone();

                        //_emp.EmpSalaryNonMonthlyDetails.ForEach(o => o.Status = "UnChanged");
                        //_emp.donotUseEmpSNMDetails = _emp.EmpSalaryNonMonthlyDetails.Clone();

                        _emp.EmpCostAllocatioDetails.ForEach(o => o.Status = "UnChanged");
                        _emp.donotUseEmpCADetails = _emp.EmpCostAllocatioDetails.Clone();

                        //_emp.EmpAttachmentDetails.ForEach(o => o.Status = "UnChanged");
                        //_emp.donotUseEmpATTDetails = _emp.EmpAttachmentDetails.Clone();

                        transaction.Commit();
                        return true;
                    }

                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }



        internal static bool ChangeSupervisor(Employee _emp, string _userId)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("ChangeSupervisor"))
                {
                    db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, _emp.BranchCode);
                    db.AddInParameter(dbCommand, "DepartmentCode", SqlDbType.VarChar, _emp.DepartmentCode);
                    db.AddInParameter(dbCommand, "CurrentSuperVisorId", SqlDbType.SmallInt, _emp.SupervisorId);
                    db.AddInParameter(dbCommand, "NewSupervisorId", SqlDbType.SmallInt, _emp.SupervisorId);
                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);

                    db.ExecuteNonQuery(dbCommand);

                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Delete(string _empid)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("DeleteEmployee"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.VarChar, _empid);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
            }
            catch (Exception)
            { throw; }
        }

       
      
        #endregion

        #region private methods
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
    }
}