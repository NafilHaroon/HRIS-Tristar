﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpSalary : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Head")]
        public short? HeadId { get; set; }
        [Display(Name = "Amount")]
        public double Amount { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }
        public double TotalSalary { get; set; }


        #endregion

        #region constructor
        public EmpSalary()
        {
            DetailId = 1;
            Status = "Added";
        }
        public EmpSalary(int _detailId, short _HeadId, double _Amount,
            string _itemState = "UnChanged")
        {

            DetailId = _detailId;
            HeadId = _HeadId;
            Amount = _Amount;
            Status = _itemState;
        }
        #endregion

        #region internal methods

        internal static List<EmpSalary> Get(short _empId)
        {
            try
            {
                List<EmpSalary> lstESMD = new List<EmpSalary>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeSalaryDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstESMD.Add(new EmpSalary(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["HeadId"]),
                                         Convert.ToDouble(dr["Amount"])));
                            }
                        }
                    }
                }
                return lstESMD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpSalary> _details, List<EmpSalary> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpSalary eld in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeSalaryDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, eld.HeadId);
                        db.AddInParameter(dbCommand, "Amount", SqlDbType.Float, eld.Amount);

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            eld.Status == "Added" ? "I" : (
                            eld.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpSalary> getChanges(List<EmpSalary> _details,
         List<EmpSalary> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmpSalary> editedItems = (IEnumerable<EmpSalary>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmpSalary>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion

    }
}