﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class EmployeeList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         [DataMember(Order = 0)]
         [Display(Name = "Employee Code")]
        public string EmployeeCode { get; set; }
         [DataMember(Order = 1)]
         [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }
         [DataMember(Order = 2)]
         [Display(Name = "Employee Id")]
        public short EmployeeId { get; set; }
         [DataMember(Order = 3)]
         [Display(Name = "Branch Name")]
        public string BranchName { get; set; }
         [DataMember(Order = 4)]
         [Display(Name = "Department Name")]
        public string DepartmentName { get; set; }
  
        #endregion

        #region constructor
        public EmployeeList()
        {
        }

        public EmployeeList(string _EmployeeCode, string _EmployeeName)
        {           
                EmployeeCode = _EmployeeCode;
                EmployeeName = _EmployeeName;
           
        }

        public EmployeeList(string _EmployeeCode, string _EmployeeName, short _EmployeeId)
        {
            EmployeeCode = _EmployeeCode;
            EmployeeName = _EmployeeName;
            EmployeeId = _EmployeeId;

        }


        public EmployeeList(string _EmployeeCode, string _EmployeeName, short _EmployeeId, string _BranchName, string _DepartmentName)
        {
            EmployeeCode = _EmployeeCode;
            EmployeeName = _EmployeeName;           
            EmployeeId = _EmployeeId;
            BranchName=_BranchName;
            DepartmentName=_DepartmentName;

        }
        #endregion

        #region internal methods
        internal static List<EmployeeList> Get(string UserId)
        {
            return getEmployees(UserId);
        }

        internal static List<EmployeeList> GetInActive()
        {
            return getInactiveEmployees();
        }

        internal static List<EmployeeList> GetAllowed(string UserId)
        {
            return getAllowedEmployees(UserId);
        }

        internal static DataTable GetDT(string UserId)
        {
            return AgilityHelper.ListToDataTable(getEmployees(UserId));
        }
        #endregion

        #region private methods
        private static List<EmployeeList> getEmployees(string UserId)
        {
            List<EmployeeList> lstEmployeeList = new List<EmployeeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeList"))
            {
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, UserId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstEmployeeList.Add(new EmployeeList(                              
                                dr["EmployeeCode"].ToString(),
                                dr["EmployeeName"].ToString(),
                                 Convert.ToInt16(dr["EmployeeId"]),
                                  dr["BranchName"].ToString(),
                                   dr["DepartmentName"].ToString()));
                        }
                    }
                }
            }
            return lstEmployeeList;
        }

        private static List<EmployeeList> getInactiveEmployees()
        {
            List<EmployeeList> lstEmployeeList = new List<EmployeeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getInactiveEmployeeList"))
            {

                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstEmployeeList.Add(new EmployeeList(
                                dr["EmployeeCode"].ToString(),
                                dr["EmployeeName"].ToString()));
                        }
                    }
                }
            }
            return lstEmployeeList;
        }

        private static List<EmployeeList> getAllowedEmployees(string UserId)
        {
            List<EmployeeList> lstEmployeeList = new List<EmployeeList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getAllowedEmployeeList"))
            {
                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, UserId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstEmployeeList.Add(new EmployeeList(                            
                                dr["EmployeeName"].ToString(),
                                dr["EmployeeCode"].ToString(),
                                  Convert.ToInt16(dr["EmployeeId"])));
                        }
                    }
                }
            }
            return lstEmployeeList;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}