﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpAsset : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "EmpAsset")]
        public short? AssetId { get; set; }
        [Display(Name = "Registration #")]
        public string RegistrationNumber { get; set; }
        [Display(Name = "Model")]
        public string Model { get; set; }
        [Display(Name = "Issue Date")]
        public DateTime? IssueDate { get; set; }
        [Display(Name = "Base Value")]
        public double BaseValue { get; set; }
        [Display(Name = "Limit")]
        public double Limit { get; set; }
        [Display(Name = "Consumable")]
        public bool Consumable { get; set; }
        [Display(Name = "Active")]
        public bool Active { get; set; }
        [Display(Name = "Expiry Date")]
        public DateTime? ExpiryDate { get; set; }
        [Display(Name = "Reminder Date")]
        public DateTime? ReminderDate { get; set; }
        [Display(Name = "Disposal Date")]
        public DateTime? DisposalDate { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }
        #endregion

        #region constructor
        public EmpAsset()
        {
            DetailId = 1;
            Status = "Added";
        }
        public EmpAsset(int _detailId, short _assetId, string _RegistrationNumber, string _Model,
            DateTime _IssueDate, double _BaseValue, double _Limit, bool _Consumable, bool _Active, DateTime _ExpiryDate,
            DateTime _ReminderDate, DateTime _DisposalDate,
            string _itemState = "UnChanged")
        {

            DetailId = _detailId;
            AssetId = _assetId;
            RegistrationNumber = _RegistrationNumber;
            Model = _Model;
            IssueDate = _IssueDate;
            BaseValue = _BaseValue;
            Limit = _Limit;
            Consumable = _Consumable;
            Active = _Active;
            ExpiryDate = _ExpiryDate;
            ReminderDate = _ReminderDate;
            DisposalDate = _DisposalDate;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<EmpAsset> Get(short _empId)
        {
            try
            {
                List<EmpAsset> lstEAD = new List<EmpAsset>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeEmpAssetDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstEAD.Add(new EmpAsset(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["EmpAssetId"]),
                                    dr["RegistrationNumber"].ToString(),
                                     dr["Model"].ToString(),
                                      Convert.ToDateTime(dr["IssueDate"]),
                                       Convert.ToDouble(dr["BaseValue"]),
                                         Convert.ToDouble(dr["Limit"]),
                                     Convert.ToBoolean(dr["Consumable"]),
                                      Convert.ToBoolean(dr["Active"]),
                                    Convert.ToDateTime(dr["ExpiryDate"]),
                                    Convert.ToDateTime(dr["ReminderDate"]),
                                    Convert.ToDateTime(dr["DisposalDate"])));
                            }
                        }
                    }
                }
                return lstEAD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpAsset> _details, List<EmpAsset> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpAsset eld in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeEmpAssetDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "EmpAssetId", SqlDbType.TinyInt, eld.AssetId);
                        db.AddInParameter(dbCommand, "RegistrationNumber", SqlDbType.VarChar, eld.RegistrationNumber);
                        db.AddInParameter(dbCommand, "IssueDate", SqlDbType.SmallDateTime, eld.IssueDate);
                        db.AddInParameter(dbCommand, "Model", SqlDbType.VarChar, eld.Model);
                        db.AddInParameter(dbCommand, "BaseValue", SqlDbType.Float, eld.BaseValue);
                        db.AddInParameter(dbCommand, "Limit", SqlDbType.Float, eld.Limit);
                        //db.AddInParameter(dbCommand, "BaseValue", SqlDbType.Bit, eld.BaseValue);
                        db.AddInParameter(dbCommand, "Active", SqlDbType.Bit, eld.Active);
                        db.AddInParameter(dbCommand, "Consumable", SqlDbType.Bit, eld.@Consumable);
                        db.AddInParameter(dbCommand, "ExpiryDate", SqlDbType.SmallDateTime, eld.ExpiryDate);
                        db.AddInParameter(dbCommand, "ReminderDate", SqlDbType.SmallDateTime, eld.ReminderDate);
                        db.AddInParameter(dbCommand, "DisposalDate", SqlDbType.SmallDateTime, eld.DisposalDate);

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            eld.Status == "Added" ? "I" : (
                            eld.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpAsset> getChanges(List<EmpAsset> _details,
         List<EmpAsset> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmpAsset> editedItems = (IEnumerable<EmpAsset>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmpAsset>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}