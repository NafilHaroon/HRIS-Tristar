﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpCostAllocation : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Template")]
        public short? TemplateId { get; set; }
        [Display(Name = "Branch")]
        public string BranchCode { get; set; }
        [Display(Name = "Percentage")]
        public double Percentage { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }


        #endregion

        #region constructor
        public EmpCostAllocation()
        {
            DetailId = 1;
            Status = "Added";
        }
        public EmpCostAllocation(int _detailId, short _TemplateId, string _BranchCode, double _percetage,
            string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            TemplateId = _TemplateId;
            BranchCode = _BranchCode;
            Percentage = _percetage;
            Status = _itemState;
        }
        #endregion

        #region internal methods

        internal static List<EmpCostAllocation> Get(short _empId)
        {
            try
            {
                List<EmpCostAllocation> lstATD = new List<EmpCostAllocation>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeCostADetailByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstATD.Add(new EmpCostAllocation(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["TemplateId"]),
                                         dr["BranchCode"].ToString(),
                                         Convert.ToDouble(dr["Percentage"])));
                            }
                        }
                    }
                }
                return lstATD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<EmpCostAllocation> _details, List<EmpCostAllocation> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpCostAllocation ATD in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeCostADetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, ATD.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "BranchCode", SqlDbType.VarChar, ATD.BranchCode);
                        db.AddInParameter(dbCommand, "TemplateId", SqlDbType.TinyInt, ATD.TemplateId);
                        db.AddInParameter(dbCommand, "Percentage", SqlDbType.Float, ATD.Percentage);

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            ATD.Status == "Added" ? "I" : (
                            ATD.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpCostAllocation> getChanges(List<EmpCostAllocation> _details,
         List<EmpCostAllocation> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmpCostAllocation> editedItems = (IEnumerable<EmpCostAllocation>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmpCostAllocation>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}