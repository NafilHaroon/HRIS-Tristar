﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
namespace HRIS.Areas.Master.Models
{
    public class EmpDetail : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Emp Id")]
        public short EmployeeId { get; set; }
        [Display(Name = "Working Since")]
        public DateTime? WorkingSinceDate { get; set; }
        [Display(Name = "Birth Date")]
        public DateTime? BirthDate { get; set; }
        [Display(Name = "CNIC #")]
        public string CNICNumber { get; set; }
        [Display(Name = "NTN")]
        public string NTN { get; set; }
        [Display(Name = "Religion")]
        public string Religion { get; set; }
        [Display(Name = "Cell #")]
        public string CellNumber { get; set; }
        [Display(Name = "Phone #")]
        public string PhoneNumber { get; set; }
        [Display(Name = "Gender")]
        public short? GenderId { get; set; }
        [Display(Name = "Marital Status")]
        public short? MaritalStatusId { get; set; }       
        [Display(Name = "Permanent Address")]
        public string PermanentAddress { get; set; }
        [Display(Name = "Residential Address")]
        public string ResidentialAddress { get; set; }
        [Display(Name = "Qualification")]
        public short? QualificationId { get; set; }
        [Display(Name = "Payment Mode")]
        public short? PaymentModeId { get; set; }
        [Display(Name = "Email")]
        public string Email { get; set; }
        [Display(Name = "Nationality")]
        public string Nationality { get; set; }
        [Display(Name = "SESSI")]
        public string SESSI { get; set; }
        [Display(Name = "Is SS Member")]
        public bool IsSSMemeber { get; set; }
        [Display(Name = "EOBI")]
        public string EOBI { get; set; }
        [Display(Name = "ESS")]
        public string ESS { get; set; }
        [Display(Name = "ESS")]
        public string OldESS { get; set; }
      
        [Display(Name = "Bank Company")]
        public short? CompanyBankId { get; set; }
        [Display(Name = "Account #")]
        public string BankAccountNo { get; set; }
        [Display(Name = "Bank Detail")]
        public string BankDetail { get; set; }
        [Display(Name = "CNIC Family #")]
        public string FamilyNumber { get; set; }
      
        #endregion

        #region constructor
        public EmpDetail()
        {
            var myDate = DateTime.Now;
            BirthDate = myDate.AddYears(-18);

        }
        #endregion

        #region internal methods
        internal static EmpDetail Get(short _empId)
        {
            try
            {
                using (DbCommand dbCommandDetail = db.GetStoredProcCommand("getEmpDetailByCode"))
                {
                    db.AddInParameter(dbCommandDetail, "EmployeeId", SqlDbType.SmallInt, _empId);
                    using (DataSet ds = db.ExecuteDataSet(dbCommandDetail))
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            EmpDetail _cn = new EmpDetail();
                            DataRow dr = ds.Tables[0].Rows[0];
                            _cn.EmployeeId = _empId;      
                            _cn.BirthDate = Convert.ToDateTime(dr["BirthDate"]);
                            _cn.CNICNumber = dr["CNICNumber"].ToString();
                           
                            _cn.NTN = dr["NTN"].ToString();
                            _cn.Religion = dr["Religion"].ToString();
                            _cn.CellNumber = dr["CellNumber"].ToString();
                            _cn.PhoneNumber = dr["PhoneNumber"].ToString();      
                            _cn.GenderId = Convert.ToInt16(dr["GenderId"]); 

                            _cn.MaritalStatusId =Convert.ToInt16(dr["MaritalStatusId"]);
                            _cn.PermanentAddress = dr["PermanentAddress"].ToString();
                            _cn.ResidentialAddress = dr["ResidentialAddress"].ToString();
                            _cn.QualificationId = Convert.ToInt16(dr["Qualification"]);
                            _cn.WorkingSinceDate = Convert.ToDateTime(dr["WorkingSince"]);
                            if (dr["PaymentModeId"] != DBNull.Value)
                            _cn.PaymentModeId = Convert.ToInt16(dr["PaymentModeId"]);

                            if (dr["CompanyBankId"] != DBNull.Value)
                                _cn.CompanyBankId = Convert.ToInt16(dr["CompanyBankId"]);
                            _cn.BankAccountNo = dr["BankAccountNumber"].ToString();
                            _cn.BankDetail = dr["BankDetail"].ToString();
                            _cn.FamilyNumber = dr["FamilyNumber"].ToString();

                            _cn.Email = dr["EmailAddress"].ToString();
                            _cn.Nationality = dr["Nationality"].ToString();
                            _cn.SESSI = dr["SocialSecurityNumber"].ToString();
                            _cn.IsSSMemeber = Convert.ToBoolean(dr["SSMember"]);
                            _cn.EOBI = dr["EOBINumber"].ToString();
                            _cn.ESS = dr["ESSNumber"].ToString();
                            _cn.OldESS = _cn.ESS;

                            return _cn;
                        }
                        else
                            return null;
                    }
                }
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, EmpDetail _emp, string _userId, DbTransaction _transaction)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeDetail"))
                {
                    dbCommand.Transaction = _transaction;
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                    db.AddInParameter(dbCommand, "BirthDate", SqlDbType.DateTime, _emp.BirthDate);
                    db.AddInParameter(dbCommand, "CNICNumber", SqlDbType.VarChar, _emp.CNICNumber);
                    db.AddInParameter(dbCommand, "NTN", SqlDbType.VarChar, _emp.NTN);
                    db.AddInParameter(dbCommand, "Religion", SqlDbType.VarChar, _emp.Religion);
                    db.AddInParameter(dbCommand, "Nationality", SqlDbType.VarChar, _emp.Nationality);
                    db.AddInParameter(dbCommand, "CellNumber", SqlDbType.VarChar, _emp.CellNumber);
                    db.AddInParameter(dbCommand, "PhoneNumber", SqlDbType.VarChar, _emp.PhoneNumber);
                    db.AddInParameter(dbCommand, "GenderId", SqlDbType.SmallInt, _emp.GenderId);
                    db.AddInParameter(dbCommand, "MaritalStatusId", SqlDbType.SmallInt, _emp.MaritalStatusId);
                    db.AddInParameter(dbCommand, "PermanentAddress", SqlDbType.VarChar, _emp.PermanentAddress);
                    db.AddInParameter(dbCommand, "ResidentialAddress", SqlDbType.VarChar, _emp.ResidentialAddress);
                    db.AddInParameter(dbCommand, "FamilyNumber", SqlDbType.VarChar, _emp.FamilyNumber);
                    db.AddInParameter(dbCommand, "QualificationId", SqlDbType.SmallInt, _emp.QualificationId);
                    db.AddInParameter(dbCommand, "PaymentModeId", SqlDbType.SmallInt, _emp.PaymentModeId);
                    db.AddInParameter(dbCommand, "EmailAddress", SqlDbType.SmallInt, _emp.Email);
                    db.AddInParameter(dbCommand, "SESSI", SqlDbType.VarChar, _emp.SESSI);
                    db.AddInParameter(dbCommand, "ESS", SqlDbType.VarChar, _emp.ESS);
                    db.AddInParameter(dbCommand, "EOBI", SqlDbType.VarChar, _emp.EOBI);
                    db.AddInParameter(dbCommand, "SSMember", SqlDbType.Bit, _emp.IsSSMemeber);
                    db.AddInParameter(dbCommand, "CompanyBankId", SqlDbType.SmallInt, _emp.CompanyBankId);
                    db.AddInParameter(dbCommand, "BankAccountNumber", SqlDbType.VarChar, _emp.BankAccountNo);
                    db.AddInParameter(dbCommand, "WorkingSinceDate", SqlDbType.DateTime, _emp.WorkingSinceDate);
                    db.AddInParameter(dbCommand, "BankDetail", SqlDbType.VarChar, _emp.BankDetail);

                    db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand, _transaction);
                    
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
    }
}