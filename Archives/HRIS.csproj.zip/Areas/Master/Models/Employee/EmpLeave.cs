﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class EmpLeave : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Leave")]
        public short? LeaveId { get; set; }
        [Display(Name = "Allowed Days")]
        public short? AllowedDays { get; set; }
        [Display(Name = "Due Date")]
        public DateTime? DueDate { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }
        #endregion

        #region constructor
        public EmpLeave()
        {
            DetailId = 0;
            Status = "Added";
        }

        public EmpLeave(int _detailId, short _leaveId, short _allowedDays,
            DateTime _dueDate, string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            LeaveId = _leaveId;
            AllowedDays = _allowedDays;
            DueDate = _dueDate;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<EmpLeave> Get(short _empid)
        {
            try
            {
                List<EmpLeave> lstED = new List<EmpLeave>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getEmployeeLeaveDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empid);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstED.Add(new EmpLeave(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["LeaveId"]),
                                     Convert.ToInt16(dr["AllowedDays"]),
                                    Convert.ToDateTime(dr["DueDate"])));
                            }
                        }
                    }
                }
                return lstED;
            }
            catch (Exception)
            { throw; }

        }

        internal static bool Save(short _empid, List<EmpLeave> _details, List<EmpLeave> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (EmpLeave eld in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveEmployeeLeaveDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empid);
                        db.AddInParameter(dbCommand, "LeaveId", SqlDbType.TinyInt, eld.LeaveId);
                        db.AddInParameter(dbCommand, "AllowedDays", SqlDbType.TinyInt, eld.AllowedDays);
                        db.AddInParameter(dbCommand, "DueDate", SqlDbType.SmallDateTime, eld.DueDate);

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            eld.Status == "Added" ? "I" : (
                            eld.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<EmpLeave> getChanges(List<EmpLeave> _details,
         List<EmpLeave> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<EmpLeave> editedItems = (IEnumerable<EmpLeave>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<EmpLeave>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}