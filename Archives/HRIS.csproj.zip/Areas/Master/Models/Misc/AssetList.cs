﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class AssetList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short AssetId { get; set; }
        public string AssetName { get; set; }

        #endregion

        #region constructor
        public AssetList()
        {
        }

        public AssetList(short _AssetId, string _AssetName)
        {
            AssetId = _AssetId;
            AssetName = _AssetName;

        }
        #endregion

        #region internal methods
        internal static List<AssetList> Get()
        {
            return getAssets();
        }

        internal static DataTable GetDT()
        {
            return AgilityHelper.ListToDataTable(getAssets());
        }
        #endregion

        #region private methods
        private static List<AssetList> getAssets()
        {
            List<AssetList> lstAsset = new List<AssetList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getAssetList"))
            {
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstAsset.Add(new AssetList(
                             Convert.ToInt16(dr["AssetId"]),
                                dr["AssetName"].ToString()));
                        }
                    }
                }
            }
            return lstAsset;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}