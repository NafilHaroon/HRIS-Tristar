﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class BranchList : IDisposable
    {
                #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         public string BranchCode { get; set; }
         public string BranchName { get; set; }
         
        #endregion

        #region constructor
        public BranchList()
        {
        }

        public BranchList(string _BranchCode, string _BranchName)
        {           
                BranchCode = _BranchCode;
                BranchName = _BranchName;
           
        }
        #endregion


        #region internal methods
        internal static List<BranchList> Get(bool _activeOnly, string _userid)
        {
            return getBranches(_activeOnly, _userid);
        }

        internal static DataTable GetDT(bool _activeOnly, string _userid)
        {
            return AgilityHelper.ListToDataTable(getBranches(_activeOnly, _userid));
        }
        #endregion

        #region private methods
        private static List<BranchList> getBranches(bool _activeOnly, string _userId = null)
        {
            List<BranchList> lstBranch = new List<BranchList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getBranchList"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _activeOnly);
                if (_userId != null)
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstBranch.Add(new BranchList(
                                dr["BranchCode"].ToString(),
                                dr["BranchName"].ToString()));
                        }
                    }
                }
            }
            return lstBranch;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}