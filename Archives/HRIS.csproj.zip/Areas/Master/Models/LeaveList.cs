﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class LeaveList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Leave Id")]
        public short LeaveId { get; set; }
        [DataMember(Order = 1)]
        [Display(Name = "Leave Name")]
        public string LeaveName { get; set; }
        [DataMember(Order = 2)]
        public bool IsActive { get; set; }
        #endregion

        #region constructor
        public LeaveList()
        {
        }

        public LeaveList(short _LeaveId, string _LeaveName, bool _isActive = true)
        {
            LeaveId = _LeaveId;
            LeaveName = _LeaveName;
            IsActive = _isActive;

        }
        #endregion

        #region internal methods
        internal static List<LeaveList> Get(bool _isActive = true)
        {
            return getLeaves(_isActive);
        }

        internal static DataTable GetDT(bool _isActive = true)
        {
            return AgilityHelper.ListToDataTable(getLeaves(_isActive));
        }
        #endregion

        #region private methods
        private static List<LeaveList> getLeaves(bool _isActive)
        {
            List<LeaveList> lstCompany = new List<LeaveList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getLeaveList"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _isActive);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstCompany.Add(new LeaveList(
                               Convert.ToInt16(dr["LeaveId"]),
                                dr["LeaveName"].ToString(),
                                 Convert.ToBoolean(dr["IsActive"])));
                        }
                    }
                }
            }
            return lstCompany;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}