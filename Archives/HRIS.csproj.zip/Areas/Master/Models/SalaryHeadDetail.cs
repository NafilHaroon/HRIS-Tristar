﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;


namespace HRIS.Areas.Master.Models
{
    public class SalaryHeadDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Head Id")]
        public short HeadId { get; set; }
        [Display(Name = "Employee Type")]
        public short? EmployeeTypeId { get; set; }
         [Display(Name = "S21 Positive Account")]
        public string S21PositiveAccount { get; set; }
        [Display(Name = "S21 Negative Account")]
        public string S21NegativeAccount { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }
       

        #endregion

        #region constructor
        public SalaryHeadDetail()
        {
            DetailId = 1;
            Status = "Added";
        }
        public SalaryHeadDetail(int _detailId, short _EmployeeTypeId, string _S21PositiveAccount, string _S21NegativeAccount,
            string  _itemState = "UnChanged")
        {
            
            DetailId = _detailId;
            EmployeeTypeId = _EmployeeTypeId;
            S21PositiveAccount = _S21PositiveAccount;
            S21NegativeAccount = _S21NegativeAccount;
            Status = _itemState;
        }
        #endregion

        #region internal methods

        internal static List<SalaryHeadDetail> Get(short _HeadId)
        {
            try
            {
                List<SalaryHeadDetail> lstATD = new List<SalaryHeadDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getSalaryHeadDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "HeadId", SqlDbType.SmallInt, _HeadId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                           
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstATD.Add(new SalaryHeadDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["EmployeeTypeId"]),
                                         dr["S21PositiveAccount"].ToString(),
                                         dr["S21NegativeAccount"].ToString()));
                            }
                        }
                    }                  
                }
                return lstATD;
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Save(short _HeadId, List<SalaryHeadDetail> _details, List<SalaryHeadDetail> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (SalaryHeadDetail ATD in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveSalaryHeadDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, ATD.DetailId);
                        db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, _HeadId);
                        db.AddInParameter(dbCommand, "EmployeeTypeId", SqlDbType.SmallInt, ATD.EmployeeTypeId);
                        db.AddInParameter(dbCommand, "S21PositiveAccount", SqlDbType.VarChar, ATD.S21PositiveAccount);
                        db.AddInParameter(dbCommand, "S21NegativeAccount", SqlDbType.VarChar, ATD.S21NegativeAccount);

                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            ATD.Status == "Added" ? "I" : (
                            ATD.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
       
      
        #endregion

        #region private methods
        private static IEnumerable<SalaryHeadDetail> getChanges(List<SalaryHeadDetail> _details,
         List<SalaryHeadDetail> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<SalaryHeadDetail> editedItems = (IEnumerable<SalaryHeadDetail>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<SalaryHeadDetail>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}