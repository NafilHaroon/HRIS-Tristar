﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Master.Models
{
    public class AllocationTemplateDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Template Id")]
        public short TemplateId { get; set; }
        [Display(Name = "Division")]
        public short? DivisionId { get; set; }
        [Range(0, 100)]
        [Display(Name = "Percentage")]
        public double Percentage { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }


        #endregion

        #region constructor
        public AllocationTemplateDetail()
        {
            DetailId = 1;
            Percentage = 0;
            Status = "Added";
        }
        public AllocationTemplateDetail(int _detailId, short _DivisionId, double _Percentage,
            string _itemState = "UnChanged")
        {

            DetailId = _detailId;
            DivisionId = _DivisionId;
            Percentage = _Percentage;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<AllocationTemplateDetail> Get(short _templateid)
        {
            try
            {
                List<AllocationTemplateDetail> lstATD = new List<AllocationTemplateDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getAllocationTemplateDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "TemplateId", SqlDbType.SmallInt, _templateid);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstATD.Add(new AllocationTemplateDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["DivisionId"]),
                                         Convert.ToDouble(dr["Percentage"])));
                            }
                        }
                    }
                }
                return lstATD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _templateid, List<AllocationTemplateDetail> _details, List<AllocationTemplateDetail> _originalDetails,
            string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (AllocationTemplateDetail ATD in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveAllocationTemplateDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.Int, ATD.DetailId);
                        db.AddInParameter(dbCommand, "TemplateId", SqlDbType.SmallInt, _templateid);
                        db.AddInParameter(dbCommand, "DivisionId", SqlDbType.TinyInt, ATD.DivisionId);
                        db.AddInParameter(dbCommand, "Percentage", SqlDbType.Float, ATD.Percentage);


                        db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            ATD.Status == "Added" ? "I" : (
                            ATD.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<AllocationTemplateDetail> getChanges(List<AllocationTemplateDetail> _details,
         List<AllocationTemplateDetail> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<AllocationTemplateDetail> editedItems = (IEnumerable<AllocationTemplateDetail>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<AllocationTemplateDetail>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}