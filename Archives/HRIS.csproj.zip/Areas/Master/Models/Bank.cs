﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class Bank : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Bank Id")]
        public short BankId { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Bank Name")]
        public string BankName { get; set; }
        [Display(Name = "Address")]
        public string Address { get; set; }
        [Display(Name = "Account #")]
        public string AccountNumber { get; set; }
        [Display(Name = "Contact Person")]
        public string ContactPerson { get; set; }
        [Display(Name = "Salary Letter Header Text")]
        public string LetterHeader { get; set; }
        [Display(Name = "Show Employee Bank Detail in Letter")]
        public bool ShowEmpDetail { get; set; }
        public bool IsActive { get; set; }
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public Bank()
        {
            AuditTrail = new Footer();
            IsActive = true;
        }
        #endregion

        #region internal methods
        internal static Bank Get(short _bankId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetBankByCode"))
            {
                db.AddInParameter(dbCommand, "BankId", SqlDbType.SmallInt, _bankId);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (Bank _bnk = new Bank())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _bnk.BankId = _bankId;
                            _bnk.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                            _bnk.BankName = dr["BankName"].ToString();
                            _bnk.Address = dr["Address"].ToString();
                            _bnk.AccountNumber = dr["AccountNumber"].ToString();
                            _bnk.ContactPerson = dr["ContactPerson"].ToString();
                            _bnk.LetterHeader = dr["LetterHeader"].ToString();
                            _bnk.ShowEmpDetail = Convert.ToBoolean(dr["ShowEmployeeBankDetail"]);
                            _bnk.IsActive = Convert.ToBoolean(dr["IsActive"]);
                            _bnk.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _bnk.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _bnk.AuditTrail.UpdatedBy = dr["UpdatedBy"].ToString();
                            if (dr["UpdatedOn"] != DBNull.Value)
                                _bnk.AuditTrail.UpdatedOn = Convert.ToDateTime(dr["UpdatedOn"]);
                            return _bnk;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(Bank _bnk, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveBank"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "BankId", SqlDbType.TinyInt, _bnk.BankId);
                    db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _bnk.CompanyId);
                    db.AddInParameter(dbCommand, "BankName", SqlDbType.VarChar, _bnk.BankName);
                    db.AddInParameter(dbCommand, "Address", SqlDbType.VarChar, _bnk.Address);
                    db.AddInParameter(dbCommand, "AccountNumber", SqlDbType.VarChar, _bnk.AccountNumber);
                    db.AddInParameter(dbCommand, "ContactPerson", SqlDbType.VarChar, _bnk.ContactPerson);
                    db.AddInParameter(dbCommand, "LetterHeader", SqlDbType.VarChar, _bnk.LetterHeader);
                    db.AddInParameter(dbCommand, "ShowEmpDetail", SqlDbType.Bit, _bnk.ShowEmpDetail);
                    db.AddInParameter(dbCommand, "IsActive", SqlDbType.Bit, _bnk.IsActive);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.AddInParameter(dbCommand, "UpdatedOn", SqlDbType.DateTime, _bnk.AuditTrail.UpdatedOn);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}
