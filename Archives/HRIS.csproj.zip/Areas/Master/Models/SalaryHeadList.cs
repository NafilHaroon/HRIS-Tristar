﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Master.Models
{
    public class SalaryHeadList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [DataMember(Order = 0)]
        [Display(Name = "Head Id")]
        public short HeadId { get; set; }
        [DataMember(Order = 0)]
        [Display(Name = "Head Name")]
        public string HeadName { get; set; }
        [DataMember(Order = 3)]
        public bool IsActive { get; set; }
        [Browsable(false)]
        public bool AbsentDeduction { get; set; }
        [Browsable(false)]
        public short Symbol { get; set; }

        #endregion

        #region constructor
        public SalaryHeadList()
        {
        }

        public SalaryHeadList(short _HeadId, string _HeadName, bool _isActive, bool _AbsentDeduction, short _Symbol)
        {
            HeadId = _HeadId;
            HeadName = _HeadName;
            IsActive = _isActive;
            AbsentDeduction = _AbsentDeduction;
            Symbol = _Symbol;

        }
        #endregion

        #region internal methods
        internal static List<SalaryHeadList> Get(bool _isActive, short _headTypeId)
        {
            return getSalaryHeads(_isActive, _headTypeId);
        }

        internal static DataTable GetDT(bool _isActive, short _headTypeId)
        {
            return AgilityHelper.ListToDataTable(getSalaryHeads(_isActive, _headTypeId));
        }
        #endregion

        #region private methods
        private static List<SalaryHeadList> getSalaryHeads(bool _isActive, short _headTypeId)
        {
            List<SalaryHeadList> lstSalaryHead = new List<SalaryHeadList>();
            using (DbCommand dbCommand = db.GetStoredProcCommand("getSalaryHeadList"))
            {
                db.AddInParameter(dbCommand, "ActiveOnly", SqlDbType.Bit, _isActive);
                db.AddInParameter(dbCommand, "HeadTypeId", SqlDbType.TinyInt, _headTypeId);
                using (DataTable dt = db.ExecuteDataSet(dbCommand).Tables[0])
                {
                    if (dt != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            lstSalaryHead.Add(new SalaryHeadList(
                              Convert.ToInt16(dr["HeadId"]),
                                dr["HeadName"].ToString(),
                                 Convert.ToBoolean(dr["IsActive"]),
                                 Convert.ToBoolean(dr["AbsentDeduction"]),
                                 Convert.ToInt16(dr["Symbol"])));
                        }
                    }
                }
            }
            return lstSalaryHead;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}