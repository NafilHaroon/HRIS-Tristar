﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Master.Models
{
    public class UserBranch : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public short SerialNo { get; set; }
        public short? UserBranchId { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }
        public bool Selected { get; set; }
        #endregion

        #region Constructors
        public UserBranch()
        {
            Selected = false;
        }

        internal UserBranch(short _serialNo, object _userBranchId, string _branchCode, string _branchName, bool _selected)
        {
            SerialNo = _serialNo;
            if (_userBranchId != DBNull.Value)
                UserBranchId = Convert.ToInt16(_userBranchId);
            BranchCode = _branchCode;
            BranchName = _branchName;
            Selected = _selected;
        }
        #endregion

        #region internal methods
        internal static List<UserBranch> getBranchesByUserId(string _userId)
        {
            List<UserBranch> lstBranch = new List<UserBranch>();
            try
            {
                using (DbCommand dbCommandDetail = db.GetStoredProcCommand("GetUserBranchesByUserId"))
                {
                    db.AddInParameter(dbCommandDetail, "UserId", SqlDbType.VarChar, _userId);
                    using (DataSet ds = db.ExecuteDataSet(dbCommandDetail))
                    {
                        if (ds.Tables.Count > 0)
                        {
                            short _serialNo = 1;
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstBranch.Add(new UserBranch(
                                    _serialNo++,
                                    dr["UserBranchId"],
                                    dr["BranchCode"].ToString(),
                                    dr["BranchName"].ToString(),
                                    Convert.ToBoolean(dr["Selected"])));
                            }
                        }
                    }
                }
                return lstBranch;
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion
        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}
