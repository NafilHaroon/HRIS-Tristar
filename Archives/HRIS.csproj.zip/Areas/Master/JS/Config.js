﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
       
    });
});




function setDropDown(formMode) {
    if (formMode == "Recall") {
        document.getElementById("ddADeduc").disabled = false;
        document.getElementById("ddADDeduc").disabled = false;
    }
    else {
        document.getElementById("ddADeduc").disabled = true;
        document.getElementById("ddADDeduc").disabled = true;
    }
}


var app = angular.module('HRIS', []);

app.controller('ConfigController', function ($scope, $http, $window) {


    $scope.load = function () {
        
        $http({
            method: "POST",
            url: "/Config/LoadData"
        }).success(function (result) {
            $scope.Config = result.data;           
        }).catch(function (result) {

        });
        LoadDropDown();
    };


    $scope.savedata = function () {
        $http({
            method: "POST",
            url: "/Config/Save",
            //data: $scope.Bank,
            data: $scope.Config
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Config = result.data;
               
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                $scope.Config = {};
            }
           // setFormControls(result.Session);
            //$scope.Employee = null;
            //setFormControls(result.Session);
            // alert(result.Message);
        }).error(function (result) {

            //setFormControls(result.Session);
             alert(result.Message);
            //.error(function (res) {
            //alert(res);
        });
    }





    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/Bank/Undo"
        }).success(function (result) {
            $scope.Bank = {};
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/Config/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }


    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/Config/Recall"
        }).success(function (result) {
            setFormControls("Recall");
            setDropDown("Recall");
        }).catch(function (result) {

        });
    }

    function LoadDropDown()
    {
        $http.get('/Config/GetLoan').then(function (d) {
            $scope.Loanlist = d.data;
        }, function () {
            alert('failed');
        });


        $http.get('/Config/GetAdvance').then(function (d) {
            $scope.Advancelist = d.data;
        }, function () {
            alert('failed');
        });



        $http.get('/Config/GetAbsent').then(function (d) {
            $scope.Absentlist = d.data;
        }, function () {
            alert('failed');
        });
    }
   
});