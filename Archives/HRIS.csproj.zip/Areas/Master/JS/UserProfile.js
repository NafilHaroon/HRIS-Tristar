﻿$.ajaxSetup({ cache: false });
$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#tblOption').focus();
    });

    $("#UserRights").tabs({
        collapsible: false
    });
});




var app = angular.module('HRIS', []);

app.controller('UserProfileController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtUId').value;
        if (id > 0)
            $scope.GetData(id);;

    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/UserProfile/Save",
            data: $scope.UserProfile
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.UserProfile = result.data;
                
            }
            else {
                alert(result.Message);
                $scope.UserProfile = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {

            setFormControls(result.Session);
             alert(result.Message);
        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/UserProfile/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.UserProfile = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                
                $scope.UserProfile = result.data;
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/UserProfile/Undo"
        }).success(function (result) {
            $scope.errors = [];
            $scope.UserProfile = {};
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/UserProfile/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/UserProfile/Add"
        }).success(function (result) {
            $scope.errors = [];
            $scope.UserProfile = {};
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/UserProfile/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    function ConvertDate() {       

        $scope.UserProfile.AuditTrail.CreatedOn = formattingDateTime($scope.UserProfile.AuditTrail.CreatedOn);
        if ($scope.UserProfile.AuditTrail.UpdatedOn != null) {
            $scope.UserProfile.AuditTrail.UpdatedOn = formattingDateTime($scope.UserProfile.AuditTrail.UpdatedOn);
        }
    }
});