﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});


var app = angular.module('HRIS', []);

app.controller('SalaryHeadController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtHId').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();

    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/SalaryHead/Save",
            data: $scope.SalaryHead
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.SalaryHead = result.data;
               
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                $scope.SalaryHead = {};
            }
            setFormControls(result.Session);
            ConvertDate();
            $scope.Clear();
        }).error(function (result) {
            alert(result);
        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/SalaryHead/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.SalaryHead = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.SalaryHead = result.data;              

            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/SalaryHead/Undo"
        }).success(function (result) {
            $scope.SalaryHead = {};
            $scope.errors = [];
            setFormControls(result.Session);
            $scope.Clear();
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/SalaryHead/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/SalaryHead/Add"
        }).success(function (result) {
            $scope.SalaryHead = {};
            $scope.SalaryHead = result.data;
            setFormControls(result.Session);
            ConvertDate();
            $scope.Clear();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/SalaryHead/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    $scope.AddSH = function () {

        //Add the new item to the Array.
        var ET = document.getElementById('EmployeeTypeId').value;
        var PA = document.getElementById('S21PositiveAccount').value;
        var NA = document.getElementById('S21NegativeAccount').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;
        PA=parseInt(PA);
        NA=parseInt(NA);

        if (ET != "" && PA > 0 && NA>0) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.SalaryHead.Details.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;
            if (Index != "")
                $scope.SalaryHead.Details.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.EmployeeTypeId = ET;
            ma.S21PositiveAccount = PA;
            ma.S21NegativeAccount = NA;
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.SalaryHead.Details.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = detailid + 1;
            //}
            $scope.SalaryHead.Details.push(ma);
            $scope.Clear();
            ma ={};
        }
        else
        {
            alert("Please Selct Valid Employee Type && S21 Positive and Negative Account should be greater then 6 character");
        }
      
    }
    $scope.Clear = function () {
        //Clear the TextBoxes.
        document.getElementById('EmployeeTypeId').value = "";
        document.getElementById('S21PositiveAccount').value = 0;
        document.getElementById('S21NegativeAccount').value = 0;
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
    }

    $scope.EditSH = function (m, index) {

        document.getElementById('EmployeeTypeId').value = m.EmployeeTypeId;
        document.getElementById('S21PositiveAccount').value = m.S21PositiveAccount;
        document.getElementById('S21NegativeAccount').value = m.S21NegativeAccount;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }

    $scope.RemoveSH = function (index) {
        //Find the record using Index from Array.
       // var CC = $scope.SalaryHead.Details[index].DetailId;
        if ($window.confirm("Do you want to delete: " )) {
            //Remove the item from Array using Index.
            $scope.SalaryHead.Details.splice(index, 1);
        }
    }

    //$scope.toggleEdit = function (m) {
    //    m.showEdit = m.showEdit ? false : true;
    //}


    ///Salary Head Detail///
    //$scope.AddSH= function () {
    //    //Add the new item to the Array.
    //    if ($scope.EmployeeTypeId != undefined && $scope.EmployeeTypeId != "" && $scope.S21PositiveAccount != undefined && $scope.S21PositiveAccount != ""
    //        && $scope.S21NegativeAccount != undefined && $scope.S21NegativeAccount != "") {
    //        var detailid;
    //        var SH = {};
    //        Math.max.apply(Math, $scope.SalaryHead.Details.map(function (ques) { detailid = ques.DetailId; }))
    //        detailid = (detailid === undefined) ? 0 : detailid;

    //        SH.EmployeeTypeId = $scope.EmployeeTypeId;
    //        SH.S21PositiveAccount = $scope.S21PositiveAccount;
    //        SH.S21NegativeAccount = $scope.S21NegativeAccount;
    //        SH.DetailId = detailid += 1;
    //        SH.showEdit = false;
    //        SH.status = "Added";
    //        $scope.SalaryHead.Details.push(SH);

    //        //Clear the TextBoxes.
    //        $scope.EmployeeTypeId = "";
    //        $scope.S21PositiveAccount = "";
    //        $scope.S21NegativeAccount = "";
    //    }


    //}
    //$scope.EditSH = function (m, index) {
    //    //Add the new item to the Array.
    //    if (m.EmployeeTypeId != "" && m.S21PositiveAccount != "" && m.S21NegativeAccount != "") {
    //        var SH = {};
    //        $scope.SalaryHead.Details.splice(index, 1);
    //        SH.EmployeeTypeId = m.EmployeeTypeId;
    //        SH.S21PositiveAccount = m.S21PositiveAccount;
    //        SH.S21NegativeAccount = m.S21NegativeAccount;
    //        SH.DetailId = m.DetailId;
    //        SH.showEdit = false;
    //        if (SH.status == "UnChanged") {
    //            SH.status = "Edited";
    //        }
    //        else {
    //            SH.status = "Added";
    //        }
    //        $scope.SalaryHead.Details.push(SH);
    //    }

    //}

    ///Salary Head Detail///

    function LoadDropDown()
    {
        $http.get('/SalaryHead/GetHeadType').then(function (d) {
            $scope.HeadTypelist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/SalaryHead/GetEmployeeType').then(function (d) {
            $scope.EmployeeTypelist = d.data;
        }, function () {
            alert('failed');
        });
    }


    function ConvertDate() {

        $scope.SalaryHead.AuditTrail.CreatedOn = formattingDateTime($scope.SalaryHead.AuditTrail.CreatedOn);
        if ($scope.SalaryHead.AuditTrail.UpdatedOn != null) {
            $scope.SalaryHead.AuditTrail.UpdatedOn = formattingDateTime($scope.SalaryHead.AuditTrail.UpdatedOn);
        }
    }
});