﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});


var app = angular.module('HRIS', []);

app.controller('GradeController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtGId').value;
        if (id > 0)
            $scope.GetData(id);

    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/Grade/Save",
            data: $scope.Grade
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Grade = result.data;
               
            }
            else {
                 alert(result.Message);
                $scope.Grade = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }


    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/Grade/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.Grade = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.Grade = result.data;
               

            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/Grade/Undo"
        }).success(function (result) {
            $scope.Grade = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/Grade/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/Grade/Add"
        }).success(function (result) {
            $scope.Grade = {};
            $scope.Grade = result.data;
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/Grade/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    function ConvertDate() {

        $scope.Grade.AuditTrail.CreatedOn = formattingDateTime($scope.Grade.AuditTrail.CreatedOn);
        if ($scope.Grade.AuditTrail.UpdatedOn != null) {
            $scope.Grade.AuditTrail.UpdatedOn = formattingDateTime($scope.Grade.AuditTrail.UpdatedOn);
        }
    }

   
});