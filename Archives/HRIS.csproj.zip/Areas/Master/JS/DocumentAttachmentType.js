﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});




var app = angular.module('HRIS', []);

app.controller('DocumentAttachmentTypeController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtAId').value;
        if (id > 0)
            $scope.GetData(id);

    };

    $scope.savedata = function () {
        $http({
            method: "POST",
            url: "/DocumentAttachmentType/Save",           
            data: $scope.DocumentAttachmentType
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.DocumentAttachmentType = result.data;
               
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                $scope.DocumentAttachmentType = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }


    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/DocumentAttachmentType/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.DocumentAttachmentType = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.DocumentAttachmentType = result.data;              

            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/DocumentAttachmentType/Undo"
        }).success(function (result) {
            $scope.DocumentAttachmentType = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/DocumentAttachmentType/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/DocumentAttachmentType/Add"
        }).success(function (result) {
            $scope.DocumentAttachmentType = {};
            $scope.DocumentAttachmentType = result.data;
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/DocumentAttachmentType/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    function ConvertDate() {

        $scope.DocumentAttachmentType.AuditTrail.CreatedOn = formattingDateTime($scope.DocumentAttachmentType.AuditTrail.CreatedOn);
        if ($scope.DocumentAttachmentType.AuditTrail.UpdatedOn != null) {
            $scope.DocumentAttachmentType.AuditTrail.UpdatedOn = formattingDateTime($scope.DocumentAttachmentType.AuditTrail.UpdatedOn);
        }
    }

   
});