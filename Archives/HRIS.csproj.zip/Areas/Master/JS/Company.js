﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});



function ShowDefaultImage() {
    document.getElementById("DefaultImg").style.display = "inline-block";
    document.getElementById("photo-id").style.display = "none";
};

function ShowProfileImage() {
    document.getElementById("photo-id").style.display = "inline-block";
    document.getElementById("DefaultImg").style.display = "none";
};

var app = angular.module('HRIS', []);

app.controller('CompanyController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtCId').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
    };

    $scope.readURL = function (input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {

                //Sets the Old Image to new New Image
                $('#photo-id').attr('src', e.target.result);

                //Create a canvas and draw image on Client Side to get the byte[] equivalent
                var canvas = document.createElement("canvas");
                var imageElement = document.createElement("img");

                imageElement.setAttribute('src', e.target.result);
                canvas.width = imageElement.width;
                canvas.height = imageElement.height;
                var context = canvas.getContext("2d");
                context.drawImage(imageElement, 0, 0);
                var base64Image = canvas.toDataURL("image/jpeg");

                //Removes the Data Type Prefix 
                //And set the view model to the new value
                //
                $scope.Company.CompanyLogo = base64Image.replace(/data:image\/jpeg;base64,/g, '');
                ShowProfileImage();

            }

            //Renders Image on Page
            //document.getElementById("#photo-id").value = null;
            reader.readAsDataURL(input.files[0]);
        }
    };

   

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/Company/Save",
            data: $scope.Company
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Company = result.data;               
            }
            else {
                 alert(result.Message);
                $scope.Company = {};
            }
            setFormControls(result.Session);
            if ($scope.Company.CompanyLogo == null) {
                ShowDefaultImage();
            }
            else {
                ShowProfileImage();
            }
            ConvertDate();
        }).error(function (result) {

            setFormControls(result.Session);
             alert(result.Message);
            //.error(function (res) {
            //alert(res);
        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }


    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/Company/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.Company = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.Company = result.data;              

            }
            setFormControls(result.Session);
            ShowProfileImage();
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/Company/Undo"
        }).success(function (result) {
            $scope.Company = {};
            $scope.errors = [];
            setFormControls(result.Session);
            ShowDefaultImage();
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/Company/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/Company/Add"
        }).success(function (result) {
            $scope.Company = {};
            $scope.Company = result.data;
            setFormControls(result.Session);
            ShowDefaultImage();
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/Company/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    function LoadDropDown()
    {
        $http.get('/Company/GetPFReceivableList').then(function (d) {
            $scope.PFReceivablelist = d.data;
        }, function () {
            alert('failed');
        });

    }
   


    function ConvertDate() {

        $scope.Company.AuditTrail.CreatedOn = formattingDateTime($scope.Company.AuditTrail.CreatedOn);
        if ($scope.Company.AuditTrail.UpdatedOn != null) {
            $scope.Company.AuditTrail.UpdatedOn = formattingDateTime($scope.Company.AuditTrail.UpdatedOn);
        }
    }
   
});