﻿/// <reference path="../../Common/Views/MyForms/Search.cshtml" />
/// <reference path="../../Common/Views/MyForms/Search.cshtml" />
$(document).ready(function () {
    
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#dempstatus').focus();
    });
      
    $('#DueDate').datepicker({
        minDate: '0D',
        maxDate: '+10Y'
    });

    $('#DExpiryDate').datepicker({
        minDate: '0D',
        maxDate: '+10Y'
    });

    $('#ExpiryDate').datepicker({
        minDate: '0D',
        maxDate: '+10Y'
    });
    $('#ReminderDate').datepicker({
        minDate: '0D',
        maxDate: '+10Y'
    });
    $('#DisposalDate').datepicker({
        minDate: '0D',
        maxDate: '+10Y'
    });

    $('#IssueDate').datepicker();
    $('#DOB').datepicker({
        minDate: '-60Y',
        maxDate: '+0D',
    });
    $('#EffectiveDate').datepicker();
    //$('#DExpiryDate').datepicker();

  // $(function () {
        //$('body').on('focus', ".mydatepicker", function () {
        //    $(this).datepicker();
        //});
  //  });

    $("#tbEmp").tabs({
        collapsible: false
    });

    $("#tbSalary").tabs({
        collapsible: false
    });

    $("#dialog-delete").dialog({
        autoOpen: false,
        resizable: false,
        height: 250,
        width: 400,
        modal: true,
        class: "DeleteAlert",
        dialogClass: "DeleteAlert",
        title: "Confirm Delete Action",
        buttons: [
            {
                id: "btnDelete",
                text: "Delete",
                width: 120,
                class: "delete",
                click: function () {
                    $(this).dialog('close');
                    var employeeid = document.getElementById("txtEmployeeId").value;
                    deleteRequest(employeeid);
                }
            },
            {
                id: "btnCancel",
                text: "Go Back!",
                width: 120,
                click: function () {
                    $(this).dialog('close');
                }
            }
        ],
        open: function () {
            //this special part is just done because delete and cancel were appearing in this form for unknown reason
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').prop('disabled', false);
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(0)').prop('disabled', false);
            //end of this special part
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').focus();
        }

    });


 //$('#ContactNo')
 //   .keydown(function (e) {
 //       var key = e.which || e.charCode || e.keyCode || 0;
 //       $phone = $(this);
 //       // Auto-format- do not expose the mask as the user begins to type
 //       if (key !== 8 && key !== 9) {
 //           if ($phone.val().length === 4) {
 //               $phone.val($phone.val() + '-');
 //           }
 //       }
 //       // Allow numeric (and tab, backspace, delete) keys only
 //       return (key == 8 ||
 //   			key == 9 ||
 //   			key == 46 ||
 //   			(key >= 48 && key <= 57) ||
 //   			(key >= 96 && key <= 105));	})
 //   .bind('focus click', function () {
 //       $phone = $(this);
 //       var val = $phone.val();
 //       $phone.val('').val(val); // Ensure cursor remains at the end
 //   })
 //   .blur(function () {
 //       $phone = $(this);
 //   });

});

function ShowDefaultImage() {
    document.getElementById("DefaultImg").style.display = "inline-block";
    document.getElementById("photo-id").style.display = "none";
};

function ShowProfileImage() {
    document.getElementById("photo-id").style.display = "inline-block";
    document.getElementById("DefaultImg").style.display = "none";
};

function showSeperation() {
    var empstatus = document.getElementById("dempstatus").value;
    if (empstatus == "null")
    {
        empstatus = 1;
    }
    if (empstatus != 1 )
    {
        lblSReason.style.visibility = 'visible';
        lblSeparationDate.style.visibility = 'visible';
        divsdate.style.visibility = 'visible';
        divsep.style.visibility = 'visible';
    }
    else {
        lblSReason.style.visibility = 'hidden';
        lblSeparationDate.style.visibility = 'hidden';
        divsdate.style.visibility = 'hidden';
        divsep.style.visibility = 'hidden';
    }
}

function showSESSI() {
    var SSM = document.getElementById("chkssm").value;
    if (SSM ==true) {
        divSESSI.style.visibility = 'visible';
    }
    else {     
        divSESSI.style.visibility = 'hidden';
    }

}

function changePicture() {
    $('#fuAttachment').click();
}

var app = angular.module('HRIS', []);

app.controller('EmployeeController', function ($scope, $http, $window) {
    
    function Date ()
    {
        $('#JoiningDate').datepicker({
            onSelect: function (date) {
                $scope.Employee.JoiningDate = date;
                $scope.$apply();
            }
        });

        $('#ConfirmationDueDate').datepicker({
            onSelect: function (date) {
                $scope.Employee.ConfirmationDueDate = date;
                $scope.$apply();
            }
        });

        $('#ConfirmationDate').datepicker({
            onSelect: function (date) {
                $scope.Employee.ConfirmationDate = date;
                $scope.$apply();
            }
        });

        $('#SeparationDate').datepicker({
            onSelect: function (date) {
                $scope.Employee.SeparationDate = date;
                $scope.$apply();
            }
        });

        $('#BirthDate').datepicker({           
            minDate: '-60Y',
            maxDate: '+0D',
            showOn: "both",
            onSelect: function (date) {
                $scope.Employee.EmpDetails.BirthDate = date;
                $scope.$apply();
            }
        });

        $('#WorkingSinceDate').datepicker({
            onSelect: function (date) {
                $scope.Employee.EmpDetails.WorkingSinceDate = date;
                $scope.$apply();
            }
        });
    }

    $scope.load = function () {

        LoadDropDown();
        Date();
        var id = document.getElementById('txtEmpId').value;
        if (id !="")
            $scope.GetData(id);       
    };

    $scope.readURL = function (input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {

                //Sets the Old Image to new New Image
                $('#photo-id').attr('src', e.target.result);

                //Create a canvas and draw image on Client Side to get the byte[] equivalent
                var canvas = document.createElement("canvas");
                var imageElement = document.createElement("img");

                imageElement.setAttribute('src', e.target.result);
                canvas.width = imageElement.width;
                canvas.height = imageElement.height;
                var context = canvas.getContext("2d");
                context.drawImage(imageElement, 0, 0);
                var base64Image = canvas.toDataURL("image/jpeg");

                //Removes the Data Type Prefix 
                //And set the view model to the new value
                //
                $scope.Employee.ProfileImage = base64Image.replace(/data:image\/jpeg;base64,/g, '');
                ShowProfileImage();
            }
            //Renders Image on Page
            //document.getElementById("#photo-id").value = null;
            reader.readAsDataURL(input.files[0]);
        }
    };
    
    $scope.savedata = function () {
        $http({
            url: '/Employee/Save',
            method: 'POST',           
            data: $scope.Employee 
            //
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Employee = result.data;
            }
            else {
                alert(result.Message);
                $scope.Employee = {};
                $('#photo-id').val("");
                $('#fuAttachment').val("");
                document.getElementById("TotalSalary").innerText = "";
                document.getElementById("TotalPercentage").innerText = "";
                $scope.ClearLeave();
                $scope.ClearSM();
                $scope.ClearAsset();
                $scope.ClearFNK();
                $scope.ClearFM();
                $scope.ClearCA();
            }
            setFormControls(result.Session);
            if ($scope.Employee.image == null)
            {
                ShowDefaultImage();
            }
            else
            {
                ShowProfileImage();
            }
            ConvertDate();
        }).error(function (result) {
          
            //setFormControls(result.Session);
             alert(result);
        });
    }    

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }


    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/Employee/Get",
            data: { _keyId: res },
        }).success(function (result) {
            $scope.errors = [];
            $scope.Employee={};
            if (result.success == false)
            {
                $scope.errors = [
                   result.Message]                
            }
            else
            {                
                $scope.Employee = result.data;
                Calculate_TotalSalary();
                Calculate_TotalPercentage();
            }
            setFormControls(result.Session);
            ShowProfileImage();
            ConvertDate();
        }).catch(function (result)
        {
          
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/Employee/Undo"
        }).success(function (result) {
            $scope.Employee = {};
            $scope.errors = [];
            setFormControls(result.Session);
            ShowDefaultImage();
            $('#photo-id').val("");
            $('#fuAttachment').val("");
            document.getElementById("TotalSalary").innerText = "";
            document.getElementById("TotalPercentage").innerText = "";
            ClearLeave();
            ClearSM();
            ClearAsset();
            ClearFNK();
            ClearFM();
            ClearCA();
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/Employee/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {
        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/Employee/Add"
        }).success(function (result) {
            $scope.errors = [];
            $scope.Employee = result.data;
            ConvertDate();         
            setFormControls(result.Session);
            ShowDefaultImage();
        }).catch(function (result) {
        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/Employee/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }
    
    $scope.replaceemp = function () {
        var hiringtype = $scope.Employee.HiringType;

        if (hiringtype == 2) {
            dREmp.style.visibility = 'visible';
            lblREmp.style.visibility = 'visible';

            $http.get('/Employee/GetInActiveEmployee').then(function (d) {
                $scope.GetEmployeelist = d.data;
            }, function () {
                alert('failed');
            });
        }
        if (hiringtype == 3) {
            dREmp.style.visibility = 'visible';
            lblREmp.style.visibility = 'visible';

            $http.get('/Employee/GetEmployees').then(function (d) {
                $scope.GetEmployeelist = d.data;
            }, function () {
                alert('failed');
            });
        }
        if (hiringtype == 1) {
            dREmp.style.visibility = 'hidden';
            lblREmp.style.visibility = 'hidden';
        }

    }

    //$scope.toggleEdit = function (m) {
    //    m.showEdit = m.showEdit ? false : true;
    //}

    //Leave Detail////
    $scope.AddLeave = function () {

        //Add the new item to the Array.
        var LI = document.getElementById('LeaveId').value;
        var AD = document.getElementById('AllowedDays').value;
        var DD = document.getElementById('DueDate').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        AD = parseInt(AD);
        //Index = (Index === "") ? 0 : Index;
        DID = (DID === "") ? 0 : DID;

        if (LI != "" && AD >0 && DD != "") {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.Employee.EmpLeaveDetails.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;
            if (Index != "")
                $scope.Employee.EmpLeaveDetails.splice(Index, 1);

            ma.AllowedDays = AD;
            ma.DueDate = DD;
            ma.LeaveId = LI;
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID  <= 0) {
            //    ma.DetailId = DID;
            //    $scope.Employee.EmpLeaveDetails.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = -1;
            //}
            $scope.Employee.EmpLeaveDetails.push(ma);
            $scope.ClearLeave();
            ma = {};
        }
        else {
            alert("Please Select Valid Leave, Due Date and Allowed Days should be greater then zero. Before saving value in Grid. ");
        }
    }
    $scope.ClearLeave = function () {
        //Clear the TextBoxes.
        document.getElementById('LeaveId').value = "";
        document.getElementById('AllowedDays').value =0;
        document.getElementById('DueDate').value = "";
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
    }
    $scope.EditLeave = function (m, index) {

        document.getElementById('LeaveId').value = m.LeaveId;
        document.getElementById('AllowedDays').value = m.AllowedDays;
        document.getElementById('DueDate').value = m.DueDate;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
    $scope.RemoveLeave = function (index) {
        //Find the record using Index from Array.
        //var CC = $scope.Employee.EmpLeaveDetails[index];
        if ($window.confirm("Do you want to delete: " )) {
            //Remove the item from Array using Index.
            $scope.Employee.EmpLeaveDetails.splice(index, 1);
        }
    }

  

    $scope.AddAsset = function () {

        //Add the new item to the Array.
        var AI = document.getElementById('AssetId').value;
        var RM = document.getElementById('RegistrationNumber').value;
        var MD = document.getElementById('Model').value;
        var RD = document.getElementById('ReminderDate').value;
        var DD = document.getElementById('DisposalDate').value;
        var ID = document.getElementById('IssueDate').value;
        var BV = document.getElementById('BaseValue').value;
        var ED = document.getElementById('ExpiryDate').value;
        var LT = document.getElementById('Limit').value;
        var CN = document.getElementById('Consumable').checked;
        var AC = document.getElementById('Active').checked;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        //Index = (Index === "") ? 0 : Index;
        DID = (DID === "") ? 0 : DID;
     

        if (AI != "" && RM != "" && MD != "" && RD != "" && DD != "" && ID != ""
            && BV > 0 && ED != "" && LT > 0 ) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.Employee.EmpAssetDetails.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;

            if (Index != "")
                $scope.Employee.EmpAssetDetails.splice(Index, 1);

            ma.AssetId = AI;
            ma.RegistrationNumber = RM;
            ma.Model = MD;
            ma.IssueDate = ID;
            ma.BaseValue = parseFloat(BV).toFixed(2);
            ma.Limit = parseFloat(LT).toFixed(2);
            ma.Consumable = CN;
            ma.Active = AC;
            ma.ExpiryDate = ED;
            ma.ReminderDate = RD;
            ma.DisposalDate = DD;

            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.Employee.EmpAssetDetails.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = -1;
            //}
            $scope.Employee.EmpAssetDetails.push(ma);
            $scope.ClearAsset();
            ma = {};
        }
        else {
            alert("Please Select Valid Asset, Reg #, Model, Reminder Date, Disposal Date, Issue Date, Limit and Base Value  should be greater then zero. Before saving value in Grid. ");
        }
    }
    $scope.ClearAsset = function () {
        document.getElementById('AssetId').value = "";
        document.getElementById('RegistrationNumber').value = "";
        document.getElementById('Model').value = "";
        document.getElementById('ReminderDate').value = "";
        document.getElementById('DisposalDate').value = "";
        document.getElementById('IssueDate').value = "";
        document.getElementById('BaseValue').value = 0;
        document.getElementById('ExpiryDate').value = "";
        document.getElementById('Limit').value = 0;
        document.getElementById('Consumable').checked = false;
        document.getElementById('Active').checked = false;
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
    }
    $scope.EditAsset = function (m, index) {

        document.getElementById('AssetId').value = m.AssetId;
        document.getElementById('RegistrationNumber').value = m.RegistrationNumber;
        document.getElementById('Model').value = m.Model;
        document.getElementById('ReminderDate').value = m.ReminderDate;
        document.getElementById('DisposalDate').value = m.DisposalDate;
        document.getElementById('IssueDate').value = m.IssueDate;
        document.getElementById('BaseValue').value = m.BaseValue;
        document.getElementById('ExpiryDate').value = m.ExpiryDate;
        document.getElementById('Limit').value = m.Limit;
        document.getElementById('Consumable').checked = m.Consumable;
        document.getElementById('Active').checked = m.Active;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
    $scope.RemoveAsset = function (index) {
        //Find the record using Index from Array.
       // var CC = $scope.Employee.EmpAssetDetails[index];
        if ($window.confirm("Do you want to delete: " )) {
            //Remove the item from Array using Index.
            $scope.Employee.EmpAssetDetails.splice(index, 1);
        }
    }
    ///Asset Detail///

    ///Salary Detail///
    $scope.AddSM = function () {
        var HI = document.getElementById('HeadId').value;
        var AM = document.getElementById('Amount').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        var BasicSalaryId = document.getElementById('txtBSId').value;
        //Index = (Index === "") ? 0 : Index;
        DID = (DID === "") ? 0 : DID;
        AM=parseFloat(AM).toFixed(2);
        if (HI != ""   && AM > 0) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.Employee.EmpSalaryMonthlyDetails.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;

            if (Index != "")
                $scope.Employee.EmpSalaryMonthlyDetails.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.HeadId = HI;
            ma.Amount = AM;
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.Employee.EmpSalaryMonthlyDetails.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = -1;
            //}
            $scope.Employee.EmpSalaryMonthlyDetails.push(ma);
            if (ma.HeadId== BasicSalaryId)
            {
                UpdatePFAmount(ma.Amount);
            }
            $scope.ClearSM();
            ma = {};

            Calculate_TotalSalary();
        }
        else {
            alert("Please Select Valid Salary Head and Amount should be greater then zero. Before saving value in Grid. ");
        }
    }

    $scope.ClearSM = function () {
        document.getElementById('HeadId').value = "";
        document.getElementById('Amount').value = 0.00;
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";

    }
    $scope.EditSM = function (m, index) {
        document.getElementById('HeadId').value = m.HeadId;
        document.getElementById('Amount').value = m.Amount;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;
    }

    $scope.RemoveSM = function (index) {
        //Find the record using Index from Array.
        //var CC = $scope.Employee.EmpSalaryMonthlyDetails[index];
        if ($window.confirm("Do you want to delete: " )) {
            //Remove the item from Array using Index.
            $scope.Employee.EmpSalaryMonthlyDetails.splice(index, 1);
        }

        Calculate_TotalSalary();
    }

    function UpdatePFAmount(BasicSalaryAmount) {
        var dblBasicSalary = BasicSalaryAmount;
        var PFId = document.getElementById('txtPFId').value;
        //var BasicSalaryId = parseInt(BasicSalaryId);
        PFId = parseInt(PFId);

        var ma = {};
        var dr = $scope.Employee.EmpSalaryMonthlyDetails.filter(function (a) { return a.HeadId == PFId })[0]
        if (dr != undefined) {

            angular.forEach($scope.Employee.EmpSalaryMonthlyDetails, function (cb, index) {
                if (cb.HeadId == dr.HeadId) {
                    $scope.Employee.EmpSalaryMonthlyDetails.splice(index, 1);
                }
            });


            ma.HeadId = dr.HeadId;
            ma.Amount = parseFloat((dblBasicSalary * 0.1));
            ma.Status = dr.DetailId <= 0 ? "Added" : "Edited";
            //ma.Status = "Added";
            ma.DetailId = dr.DetailId;
            $scope.Employee.EmpSalaryMonthlyDetails.push(ma);
        }
    }

    function Calculate_TotalSalary() {
        var total = 0;
        $scope.Employee.EmpSalaryMonthlyDetails.forEach(function (element) {
            var ST1 = $scope.Headlist.filter(function (a) { return a.HeadId == element.HeadId })[0]["Symbol"]
            total = total + parseFloat(element.Amount) * ST1;
        });

        document.getElementById("TotalSalary").innerText = formatNumbers(total);
        $scope.Employee.EmpSalaryMonthlyDetails.TotalSalary = formatNumbers(total);
    }

    ///Salary Detail///

    ///Salary NonDetail///
    //$scope.AddSNM = function () {
    //    $scope.HeadId = ($scope.HeadId === undefined) ? "" : $scope.HeadId;
    //    $scope.Unit = ($scope.Unit === undefined) ? 0 : $scope.Unit;
    //    $scope.Rate = ($scope.Rate === undefined) ? 0 : $scope.Rate;
    //    $scope.Entitlement = ($scope.Entitlement === undefined) ? 0 : $scope.Entitlement;


    //    //Add the new item to the Array.
    //    if ($scope.HeadId != "" && $scope.Unit > 0 && $scope.Rate > 0 && $scope.Entitlement > 0) {
    //        var detailid;
    //        var snm = {};
    //        Math.max.apply(Math, $scope.Employee.EmpSalaryNonMonthlyDetails.map(function (ques) { detailid = ques.DetailId; }))
    //        detailid = (detailid === undefined) ? 0 : detailid;


    //        snm.HeadId = $scope.HeadId;
    //        snm.Unit = $scope.Unit;
    //        snm.Rate = $scope.Rate;
    //        snm.Entitlement = $scope.Entitlement;
    //        snm.DetailId = detailid += 1;
    //        snm.showEdit = false;
    //        snm.status = "Added";
    //        $scope.Employee.EmpSalaryNonMonthlyDetails.push(snm);

    //        //Clear the TextBoxes.
    //        $scope.HeadId = "";
    //        $scope.Unit = 0;
    //        $scope.Rate = 0;
    //        $scope.Entitlement = 0;
    //    }
    //}

    //$scope.EditSNM = function (m, index) {
    //    //Add the new item to the Array.
    //    if (m.HeadId != "" && m.Unit <= 0 && m.Rate <= 0 && m.Entitlement <= 0) {
    //        var snm = {};
    //        $scope.Employee.EmpSalaryNonMonthlyDetails.splice(index, 1);
    //        snm.HeadId = m.HeadId;
    //        snm.Unit = m.Unit;
    //        snm.Rate = m.Rate;
    //        snm.Entitlement = m.Entitlement;
    //        snm.DetailId = m.DetailId;
    //        snm.showEdit = false;

    //        if (snm.status == "UnChanged") {
    //            snm.status = "Edited";
    //        }
    //        else {
    //            snm.status = "Added";
    //        }
    //        $scope.Employee.EmpSalaryNonMonthlyDetails.push(snm);
    //    }
    //}

    //$scope.RemoveSNM = function (index) {
    //    //Find the record using Index from Array.
    //    var CC = $scope.Employee.EmpSalaryNonMonthlyDetails[index];
    //    if ($window.confirm("Do you want to delete: " + CC)) {
    //        //Remove the item from Array using Index.
    //        $scope.Employee.EmpSalaryNonMonthlyDetails.splice(index, 1);
    //    }
    //}
    ///Salary Non Detail///

    ///Family Detail///
    $scope.AddFM = function () {

        //Add the new item to the Array.
        var RL = document.getElementById('RelationId').value;
        var PN = document.getElementById('PersonName').value;
        var MP = document.getElementById('MedicalPlanId').value;
        var MC = document.getElementById('MedicalCost').value;
        var DB = document.getElementById('DOB').value;
        var ED = document.getElementById('EffectiveDate').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        //Index = (Index === "") ? 0 : Index;
        DID = (DID === "") ? 0 : DID;
        MC = parseFloat(MC).toFixed(2);

        if (RL != "" && MC > 0 && PN != "" && MC > 0 && DB != "" && ED != "") {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.Employee.EmpFamilyMemberDetails.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;
            if (Index != "")
                $scope.Employee.EmpFamilyMemberDetails.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }

            ma.RelationId = RL;
            ma.PersonName = PN;
            ma.MedicalPlanId = MP;
            ma.MedicalCost = MC;
            ma.DOB = DB;
            ma.EffectiveDate = ED;
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.Employee.EmpFamilyMemberDetails.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = detailid + 1;
            //}
            $scope.Employee.EmpFamilyMemberDetails.push(ma);
            $scope.ClearFM();
            ma = {};
        }
        else {
            alert("Please Select Valid Relation,MedicalPlan, PersonName, DOB, effective date and Medical Cost should be greater then zero. Before saving value in Grid. ");
        }

    }
    $scope.ClearFM = function () {
        document.getElementById('RelationId').value="";
        document.getElementById('PersonName').value="";
        document.getElementById('MedicalPlanId').value="";
        document.getElementById('MedicalCost').value =0.00;
        document.getElementById('DOB').value ="";
        document.getElementById('EffectiveDate').value = "";
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
        
    }
    $scope.EditFM = function (m, index) {

        document.getElementById('RelationId').value = m.RelationId;
        document.getElementById('PersonName').value = m.PersonName;
        document.getElementById('MedicalPlanId').value = m.MedicalPlanId;
        document.getElementById('MedicalCost').value = m.MedicalCost;
        document.getElementById('DOB').value = m.DOB;
        document.getElementById('EffectiveDate').value = m.EffectiveDate;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
    $scope.RemoveFM = function (index) {
        //Find the record using Index from Array.
      //  var CC = $scope.Employee.EmpFamilyMemberDetails[index];
        if ($window.confirm("Do you want to delete: " )) {
            //Remove the item from Array using Index.
            $scope.Employee.EmpFamilyMemberDetails.splice(index, 1);
        }
    }
    ///Family Detail///

    ///Family nOK Detail///
    $scope.AddFNK = function () {
       //Add the new item to the Array.
        var RL = document.getElementById('FRelationId').value;
        var NN = document.getElementById('NoKName').value;
        var NC = document.getElementById('ContactNo').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        //Index = (Index === "") ? 0 : Index;
        DID = (DID === "") ? 0 : DID;
        if (RL != "" && NN != "" && NC != "" ) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.Employee.EmpEmergencyContactDetails.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;
            if (Index != "")
                $scope.Employee.EmpEmergencyContactDetails.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.RelationId = RL;
            ma.NoKName = NN;
            ma.NoKContactNo = NC;
          
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.Employee.EmpEmergencyContactDetails.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = -1;
            //}
            $scope.Employee.EmpEmergencyContactDetails.push(ma);
            $scope.ClearFNK();
            ma = {};
        }
        else {
            alert("Please Select Valid Relation, Nok Name, Nok Contact #. Before saving value in Grid. ");
        }


    }

    $scope.ClearFNK = function () {
        document.getElementById('FRelationId').value = "";
        document.getElementById('NoKName').value = "";
        document.getElementById('ContactNo').value = "";
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";

    }
    $scope.EditFNK = function (m, index) {

        document.getElementById('FRelationId').value = m.RelationId;
        document.getElementById('NoKName').value = m.NoKName;
        document.getElementById('ContactNo').value = m.NoKContactNo;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }

    $scope.RemoveFNK = function (index) {
        //Find the record using Index from Array.
       // var CC = $scope.Employee.EmpEmergencyContactDetails[index];
        if ($window.confirm("Do you want to delete: " )) {
            //Remove the item from Array using Index.
            $scope.Employee.EmpEmergencyContactDetails.splice(index, 1);
        }
    }
    
    ///Employee Cost///
    $scope.AddCA = function () {
        var BC = document.getElementById('BranchCode').value;
        var TD = document.getElementById('TemplateId').value;
        var PR = document.getElementById('txtF').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;
        PR=parseFloat(PR).toFixed(2);
        if (BC != "" && TD != "" && PR >0) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.Employee.EmpCostAllocatioDetails.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;
            if (Index != "")
                $scope.Employee.EmpCostAllocatioDetails.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.BranchCode = BC;
            ma.TemplateId = TD;
            ma.Percentage = parseFloat(PR);

            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.Employee.EmpCostAllocatioDetails.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = -1;
            //}
            $scope.Employee.EmpCostAllocatioDetails.push(ma);
            $scope.ClearCA();
            Calculate_TotalPercentage();
            ma = {};
        }
        else {
            alert("Please Select Valid Branch, Template, and Percentage should be greater then zero. Before saving value in Grid. ");
        }



    }
    $scope.ClearCA = function () {
        document.getElementById('BranchCode').value = "";
        document.getElementById('TemplateId').value = "";
        document.getElementById('txtF').value = 0.00;
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";

    }
    $scope.EditCA = function (m, index) {

        document.getElementById('BranchCode').value = m.BranchCode;
        document.getElementById('TemplateId').value = m.TemplateId;
        document.getElementById('txtF').value = m.Percentage;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
    $scope.RemoveCA = function (index) {
        //Find the record using Index from Array.
       // var CC = $scope.Employee.EmpCostAllocatioDetails[index].DetailId;
        if ($window.confirm("Do you want to delete: ")) {
            //Remove the item from Array using Index.
            $scope.Employee.EmpCostAllocatioDetails.splice(index, 1);
        }
        Calculate_TotalPercentage();
    }
    
    function Calculate_TotalPercentage() {
        var total = 0;
        $scope.Employee.EmpCostAllocatioDetails.forEach(function (element) {
            total = total + parseFloat(element.Percentage);
        });

        document.getElementById("TotalPercentage").innerText = formatNumbers(total);
    }

        ///Document Attachment///
    
    $scope.AddAttachment = function () {

        var AT = document.getElementById('atid').value;
        var DE = document.getElementById('DExpiryDate').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
      //  var ST = document.getElementById('Status').value;
        var totalFiles = document.getElementById("fuAttachment").files.length;
        //$scope.AttachmentTypeId = ($scope.AttachmentTypeId === undefined) ? "" : $scope.AttachmentTypeId;
        //$scope.DExpiryDate = document.getElementById('DExpiryDate').value;

        if (AT == "" && totalFiles < 1) {
            alert("Please Seelct Valid Attachment type and File. Before saving value in Grid.");
            document.getElementById('atid').value = "";
            document.getElementById('DExpiryDate').value = "";
            $('#fuAttachment').val("");
            return false;

        }

            var dr = $scope.Employee.EmpAttachmentDetails.filter(function (a) { return a.AttachmentTypeId=AT && !a.IsDeleted })
            if (dr.lenght != undefined) {
                alert("You can not upload document of same type more than once!");
                document.getElementById('atid').value = "";
                document.getElementById('DExpiryDate').value = "";
                $('#fuAttachment').val("");
                return false;
            }
                
                var formData = new FormData();
                //File Upload
                var totalFiles = document.getElementById("fuAttachment").files.length;

                for (var i = 0; i < totalFiles; i++) {
                    var file = document.getElementById("fuAttachment").files[i];
                    formData.append("UploadedFile", file);
                }

                formData.append("DExpiryDate", $('#DExpiryDate').val());
                formData.append("AttachmentTypeId", $('#atid').val());

                $http({
                    url: '/Employee/SaveAttachment',
                    method: 'POST',
                    headers: { "Content-Type": undefined },
                    transformRequest: function (data) {
                        return formData;//NOTICE THIS RETURN WHICH WAS MISSING
                    },
                    //
                }).success(function (result) {
                    if (result.success == true) {
                        //result.data.showEdit = false;
                        //if (result.data.DExpiryDate != null)
                        //    result.data.DExpiryDate = formattingdate(result.data.DExpiryDate);

                        
                        $scope.Employee.EmpAttachmentDetails.push(result.data);
                        for (i = 0; i < result.data.length; i++) {
                            if (result.data[i]["DExpiryDate"] != null)
                                result.data[i]["DExpiryDate"] = formattingdate(result.data[i]["DExpiryDate"]);
                        }

                         document.getElementById('atid').value = "";
                        document.getElementById('DExpiryDate').value = "";
                        $('#fuAttachment').val("");

                        //result.data.AttachmentContent = [];
                        //$scope.Employee.EmpAttachmentDetails.push(result.data);
                        //document.getElementById('atid').value = "";
                        //document.getElementById('DExpiryDate').value = "";
                        //$('#fuAttachment').val("");

                        //var detailid;
                        ///var ma = {};

                        //Math.max.apply(Math, $scope.Employee.EmpAttachmentDetails.map(function (ques) { detailid = ques.DetailId; }))
                        //detailid = (detailid === undefined) ? 0 : detailid;
                        //ma.AttachmentTypeId = AT;
                        //ma.DExpiryDate = DE;
                        //ma.IsNew = true;
                        //ma.IsDeleted = false;
                        //ma.Status = "Added";
                        //ma.DetailId = detailid + 1;
                        //$scope.Employee.EmpAttachmentDetails.push(ma);
                       

                    }
                }).catch(function (result) {

                });
        
    }

    $scope.ViewAttachment= function (index) {

        var id = $scope.Employee.EmpAttachmentDetails[index].AttachmentTypeId;
        var AttachmentContentType = $scope.Employee.EmpAttachmentDetails[index].AttachmentContentType;
        var AttachmentName = $scope.Employee.EmpAttachmentDetails[index].AttachmentName;

        $http({
            method: "POST",
            url: "/Employee/ViewAttachment",
            data: { _KeyId: id },
            headers: {
                'Content-type': 'application/json'
                //"Content-Type": undefined
            },
            responseType: 'arraybuffer',
        }).success(function (result) {
           
            var blob = new Blob([result], {
                type: AttachmentContentType
            });
            saveAs(blob, AttachmentName);
        }).catch(function (result) {

        });

  
    }

    $scope.RemoveAttachment = function (index) {
        //Find the record using Index from Array.
        var id = $scope.Employee.EmpAttachmentDetails[index].AttachmentTypeId;
        var isnew = $scope.Employee.EmpAttachmentDetails[index].IsNew;
        $window.confirm("Do you want to delete: " );    
    
                $http({
                    url: "/Employee/DeleteAttachment",
                    method: "POST",
                    data: {_keyId:id},
                    //
                }).success(function (result) {
                    if (result.success == true) {
                       
                        $scope.Employee.EmpAttachmentDetails = result.data;
                        for (i = 0; i < result.data.length; i++) {
                            if (result.data[i]["DExpiryDate"] != null)
                                result.data[i]["DExpiryDate"] = formattingdate(result.data[i]["DExpiryDate"]);
                        }


                        //if (isnew == true)
                        //{
                            //$scope.Employee.EmpAttachmentDetails.splice(index, 1);
                        //}
                        //else {
                        //    $scope.Employee.EmpAttachmentDetails[index].IsDeleted = true;
                        //    $scope.Employee.EmpAttachmentDetails[index].AttachmentContent = null;

                        //    var dr = $scope.Employee.EmpAttachmentDetails.filter(function (a) { return a.IsDeleted == false })
                        //    $scope.Employee.EmpAttachmentDetails = dr;
                        //}
                    }
                    else {
                        alert(result.Message);
                    }

                }).catch(function (result) {

                });
            }            
    
        ///Document Attachment///


    function ConvertDate()
    {
        $scope.Employee.JoiningDate = formattingdate($scope.Employee.JoiningDate);
        $scope.Employee.ConfirmationDueDate = formattingdate($scope.Employee.ConfirmationDueDate);
        if ($scope.Employee.ConfirmationDate != null) {
            $scope.Employee.ConfirmationDate = formattingdate($scope.Employee.ConfirmationDate);
        }
        if ($scope.Employee.SeparationDate != null) {
            $scope.Employee.SeparationDate = formattingdate($scope.Employee.SeparationDate);
        }

        $scope.Employee.EmpDetails.BirthDate = formattingdate($scope.Employee.EmpDetails.BirthDate);
        if ($scope.Employee.EmpDetails.WorkingSinceDate != null) {
            $scope.Employee.EmpDetails.WorkingSinceDate = formattingdate($scope.Employee.EmpDetails.WorkingSinceDate);
        }
        for (i = 0; i < $scope.Employee.EmpLeaveDetails.length; i++) {
            $scope.Employee.EmpLeaveDetails[i]["DueDate"] = formattingdate($scope.Employee.EmpLeaveDetails[i]["DueDate"]);

        }

        for (i = 0; i < $scope.Employee.donotUseEmpLDetails.length; i++) {
            $scope.Employee.donotUseEmpLDetails[i]["DueDate"] = formattingdate($scope.Employee.donotUseEmpLDetails[i]["DueDate"]);

        }

        for (i = 0; i < $scope.Employee.EmpAssetDetails.length; i++) {
            $scope.Employee.EmpAssetDetails[i]["IssueDate"] = formattingdate($scope.Employee.EmpAssetDetails[i]["IssueDate"]);
            $scope.Employee.EmpAssetDetails[i]["ExpiryDate"] = formattingdate($scope.Employee.EmpAssetDetails[i]["ExpiryDate"]);
            $scope.Employee.EmpAssetDetails[i]["ReminderDate"] = formattingdate($scope.Employee.EmpAssetDetails[i]["ReminderDate"]);
            $scope.Employee.EmpAssetDetails[i]["DisposalDate"] = formattingdate($scope.Employee.EmpAssetDetails[i]["DisposalDate"]);

        }

        for (i = 0; i < $scope.Employee.donotUseEmpADetails.length; i++) {
            $scope.Employee.donotUseEmpADetails[i]["IssueDate"] = formattingdate($scope.Employee.donotUseEmpADetails[i]["IssueDate"]);
            $scope.Employee.donotUseEmpADetails[i]["ExpiryDate"] = formattingdate($scope.Employee.donotUseEmpADetails[i]["ExpiryDate"]);
            $scope.Employee.donotUseEmpADetails[i]["ReminderDate"] = formattingdate($scope.Employee.donotUseEmpADetails[i]["ReminderDate"]);
            $scope.Employee.donotUseEmpADetails[i]["DisposalDate"] = formattingdate($scope.Employee.donotUseEmpADetails[i]["DisposalDate"]);

        }

        for (i = 0; i < $scope.Employee.EmpFamilyMemberDetails.length; i++) {
            $scope.Employee.EmpFamilyMemberDetails[i]["DOB"] = formattingdate($scope.Employee.EmpFamilyMemberDetails[i]["DOB"]);
            $scope.Employee.EmpFamilyMemberDetails[i]["EffectiveDate"] = formattingdate($scope.Employee.EmpFamilyMemberDetails[i]["EffectiveDate"]);
        }

        for (i = 0; i < $scope.Employee.donotUseEmpFMDetails.length; i++) {
            $scope.Employee.donotUseEmpFMDetails[i]["DOB"] = formattingdate($scope.Employee.donotUseEmpFMDetails[i]["DOB"]);
            $scope.Employee.donotUseEmpFMDetails[i]["EffectiveDate"] = formattingdate($scope.Employee.donotUseEmpFMDetails[i]["EffectiveDate"]);
        }


        for (i = 0; i < $scope.Employee.EmpAttachmentDetails.length; i++) {
            if ($scope.Employee.EmpAttachmentDetails[i]["DExpiryDate"] != null)
                $scope.Employee.EmpAttachmentDetails[i]["DExpiryDate"] = formattingdate($scope.Employee.EmpAttachmentDetails[i]["DExpiryDate"]);
        }


        //for (i = 0; i < $scope.Employee.EmpAttachmentDetails.length; i++) {
        //    if ($scope.Employee.donotUseEmpATTDetails[i]["DExpiryDate"] != null)
        //        $scope.Employee.donotUseEmpATTDetails[i]["DExpiryDate"] = formattingdate($scope.Employee.donotUseEmpATTDetails[i]["DExpiryDate"]);
        //}

        

        $scope.Employee.AuditTrail.CreatedOn = formattingDateTime($scope.Employee.AuditTrail.CreatedOn);
        if ($scope.Employee.AuditTrail.UpdatedOn != null) {
            $scope.Employee.AuditTrail.UpdatedOn = formattingDateTime($scope.Employee.AuditTrail.UpdatedOn);
        }
    }

    //loaddropdown();
    function LoadDropDown()
    {
        $http.get('/Employee/GetCompany').then(function (d) {
            $scope.companylist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetDepartment').then(function (d) {
            $scope.Departmentlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetBranch').then(function (d) {
            $scope.Branchlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetEmployees').then(function (d) {
            $scope.GetEmployeelist = d.data;
        }, function () {
            alert('failed');
        });
              


        $http.get('/Employee/GetJobNature').then(function (d) {
            $scope.JobNaturelist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetMaritalStatus').then(function (d) {
            $scope.MaritalStatuslist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetEmployeeStatus').then(function (d) {
            $scope.EmployeeStatuslist = d.data;
        }, function () {
            alert('failed');
        });


        $http.get('/Employee/GetGrade').then(function (d) {
            $scope.Gradelist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetEmployees').then(function (d) {
            $scope.GetEmployeelist = d.data;
        }, function () {
            alert('failed');
        });


        $http.get('/Employee/GetQualification').then(function (d) {
            $scope.Qualificationlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetPaymentMode').then(function (d) {
            $scope.PaymentModelist = d.data;
        }, function () {
            alert('failed');
        });


        $http.get('/Employee/GetBank').then(function (d) {
            $scope.Banklist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetLeave').then(function (d) {
            $scope.Leavelist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetAsset').then(function (d) {
            $scope.Assetlist = d.data;
        }, function () {
            alert('failed');
        });
        

        $http.get('/Employee/GetRelation').then(function (d) {
            $scope.Relationlist = d.data;
        }, function () {
            alert('failed');
        });


        $http.get('/Employee/GetMedicalPlan').then(function (d) {
            $scope.MedicalPlanlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetSalaryHead').then(function (d) {
            $scope.Headlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetAttachmentType').then(function (d) {
            $scope.Attachmentlist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/Employee/GetAllocationTemplate').then(function (d) {
            $scope.ATemplatelist = d.data;
        }, function () {
            alert('failed');
        });


        $scope.Genders = [{
            GenderId: 1,
            GenderName: 'Male'
        }, {
            GenderId: 2,
            GenderName: 'Female'
        }];


        $scope.HiringTypes = [{
            HiringType: 1,
            HiringTypeName: 'Additional'
        }, {
            HiringType: 2,
            HiringTypeName: 'Replacement'
        }, {
            HiringType: 3,
            HiringTypeName: 'Replacement Promotion'
        }];


    }

});