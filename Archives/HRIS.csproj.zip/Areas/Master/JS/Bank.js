﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});




var app = angular.module('HRIS', []);

app.controller('BankController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtBId').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
    };

    $scope.savedata = function () {
        $http({
            method: "POST",
            url: "/Bank/Save",
            //data: $scope.Bank,
            data:  $scope.Bank 
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Bank = result.data;               
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                $scope.Bank = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }


    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/Bank/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.Bank = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.Bank = result.data;
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/Bank/Undo"
        }).success(function (result) {
            $scope.Bank = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/Bank/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/Bank/Add"
        }).success(function (result) {
            $scope.Bank = {};
            $scope.Bank = result.data;
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/Bank/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }

    function LoadDropDown ()
    {
        $http.get('/Bank/GetCompany').then(function (d) {
            $scope.companylist = d.data;
        }, function () {
            alert('failed');
        });
    }
    



    function ConvertDate() {
       
        $scope.Bank.AuditTrail.CreatedOn = formattingDateTime($scope.Bank.AuditTrail.CreatedOn);
        if ($scope.Bank.AuditTrail.UpdatedOn != null) {
            $scope.Bank.AuditTrail.UpdatedOn = formattingDateTime($scope.Bank.AuditTrail.UpdatedOn);
        }
    }

   
});