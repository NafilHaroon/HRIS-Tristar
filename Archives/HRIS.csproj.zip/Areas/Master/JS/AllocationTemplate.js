﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });

    $("#dialog-delete").dialog({
        autoOpen: false,
        resizable: false,
        height: 250,
        width: 400,
        modal: true,
        class: "DeleteAlert",
        dialogClass: "DeleteAlert",
        title: "Confirm Delete Action",
        buttons: [
            {
                id: "btnDelete",
                text: "Delete",
                width: 120,
                class: "delete",
                click: function () {
                    $(this).dialog('close');
                    var templateid = document.getElementById("txtTemplateId").value;
                    deleteRequest(templateid);
                }
            },
            {
                id: "btnCancel",
                text: "Go Back!",
                width: 120,
                click: function () {
                    $(this).dialog('close');
                }
            }
        ],
        open: function () {
            //this special part is just done because delete and cancel were appearing in this form for unknown reason
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').prop('disabled', false);
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(0)').prop('disabled', false);
            //end of this special part
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').focus();
        }

    });


});

var app = angular.module('HRIS', []);

app.controller('AllocationTemplateController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtTId').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
       
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/AllocationTemplate/Save",
            data: $scope.AllocationTemplate
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.AllocationTemplate = result.data;            
            }
            else {
                // $scope.Employee = result.data;
                alert(result.Message);
                $scope.AllocationTemplate = {};
            }
            setFormControls(result.Session);
            ConvertDate();
            $scope.Clear();
            //loaddropdown();
        }).error(function (result) {
            alert(result);
        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/AllocationTemplate/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
           // loaddropdown();
            $scope.AllocationTemplate = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                alert($scope.errors);
            }
            else {
                $scope.AllocationTemplate = result.data;

            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/AllocationTemplate/Undo"
        }).success(function (result) {
            $scope.AllocationTemplate = {};
            $scope.errors = [];
            setFormControls(result.Session);
            $scope.Clear();
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/AllocationTemplate/Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/AllocationTemplate/Add"
        }).success(function (result) {
            $scope.errors = [];
           // loaddropdown();
            $scope.AllocationTemplate = result.data;         
            
            setFormControls(result.Session);
            ConvertDate();
            $scope.Clear();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/AllocationTemplate/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    $scope.AddAT = function () {

        //Add the new item to the Array.
        var DI = document.getElementById('DivisionId').value;
        var PE = document.getElementById('txtF').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;
        PE = parseFloat(PE).toFixed(2);

        if (DI != "" && PE>0) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.AllocationTemplate.Details.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;
            if (Index != "")
                $scope.AllocationTemplate.Details.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.DivisionId = DI;
            ma.Percentage = parseFloat(PE);
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.AllocationTemplate.Details.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = detailid + 1;
            //}
            $scope.AllocationTemplate.Details.push(ma);
            $scope.Clear();
            ma = {};
        }
        else
        {
            alert("Please Selct Valid Template && percentage should be greater then 0.00");
            return false;
        }
        
    }
    $scope.Clear = function () {
        //Clear the TextBoxes.
        document.getElementById('DivisionId').value = "";
        document.getElementById('txtF').value = 0.00;
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value =  "";
    }
    $scope.EditAT = function (m, index) {

        document.getElementById('DivisionId').value = m.DivisionId;
        document.getElementById('txtF').value = m.Percentage;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
    $scope.RemoveAT = function (index) {
        //Find the record using Index from Array.
       // var CC = $scope.AllocationTemplate.Details[index].DetailId;
        if ($window.confirm("Do you want to delete: ")) {
            //Remove the item from Array using Index.
            $scope.AllocationTemplate.Details.splice(index, 1);
        }
    }


    //$scope.toggleEdit = function (m) {
    //    m.showEdit = m.showEdit ? false : true;
    //}

    //$scope.AddAT = function () {
    //    //Add the new item to the Array.
    //    if ($scope.DivisionId != undefined &&  $scope.DivisionId != "" && $scope.Percentage != undefined
    //        && $scope.Percentage > 0 && $scope.Percentage <= 100 ) {
    //        var detailid;
    //        var sm = {};
    //        Math.max.apply(Math, $scope.AllocationTemplate.Details.map(function (ques) { detailid = ques.DetailId; }))
    //        detailid = (detailid === undefined) ? 0 : detailid;

    //        sm.DivisionId = $scope.DivisionId;
    //        sm.Percentage = $scope.Percentage;
    //        sm.DetailId = detailid += 1;
    //        sm.showEdit = false;
    //        sm.status = "Added";
    //        $scope.AllocationTemplate.Details.push(sm);

    //        //Clear the TextBoxes.
    //        $scope.DivisionId = "";
    //        $scope.Percentage = 0;
    //    }

    //}
    //$scope.EditAT = function (m, index) {
    //    //Add the new item to the Array.
    //    if (m.DivisionId != "" && m.Percentage > 0 && m.Percentage <= 100) {
    //        var sm = {};
    //        $scope.AllocationTemplate.Details.splice(index, 1);
    //        sm.DivisionId = m.DivisionId;
    //        sm.Percentage = m.Percentage;
    //        sm.DetailId = m.DetailId;
    //        if (sm.status == "UnChanged")
    //        {
    //            sm.status = "Edited";
    //        }
    //        else
    //        {
    //            sm.status = "Added";
    //        }
    //        sm.showEdit = false;
           
    //        $scope.AllocationTemplate.Details.push(sm);
    //    }

    //}
 
    

    function LoadDropDown() {
        $http.get('/AllocationTemplate/GetDivision').then(function (d) {
            $scope.Divisionlist = d.data;
        }, function () {
            alert('failed');
        });
    }


    function ConvertDate() {

        $scope.AllocationTemplate.AuditTrail.CreatedOn = formattingDateTime($scope.AllocationTemplate.AuditTrail.CreatedOn);
        if ($scope.AllocationTemplate.AuditTrail.UpdatedOn != null) {
            $scope.AllocationTemplate.AuditTrail.UpdatedOn = formattingDateTime($scope.AllocationTemplate.AuditTrail.UpdatedOn);
        }
    }


});