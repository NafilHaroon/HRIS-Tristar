﻿$(document).ready(function () {
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#numSSPercentage').focus();
    });
});

var app = angular.module('HRIS', []);

app.controller('BranchController', function ($scope, $http, $window) {

    $scope.load = function (res) {
        var id = document.getElementById('txtBranchCode').value;
        if (id > 0)
            $scope.GetData(id);
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "./Save",
            data: $scope.Branch
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.Branch = result.data;
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                $scope.Branch = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            type: "Get",
            //method: "POST",
            url: "./Get",
            dataType: "JSON",
            params: { _keyId : res },
        }).success(function (result) {
            $scope.errors = [];
            $scope.Branch = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.Branch = result.data; 
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            //url: "/Branch/Undo"
            url: "./Undo"
        }).success(function (result) {
            $scope.Branch = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            //url: "/Branch/Exit",
            url: "./Exit",
        }).success(function (result) {
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "./Add"
            //url: "/Branch/Add"
        }).success(function (result) {
            $scope.Branch = {};
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            //url: "../Branch/Recall"
            url: "./Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {
            alert(result);
        });
    }

    function ConvertDate() {

        $scope.Branch.AuditTrail.CreatedOn = formattingDateTime($scope.Branch.AuditTrail.CreatedOn);
        if ($scope.Branch.AuditTrail.UpdatedOn != null) {
            $scope.Branch.AuditTrail.UpdatedOn = formattingDateTime($scope.Branch.AuditTrail.UpdatedOn);
        }
    }
});