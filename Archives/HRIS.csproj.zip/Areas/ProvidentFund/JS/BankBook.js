﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });

    //$('#ChequeDate').datepicker().on("change", function (e) {
    //    //console.log("Date changed: ", e.target.value);
    //    alert($(this).val())
    //   // $(this).val()
    //    e.target.text = $(this).val();
    //});


    //$('#ChequeDate').datepicker({
    //    onSelect: function (date,e) {
    //        //$('#VoucherDates').text(date);
    //        e.target.text = date;
    //    }
    //});


    
    //$('#VoucherDates').datepicker();

    //$('body').on('focus', ".mydatepicker", function () {
    //    $(this).datepicker();
    //});

});
var app = angular.module('HRIS', []);

app.controller('BankBookController', function ($scope, $http, $window) {
     
    $('#VoucherDates').datepicker({
        onSelect: function (date) {
            //$('#VoucherDates').text(date);
                $scope.BankBook.VoucherDate = date;
                $scope.$apply();
            }
    });


    $('#ChequeDate').datepicker({
        minDate: '-150D',
        maxDate: '+180D',
        onSelect: function (date) {
            $scope.BankBook.ChequeDate = date;
            $scope.$apply();
        }
    });
   
    $scope.load = function (res) {

        var id = document.getElementById('txtVNo').value;
        if (id != "")
            $scope.GetData(id);
        LoadDropDown();
    };
    
    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/BankBook/Save",
            data: $scope.BankBook
        }).success(function (result) {
            //loaddropdown();
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.BankBook = result.data;
                
            }
            else {
                // $scope.Employee = result.data;
                alert(result.Message);
                $scope.BankBook = {};
                document.getElementById("fDB").innerText = "";
                document.getElementById("fCR").innerText = "";
                document.getElementById("lblBalance").innerText = "";
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/BankBook/Get",
            data: { _keyId: res },

        }).success(function (result) {
            //loaddropdown();
            $scope.errors = [];
            $scope.BankBook = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.BankBook = result.data;
                $scope.setCompanyAccountList($scope.BankBook.CompanyId)
                Calculate_Total();
                Calculate_TotalDebitCredit();

            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/BankBook/Undo"
        }).success(function (result) {
            $scope.BankBook = {};
            $scope.errors = [];
            setFormControls(result.Session);
            document.getElementById("fDB").innerText = "";
            document.getElementById("fCR").innerText = "";
            document.getElementById("lblBalance").innerText = "";
            
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/BankBook/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/BankBook/Add"
        }).success(function (result) {
            //loaddropdown();
            $scope.errors = [];
            $scope.BankBook = result.data;
            
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/BankBook/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    $scope.toggleEdit = function (m) {
        m.showEdit = m.showEdit ? false : true;
    }


    $scope.AddBB = function () {
     
        //Add the new item to the Array.
        var AC = document.getElementById('AccountCode').value;
        var DE = document.getElementById('Description').value;
        var CR = document.getElementById('Credit').value;
        var DN = document.getElementById('Debit').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;
        CR = parseFloat(CR).toFixed(2);
        DN = parseFloat(DN).toFixed(2);

        if (AC != "" && DE !="" && DN == 0 && CR != 0 || DN != 0 && CR == 0) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.BankBook.Details.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;

            if (Index != "")
                $scope.BankBook.Details.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.AccountCode = AC;
            ma.Description = DE;
            ma.Credit = CR;
            ma.Debit = DN;
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.BankBook.Details.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = detailid + 1;
            //}
            $scope.BankBook.Details.push(ma);
            $scope.Clear();
            Calculate_Total();
            Calculate_TotalDebitCredit();
            ma = {};
        }
        else {
            alert("Please Selct Valid Account, Description, at each row only one Credit and Debit is allowed, whcih should be greater then Zero ");
        }

    }

    $scope.Clear = function () {
        //Clear the TextBoxes.
        document.getElementById('AccountCode').value = "";
        document.getElementById('Description').value = "";
        document.getElementById('Credit').value = 0.00;
        document.getElementById('Debit').value = 0.00;
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
    }
    $scope.EditBB = function (m, index) {

        document.getElementById('AccountCode').value = m.AccountCode;
        document.getElementById('Description').value = m.Description;
        document.getElementById('Credit').value = m.Credit;
        document.getElementById('Debit').value = m.Debit;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
  
    $scope.RemoveBB = function (index) {
        //Find the record using Index from Array.
        //var CC = $scope.BankBook.Details[index].DetailId;
       
        if ($window.confirm("Do you want to delete: " )) {
            //Remove the item from Array using Index.
            $scope.BankBook.Details.splice(index, 1);            
        }
        Calculate_Total();
        Calculate_TotalDebitCredit();
    }


    function Calculate_Total() {
        var debit = 0;
        var credit = 0;
        $scope.BankBook.Details.forEach(function (element) {
            debit = debit + parseFloat(element.Debit);
            credit = credit + parseFloat(element.Credit);
        });

        document.getElementById("fDB").innerText = formatNumbers(debit);
        document.getElementById("fCR").innerText = formatNumbers(credit);
    }


    function Calculate_TotalDebitCredit() {
        var Debit = removeCommas(document.getElementById("fDB").innerText);
        var Credit = removeCommas(document.getElementById("fCR").innerText);

        var Balance = parseFloat(Debit) - parseFloat(Credit);
        if (Balance < 0)
            Balance = Balance * -1;
        var value = ((Debit - Credit) < 0 ? "Debit with " : "Credit with ") + formatNumbers(Balance);
        $("#lblBalance").val(value);
        //(formatNumbers(Balance));
       // document.getElementById("lblBalance").textContent = 100;
       }
    

    function LoadDropDown() {
        //$http.get('/BankBook/GetBankAccount').then(function (d) {
        //    $scope.BankAccountlist = d.data;
        //}, function () {
        //    alert('failed');
        //});

        //$http.get('/BankBook/GetCompanyAccount').then(function (d) {
        //    $scope.CompanyAccountlist = d.data;
        //}, function () {
        //    alert('failed');
        //});

        $http.get('/BankBook/GetCompany').then(function (d) {
            $scope.companylist = d.data;
        }, function () {
            alert('failed');
        });
    }



    $scope.setCompanyAccountList = function (res) {
        //var CompanyId = document.getElementById("ddCompany").value;
        $http({
            method: "POST",
            url: "/BankBook/GetCompanyAccount",
            data: { _CompanyId: res },

        }).success(function (result) {
            $scope.CompanyAccountlist = result;
        }).catch(function (result) {

        });


        $http({
            method: "POST",
            url: "/BankBook/GetBankAccount",
            data: { _CompanyId: res },

        }).success(function (result) {
            $scope.BankAccountlist = result;
        }).catch(function (result) {

        });
    }

    function ConvertDate()
    {
        if ($scope.BankBook.VoucherDate != null) {
            $scope.BankBook.VoucherDate = formattingdate($scope.BankBook.VoucherDate);
        }

        if ($scope.BankBook.ChequeDate != null) {
            $scope.BankBook.ChequeDate = formattingdate($scope.BankBook.ChequeDate);
        }

        $scope.BankBook.AuditTrail.CreatedOn = formattingDateTime($scope.BankBook.AuditTrail.CreatedOn);
        if ($scope.BankBook.AuditTrail.UpdatedOn != null) {
            $scope.BankBook.AuditTrail.UpdatedOn = formattingDateTime($scope.BankBook.AuditTrail.UpdatedOn);
        }
    }



});

