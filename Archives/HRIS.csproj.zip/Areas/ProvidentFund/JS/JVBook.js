﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#ddCompany').focus();
    });

   // $('#VoucherDates').datepicker();


    //$('body').on('focus', ".mydatepicker", function () {
    //    $(this).datepicker();
    //});


});



//function formatNumbers() {
//    var x = Number(document.getElementById('num').value);
//    document.getElementById('num').value = formatNumbers(x);
//}


var app = angular.module('HRIS', []);

app.controller('JVBookController', function ($scope, $http, $window) {
    
    $('#VD').datepicker({      
        onSelect: function (date) {
            $scope.JVBook.VoucherDate = date;
            $scope.$apply();
        }
    });

    $scope.load = function (res) {

        var id = document.getElementById('txtVCode').value;
        if (id !="")
            $scope.GetData(id);
        LoadDropDown();
    };

   
    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/JVBook/Save",
            data: $scope.JVBook
        }).success(function (result) {
           // loaddropdown();
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.JVBook = result.data;
               
            }
            else {
                // $scope.Employee = result.data;
                alert(result.Message);
                $scope.JVBook = {};
                document.getElementById("fDB").innerText = "";
                document.getElementById("fCR").innerText = "";
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/JVBook/Get",
            data: { _keyId: res },

        }).success(function (result) {
           // loaddropdown();
            $scope.errors = [];
            $scope.JVBook = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                alert($scope.errors);
            }
            else {            
                $scope.JVBook = result.data;
                $scope.setCompanyAccountList($scope.JVBook.CompanyId)
                Calculate_Total();
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/JVBook/Undo"
        }).success(function (result) {
            $scope.JVBook = {};
            $scope.errors = [];
            setFormControls(result.Session);
            document.getElementById("fDB").innerText = "";
            document.getElementById("fCR").innerText = "";
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/JVBook/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/JVBook/Add"
        }).success(function (result) {
          //  loaddropdown();
            $scope.errors = [];
            $scope.JVBook = result.data;            
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/JVBook/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    $scope.toggleEdit = function (m) {
        m.showEdit = m.showEdit ? false : true;
    }

    $scope.AddJV = function () {

        //Add the new item to the Array.
        var AC = document.getElementById('AccountCode').value;
        var DE = document.getElementById('Description').value;
        var CR = document.getElementById('Credit').value;
        var DN = document.getElementById('Debit').value;
        var DID = document.getElementById('DetailId').value;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;

        CR = parseFloat(CR).toFixed(2);
        DN = parseFloat(DN).toFixed(2);

        if (AC != "" && DE != "" && DN == 0 && CR != 0 || DN != 0 && CR == 0) {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.JVBook.Details.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;


            if (Index != "")
                $scope.JVBook.Details.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.AccountCode = AC;
            ma.Description = DE;
            ma.Credit = CR;
            ma.Debit = DN;
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.JVBook.Details.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = detailid + 1;
            //}
            $scope.JVBook.Details.push(ma);
            $scope.Clear();
            Calculate_Total();
            Calculate_TotalDebitCredit();
            ma = {};
        }
        else {
            alert("Please Selct Valid Account, Description, at each row only one Credit and Debit is allowed, whcih should be greater then Zero ");
        }

    }

    $scope.Clear = function () {
        //Clear the TextBoxes.
        document.getElementById('AccountCode').value = "";
        document.getElementById('Description').value = "";
        document.getElementById('Credit').value = 0.00;
        document.getElementById('Debit').value = 0.00;
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
    }
    $scope.EditJV = function (m, index) {

        document.getElementById('AccountCode').value = m.AccountCode;
        document.getElementById('Description').value = m.Description;
        document.getElementById('Credit').value = m.Credit;
        document.getElementById('Debit').value = m.Debit;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;

    }
    $scope.RemoveJV = function (index) {
        //Find the record using Index from Array.
        //var CC = $scope.JVBook.Details[index].DetailId;
        if ($window.confirm("Do you want to delete: ")) {
            //Remove the item from Array using Index.
            $scope.JVBook.Details.splice(index, 1);          
        }
        Calculate_Total();

        //var debit = $scope.JVBook.Details.reduce(function (prev, cur) {
        //    return prev + cur.Debit;
        //}, 0);

        //var credit = $scope.JVBook.Details.reduce(function (prev, cur) {
        //    return prev + cur.Credit;
        //}, 0);

        //document.getElementById("fDB").innerText = formatNumbers(debit);
        //document.getElementById("fCR").innerText = formatNumbers(credit);
        
    }


    function Calculate_Total() {
        var debit = 0;
        var credit = 0;
        $scope.JVBook.Details.forEach(function (element) {
            debit = debit + parseFloat(element.Debit);
            credit = credit + parseFloat(element.Credit);
        });

        document.getElementById("fDB").innerText = formatNumbers(debit);
        document.getElementById("fCR").innerText = formatNumbers(credit);
    }

    function LoadDropDown() {

        //$http.get('/JVBook/GetCompanyAccount').then(function (d) {
        //    $scope.CompanyAccountlist = d.data;
        //}, function () {
        //    alert('failed');
        //});

        $http.get('/JVBook/GetCompany').then(function (d) {
            $scope.companylist = d.data;
        }, function () {
            alert('failed');
        });
    }


    //$scope.setCompanyAccountList= function () {
    //    var CompanyId = document.getElementById("ddCompany");
    //    $.get("../JVBook/GetCompanyAccount", { _CompanyId: CompanyId.value }, function (d) {
    //        $scope.CompanyAccountlist = d;
    //    });
    //}

    $scope.setCompanyAccountList = function (res) {
        var CompanyId = document.getElementById("ddCompany").value;
        $http({
            method: "POST",
            url: "/JVBook/GetCompanyAccount",
            data: { _CompanyId: res },

        }).success(function (result) {
            $scope.CompanyAccountlist = result;
        }).catch(function (result) {

        });
    }

    function ConvertDate() {

        if ($scope.JVBook.VoucherDate != null) {
            $scope.JVBook.VoucherDate = formattingdate($scope.JVBook.VoucherDate);
        }

        $scope.JVBook.AuditTrail.CreatedOn = formattingDateTime($scope.JVBook.AuditTrail.CreatedOn);
        if ($scope.JVBook.AuditTrail.UpdatedOn != null) {
            $scope.JVBook.AuditTrail.UpdatedOn = formattingDateTime($scope.JVBook.AuditTrail.UpdatedOn);
        }
    }



});