﻿$(document).ready(function () {

    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
});


var app = angular.module('HRIS', []);

app.controller('ChartofAccountsController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtACode').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/ChartofAccounts/Save",
            data: $scope.ChartofAccounts
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.ChartofAccounts = result.data;               
            }
            else {
                // $scope.Employee = result.data;
                 alert(result.Message);
                $scope.ChartofAccounts = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }


    //$scope.OpenPopupWindow = function () {
    //    var $popup = $window.open("Popup.htm", "popup", "width=250,height=100,left=10,top=150");
    //    $popup.Name = $scope.Name;
    //}

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/ChartofAccounts/Get",
            data: { _keyId: res },

        }).success(function (result) {
            $scope.errors = [];
            $scope.ChartofAccounts = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.ChartofAccounts = result.data;               

            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/ChartofAccounts/Undo"
        }).success(function (result) {
            $scope.ChartofAccounts = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/ChartofAccounts/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/ChartofAccounts/Add"
        }).success(function (result) {
            $scope.ChartofAccounts = {};
            $scope.ChartofAccounts = result.data;
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/ChartofAccounts/Recall"
        }).success(function (result) {
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }

    function LoadDropDown()
    {
        $http.get('/ChartofAccounts/GetAccountType').then(function (d) {
            $scope.AccountTypelist = d.data;
        }, function () {
            alert('failed');
        });

        $http.get('/ChartofAccounts/GetCompany').then(function (d) {
            $scope.companylist = d.data;
        }, function () {
            alert('failed');
        });
    }



    function ConvertDate() {

        $scope.ChartofAccounts.AuditTrail.CreatedOn = formattingDateTime($scope.ChartofAccounts.AuditTrail.CreatedOn);
        if ($scope.ChartofAccounts.AuditTrail.UpdatedOn != null) {
            $scope.ChartofAccounts.AuditTrail.UpdatedOn = formattingDateTime($scope.ChartofAccounts.AuditTrail.UpdatedOn);
        }
    }
   
});