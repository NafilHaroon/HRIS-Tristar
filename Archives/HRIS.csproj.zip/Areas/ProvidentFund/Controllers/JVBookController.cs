﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.ProvidentFund.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.ProvidentFund.Controllers
{
    [NoCache]
    [Authorize]
    public class JVBookController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, JVBook _em, FormCollection formCollection)
        {
            return View();
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            JVBook e = new JVBook();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(JVBook e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (JVBook.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(string _keyId)
        {
            var msg = new Object();
            try
            {
                JVBook cn = JVBook.Get(_keyId);

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }


        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(JVBookList.GetDT(Session["UserId"].ToString()), "../ProvidentFund/JVBook");
            Session["SearchKey"] = "VoucherNumber";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(string  _keyId)
        {
            JVBook _as = new JVBook();
            _as.VoucherNumber = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }

        #endregion

        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstCompanyAccount"] = CoAList.getCompanyByAccountList(Session["UserId"].ToString());
            Session["lstCompany"] = CompanyList.getCompanies(true, Session["UserId"].ToString());
           
            //populateViewBags();
        }
        #endregion

        #region Json Method

        public JsonResult GetCompanyAccount(short _CompanyId)
        {
            List<CoAList> mcDetails = new List<CoAList>();
            mcDetails = (List<CoAList>)Session["lstCompanyAccount"];

            var result = mcDetails.Where(test => test.CompanyId == _CompanyId).ToList();

            //result = new { data = result, };
            return Json(result, JsonRequestBehavior.AllowGet);

            ////return Json((List<ChartofAccountsList>)Session["lstCompanyAccount"], JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCompany()
        {
            return Json((List<CompanyList>)Session["lstCompany"], JsonRequestBehavior.AllowGet);
        }



        #endregion

        #region private methods

        private void clearSessions()
        {            
            Session.Remove("lstCompanyAccount");
            Session.Remove("lstCompany");
        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'JV Book'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }




        private void validate(JVBook at)
        {
            if (!string.IsNullOrEmpty(at.VoucherNumber) )
                ModelState.AddModelError("Validation", "=> No further changes can be made to this Bank Book at this stage");

            if (!at.VoucherDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Voucher Date"));


            if (!at.CompanyId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Company"));


            if (at.Details.Count == 0)
            {
                ModelState.AddModelError("Validation", "=> Atleast one Account  must exist in JV Book to perform save operation");
            }

            else if (at.Details.Where(x => string.IsNullOrEmpty(x.AccountCode)).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Account"));

            else if (at.Details.GroupBy(x => x.AccountCode).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Account  used in JV Book must be unique");

            if (at.Details.Where(x => x.Credit < 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixZero("Credit"));

            if (at.Details.Where(x => x.Debit < 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixZero("Debit"));

            var DB = at.Details.Sum(x => x.Debit);
            var CR = at.Details.Sum(x => x.Credit);
            if (DB != CR)
                ModelState.AddModelError("Validation", "=> Debit and Credit total must be equal to complete the JV. Please make them equal before saving the entry!");

        }

        #endregion

    }
}
