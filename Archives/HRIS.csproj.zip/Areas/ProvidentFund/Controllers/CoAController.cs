﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.ProvidentFund.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.ProvidentFund.Controllers
{
    [NoCache]
    [Authorize]
    public class CoAController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }

        [HttpPost]
        public ActionResult DataForm(string command, CoA b, FormCollection formCollection)
        {               
            return View();
        }   
        
        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            CoA _as = new CoA();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = _as, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Save(CoA e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (CoA.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new { success = false, data = e, Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(), Session = Session["FormMode"].ToString() };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(string _keyId)
        {
            var msg = new Object();
            try
            {
                CoA cn = CoA.Get(_keyId);

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

      
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }



        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(CoAList.GetDT(Session["UserId"].ToString()), "../ProvidentFund/ChartofAccounts");
            Session["SearchKey"] = "AccountCode";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(string  _keyId)
        {
            CoA _as = new CoA();
            _as.AccountCode = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }

        #endregion



        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstAccountType"] = AccountTypeList.Get();
            Session["lstCompany"] = CompanyList.getCompanies(true, Session["UserId"].ToString());
            //populateViewBags();
        }
        #endregion


        #region Json Method
        public JsonResult GetAccountType()
        {
            return Json((List<AccountTypeList>)Session["lstAccountType"], JsonRequestBehavior.AllowGet);
           
        }

        public JsonResult GetCompany()
        {
            return Json((List<CompanyList>)Session["lstCompany"], JsonRequestBehavior.AllowGet);
        }
        #endregion
        

        #region private methods
        
        private void clearSessions()
        {
            Session.Remove("lstAccountType");

            Session.Remove("lstCompany");
        }
            
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Chart of Accounts'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;           
            return View();
        }

        private void validate(CoA coa)
        {
            if (string.IsNullOrEmpty(coa.AccountName))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Account Name"));

            if (!coa.AccountTypeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Account Type"));

            if (coa.OpeningBalance <=0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixZero("OpeningBalance"));
          

        }
        #endregion
    }
}
