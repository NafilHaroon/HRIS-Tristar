﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class JVBook : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Voucher #")]
        public string VoucherNumber { get; set; }
        [Display(Name = "Company")]
        public short? CompanyId { get; set; }
        [Display(Name = "Voucher Date")]
        public DateTime? VoucherDate { get; set; }
           

        public Footer AuditTrail { get; set; }
        public List<JVBookDetail> Details { get; set; }


        #endregion

        #region Constructor
        public JVBook()
        {
            VoucherDate = DateTime.Now;
          
            Details = new List<JVBookDetail>();
            AuditTrail = new Footer();
        }
        #endregion

        #region internal methods
        internal static JVBook Get(string _voucherNo)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetJVBookByCode"))
            {
                db.AddInParameter(dbCommand, "VoucherNumber", SqlDbType.VarChar, _voucherNo);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (JVBook _jb = new JVBook())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _jb.VoucherNumber = _voucherNo;
                            _jb.VoucherDate = Convert.ToDateTime(dr["VoucherDate"]);
                            _jb.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                            _jb.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                            _jb.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _jb.Details = JVBookDetail.Get(_voucherNo);
                            return _jb;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(JVBook _jb, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveJVBook"))
            {
                db.AddInParameter(dbCommand, "VoucherNumber", SqlDbType.VarChar, _jb.VoucherNumber);
                db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _jb.CompanyId);
                db.AddInParameter(dbCommand, "VoucherDate", SqlDbType.DateTime, _jb.VoucherDate);

                db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                db.AddOutParameter(dbCommand, "NewVoucherNumber", SqlDbType.VarChar, 32);

                using (DbConnection dbconnection = db.CreateConnection())
                {
                    dbconnection.Open();
                    DbTransaction transaction = dbconnection.BeginTransaction();
                    try
                    {
                        db.ExecuteNonQuery(dbCommand, transaction);
                        _jb.VoucherNumber = dbCommand.Parameters["@NewVoucherNumber"].Value.ToString();
                        JVBookDetail.Save(_jb.VoucherNumber, _jb.Details, _userId, transaction);
                        transaction.Commit();
                        return true;
                    }

                    catch (Exception)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }            
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}