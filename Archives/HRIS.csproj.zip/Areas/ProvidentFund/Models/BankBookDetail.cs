﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.ProvidentFund.Models
{
    public class BankBookDetail : IDisposable
    {
         #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Voucher #")]
        public string VoucherNumber { get; set; }
        [Display(Name = "Account")]
        public string AccountCode { get; set; }
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Display(Name = "Credit")]
        public double Credit { get; set; }
        [Display(Name = "Debit")]
        public double Debit { get; set; }
        public int DetailId { get; set; }
        public string Status { get; set; }
       

        #endregion

        #region constructor
        public BankBookDetail()
        {

            DetailId = 1;
            Credit = 0;
            Debit = 0;
            Status = "Added";
        }
        public BankBookDetail(int _detailId, string _VoucherNumber, string _AccountCode, string _Description, 
            double _Credit, double _Debit,
            string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            VoucherNumber = _VoucherNumber;
            AccountCode = _AccountCode;
            Description = _Description;
            Credit = _Credit;
            Debit = _Debit;    
            Status = _itemState;
        }
        #endregion

        #region internal methods

        internal static List<BankBookDetail> Get(string _vouchernumber)
        {
            try
            {
                List<BankBookDetail> lstATD = new List<BankBookDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getBankBookDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "VoucherNumber", SqlDbType.VarChar, _vouchernumber);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                           
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstATD.Add(new BankBookDetail(
                                      Convert.ToInt32(dr["DetailId"]),
                                    dr["VoucherNumber"].ToString(),
                                     dr["AccountCode"].ToString(),
                                     dr["Description"].ToString(),
                                     Convert.ToDouble(dr["Credit"]),
                                         Convert.ToDouble(dr["Debit"])));
                            }
                        }
                    }                  
                }
                return lstATD;
            }
            catch (Exception)
            { throw; }
        }


        internal static bool Save(string  _vouchernumber, List<BankBookDetail> _details, string _userId, DbTransaction _transaction)
        {
            try
            {
                foreach (BankBookDetail bbd in _details)
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveBankBookDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "VoucherNumber", SqlDbType.VarChar, _vouchernumber);
                        db.AddInParameter(dbCommand, "AccountCode", SqlDbType.VarChar, bbd.AccountCode);
                        db.AddInParameter(dbCommand, "Description", SqlDbType.VarChar, bbd.Description);
                        db.AddInParameter(dbCommand, "Credit", SqlDbType.Float, bbd.Credit);
                        db.AddInParameter(dbCommand, "Debit", SqlDbType.Float, bbd.Debit);
                        

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
       
      
        #endregion

        #region private methods
        
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

    }
}