﻿using HRIS.Areas.Common.Models;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Transaction.Models
{
    public class AdvanceSalary: IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Reference #")]
        public int? ReferenceNo { get; set; }
       
        [Display(Name = "Reference Date")]
        public DateTime? ReferenceDate { get; set; }
        [Display(Name = "Employee")]
        public short? EmployeeId { get; set; }
       // public string EmployeeCode { get; set; }
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Display(Name = "Amount")]
        public double Amount { get; set; }
       
        public Footer AuditTrail { get; set; }
        #endregion

        #region Constructor
        public AdvanceSalary()
        {
            AuditTrail = new Footer();
            ReferenceDate = DateTime.Now;
        }
        #endregion

        #region internal methods
        internal static AdvanceSalary Get(int _referenceno)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("GetAdvanceSalaryByCode"))
            {
                db.AddInParameter(dbCommand, "ReferenceNo", SqlDbType.Int, _referenceno);
                using (DataSet ds = db.ExecuteDataSet(dbCommand))
                {
                    if (ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                    {
                        using (AdvanceSalary _advSal = new AdvanceSalary())
                        {
                            DataRow dr = ds.Tables[0].Rows[0];
                            _advSal.ReferenceNo = _referenceno;
                            //_bran.CompanyId = Convert.ToInt16(dr["CompanyId"]);
                            _advSal.ReferenceDate = Convert.ToDateTime(dr["ReferenceDate"]);
                            _advSal.EmployeeId = Convert.ToInt16(dr["EmployeeId"]);
                            _advSal.Description = dr["Description"].ToString();
                            _advSal.Amount = Convert.ToDouble(dr["Amount"]);                          
                            _advSal.AuditTrail.CreatedBy = dr["CreatedBy"].ToString();
                            _advSal.AuditTrail.CreatedOn = Convert.ToDateTime(dr["CreatedOn"]);
                         
                            
                         
                            return _advSal;
                        }
                    }
                    else
                        return null;
                }
            }
        }

        internal static bool Save(AdvanceSalary _advSal, string _userId)
        {
            using (DbCommand dbCommand = db.GetStoredProcCommand("SaveAdvanceSalary"))
            {
                try
                {
                    db.AddInParameter(dbCommand, "ReferenceNo", SqlDbType.Int, _advSal.ReferenceNo);
                    //db.AddInParameter(dbCommand, "CompanyId", SqlDbType.TinyInt, _bran.CompanyId);
                    db.AddInParameter(dbCommand, "ReferenceDate", SqlDbType.DateTime, _advSal.ReferenceDate);
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _advSal.EmployeeId);
                    db.AddInParameter(dbCommand, "Description", SqlDbType.VarChar, _advSal.Description);
                    db.AddInParameter(dbCommand, "Amount", SqlDbType.Float, _advSal.Amount);
                    db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
                    db.ExecuteNonQuery(dbCommand);
                    return true;
                }
                catch (Exception)
                { throw; }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            // no implementation
        }
        #endregion
    }
}