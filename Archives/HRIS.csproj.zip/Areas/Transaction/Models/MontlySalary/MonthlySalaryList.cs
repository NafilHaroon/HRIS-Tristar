﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace HRIS.Areas.Transaction.Models
{
    public class MonthlySalaryList : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
         [DataMember(Order = 0)]
         [Display(Name = "Employee Id")]
         public short EmployeeId { get; set; }
         [DataMember(Order = 1)]
         [Display(Name = "Employee Code")]
         public string EmployeeCode { get; set; }
         [DataMember(Order = 2)]
         [Display(Name = "Employee Name")]
         public string  EmployeeName { get; set; }
         [DataMember(Order = 3)]
         [Display(Name = "Branch")]
         public string Branch { get; set; }
          [DataMember(Order = 4)]
          [Display(Name = "Department")]
         public string  Department { get; set; }
         [DataMember(Order = 5)]
         [Display(Name = "Grade")]
         public string  Grade { get; set; }
         [DataMember(Order = 6)]
         [Display(Name = "Designation")]
         public string Designation { get; set; }
         
        #endregion

        #region constructor
        public MonthlySalaryList()
        {
        }

        public MonthlySalaryList(short _EmployeeId, string _EmployeeCode, string _EmployeeName, string _Branch,
            string _Department, string _Grade, string _Designation)
        {
            EmployeeId = _EmployeeId;
            EmployeeCode = _EmployeeCode;
            EmployeeName = _EmployeeName;
            Branch = _Branch;
            Department = _Department;
            Grade = _Grade;
            Designation = _Designation;
           
        }
        #endregion

        #region internal methods
        internal static List<MonthlySalaryList> Get(string _userId)
        {
            return getMonthlySalaryLists(_userId);
        }

        internal static DataTable GetDT(string _userId)
        {
            return AgilityHelper.ListToDataTable(getMonthlySalaryLists(_userId));
        }
        #endregion

        #region private methods
        private static List<MonthlySalaryList> getMonthlySalaryLists(string _userId)
        {
            List<MonthlySalaryList> lstdat = new List<MonthlySalaryList>();

            DbCommand dbCommand = db.GetStoredProcCommand("getMonthlySalaryList");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new MonthlySalaryList(
                              Convert.ToInt16(dr["EmployeeId"]),
                                  dr["EmployeeCode"].ToString(),
                                  dr["EmployeeName"].ToString(),
                                  dr["Branch"].ToString(),
                                  dr["Department"].ToString(),
                                  dr["Grade"].ToString(),
                                   dr["Designation"].ToString()));
                    }
                }
            }
            return lstdat;
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}