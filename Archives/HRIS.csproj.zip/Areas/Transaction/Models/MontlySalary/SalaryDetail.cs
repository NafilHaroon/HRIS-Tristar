﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Transaction.Models
{
    public class SalaryDetail : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Head")]
        public short? HeadId { get; set; }
        [Display(Name = "Amount")]
        public double Amount { get; set; }
        [Display(Name = "Remarks")]
        public string Remarks { get; set; }
        public short LoanId { get; set; }
        public string Status { get; set; }
        public int? DetailId { get; set; }
        public bool AutoCalculated { get; set; }


        #endregion

        #region constructor
        public SalaryDetail()
        {

            Status = "Added";
        }
        public SalaryDetail(int _DetailId, short _HeadId, double _Amount, short _LoanId, string _Remarks,
            string _itemState = "UnChanged")
        {
            DetailId = _DetailId;
            HeadId = _HeadId;
            Amount = _Amount;
            LoanId = _LoanId;
            Remarks = _Remarks;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<SalaryDetail> Get(short _empId)
        {
            try
            {
                List<SalaryDetail> lstESMD = new List<SalaryDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getCurrentMonthSalaryDetailByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstESMD.Add(new SalaryDetail(
                                     Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["HeadId"]),
                                         Convert.ToDouble(dr["Amount"]),
                                          Convert.ToInt16(dr["LoanId"]),
                                         dr["Remarks"].ToString()));
                            }
                        }
                    }
                }
                return lstESMD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<SalaryDetail> _details, List<SalaryDetail> _originalDetails, DbTransaction _transaction)
        {
            try
            {
                foreach (SalaryDetail eld in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveCurrentMonthlySalaryDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, eld.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "HeadId", SqlDbType.TinyInt, eld.HeadId);
                        db.AddInParameter(dbCommand, "Amount", SqlDbType.Float, eld.Amount);
                        db.AddInParameter(dbCommand, "Remarks", SqlDbType.VarChar, eld.Remarks);
                        db.AddInParameter(dbCommand, "LoanId", SqlDbType.TinyInt, eld.LoanId);
                        db.AddInParameter(dbCommand, "AutoCalculated", SqlDbType.Bit, eld.AutoCalculated);

                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            eld.Status == "Added" ? "I" : (
                            eld.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<SalaryDetail> getChanges(List<SalaryDetail> _details,
         List<SalaryDetail> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<SalaryDetail> editedItems = (IEnumerable<SalaryDetail>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<SalaryDetail>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}