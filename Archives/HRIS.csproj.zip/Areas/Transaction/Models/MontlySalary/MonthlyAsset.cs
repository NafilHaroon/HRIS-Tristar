﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace HRIS.Areas.Transaction.Models
{
    public class MonthlyAsset : IDisposable, ICloneable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        [Display(Name = "Asset")]
        public short? AssetId { get; set; }
        [Display(Name = "Limit")]
        public double Limit { get; set; }
        public string Remarks { get; set; }
        public string Status { get; set; }
        public int? DetailId { get; set; }
        #endregion

        #region constructor
        public MonthlyAsset()
        {

            Status = "Added";
        }
        public MonthlyAsset(int _detailId, short _assetId, double _Limit, string _Remarks,
            string _itemState = "UnChanged")
        {
            DetailId = _detailId;
            AssetId = _assetId;
            Limit = _Limit;
            Remarks = _Remarks;
            Status = _itemState;
        }
        #endregion

        #region internal methods

        internal static List<MonthlyAsset> Get(short _empId)
        {
            try
            {
                List<MonthlyAsset> lstEAD = new List<MonthlyAsset>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("getCurrentMonthCompanyMonthlyAssetByCode"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);

                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {

                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                lstEAD.Add(new MonthlyAsset(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["MonthlyAssetId"]),
                                         Convert.ToDouble(dr["Limit"]),
                                             dr["Remarks"].ToString()));
                            }
                        }
                    }
                }
                return lstEAD;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _empId, List<MonthlyAsset> _details, List<MonthlyAsset> _originalDetails,
            DbTransaction _transaction)
        {
            try
            {
                foreach (MonthlyAsset eld in getChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveCurrentMonthCompanyMonthlyAssetDetail"))
                    {
                        dbCommand.Transaction = _transaction;
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _empId);
                        db.AddInParameter(dbCommand, "MonthlyAssetId", SqlDbType.TinyInt, eld.AssetId);
                        db.AddInParameter(dbCommand, "Remarks", SqlDbType.VarChar, eld.Remarks);

                        db.AddInParameter(dbCommand, "Limit", SqlDbType.Float, eld.Limit);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                            eld.Status == "Added" ? "I" : (
                            eld.Status == "Deleted" ? "D" : "U")));

                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<MonthlyAsset> getChanges(List<MonthlyAsset> _details,
         List<MonthlyAsset> _originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            _originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<MonthlyAsset> editedItems = (IEnumerable<MonthlyAsset>)
                    (from actualItem in _details
                     where (actualItem.Status == "Edited" ||
                     actualItem.Status == "Added")
                     select actualItem).Union(
                        from actualItem in _originalDetails
                        where !
                        (from newItem in _details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<MonthlyAsset>();
        }
        #endregion

        #region dispose method
        public void Dispose()
        {
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion
    }
}