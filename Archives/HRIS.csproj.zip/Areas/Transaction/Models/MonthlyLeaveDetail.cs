﻿using HRIS.Helper;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Linq;



namespace HRIS.Areas.Transaction.Models
{
    public class MonthlyLeaveDetail : IDisposable, ICloneable, IValidatableObject
    {
         #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int DetailId { get; set; }
        [Display(Name = "Leave")]
        public short? LeaveId { get; set; }     
        [Display(Name = "Date From")]
        public DateTime? DateFrom { get; set; }
        [Display(Name = "Date To")]
        public DateTime? DateTo { get; set; }
        [Display(Name = "Half Day")]
        public bool HalfDay { get; set; }
        [Display(Name = "Reason")]
        public string Reason { get; set; }
        public string  Status { get; set; }
        #endregion

        #region constructor
        public MonthlyLeaveDetail()
        {
            DetailId = 0;
            DateFrom = DateTime.Now;
            DateTo = DateTime.Now.AddDays(30);
            Status ="Added";
        }

        public MonthlyLeaveDetail(int _detailId, short _LeaveId,
            DateTime _dateFrom, DateTime _dateTo, bool _HalfDay, string _Reason,
            string _itemState ="UnChanged")
        {
            DetailId = _detailId;
            LeaveId = _LeaveId;
            DateFrom = _dateFrom;
            DateTo = _dateTo;
            HalfDay = _HalfDay;
            Reason=_Reason;
            Status = _itemState;
        }
        #endregion

        #region internal methods
        internal static List<MonthlyLeaveDetail> getDetailbyId(short _employeeid)
        {
            try
            {
                List<MonthlyLeaveDetail> adjList = new List<MonthlyLeaveDetail>();
                using (DbCommand dbCommand = db.GetStoredProcCommand("GetMonthlyLeavebyEmployee"))
                {
                    db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _employeeid);
                    using (DataSet ds = db.ExecuteDataSet(dbCommand))
                    {
                        if (ds != null && ds.Tables.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[0].Rows)
                            {
                                adjList.Add(new MonthlyLeaveDetail(
                                    Convert.ToInt32(dr["DetailId"]),
                                    Convert.ToInt16(dr["LeaveId"]),
                                    Convert.ToDateTime(dr["DateFrom"]),
                                    Convert.ToDateTime(dr["DateTo"]),
                                    Convert.ToBoolean(dr["HalfDay"]),                                   
                                    dr["Reason"].ToString()));
                            }
                        }
                    }
                }
                return adjList;
            }
            catch (Exception)
            { throw; }
        }

        internal static bool Save(short _employeeid, List<MonthlyLeaveDetail> _details,
            List<MonthlyLeaveDetail> _originalDetails, DbTransaction _transaction)
        {
            try
            {
                foreach (MonthlyLeaveDetail _cdd in getCDDetailChanges(_details, _originalDetails))
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveMonthlyLeave"))
                    {
                        db.AddInParameter(dbCommand, "DetailId", SqlDbType.SmallInt, _cdd.DetailId);
                        db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, _employeeid);
                        db.AddInParameter(dbCommand, "LeaveId", SqlDbType.SmallInt, _cdd.LeaveId);
                        db.AddInParameter(dbCommand, "DateFrom", SqlDbType.DateTime, _cdd.DateFrom);
                        db.AddInParameter(dbCommand, "DateTo", SqlDbType.DateTime, _cdd.DateTo);
                        db.AddInParameter(dbCommand, "HalfDay", SqlDbType.Bit, _cdd.HalfDay);
                        db.AddInParameter(dbCommand, "Reason", SqlDbType.VarChar, _cdd.Reason);
                        db.AddInParameter(dbCommand, "action", SqlDbType.Char, (
                        _cdd.Status == "Added" ? "I" : (
                        _cdd.Status == "Deleted" ? "D" : "U")));
                        db.ExecuteNonQuery(dbCommand, _transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region private methods
        private static IEnumerable<MonthlyLeaveDetail> getCDDetailChanges(List<MonthlyLeaveDetail> details,
            List<MonthlyLeaveDetail> originalDetails)
        {
            //changing all rows in original list to deleted so that mismatched rows are returned with status deleted
            originalDetails.ForEach(o => o.Status = "Deleted");

            //extracting data through union query, first part look for items with status Added & Edited whereas second part returns
            //items that were part of initial list but not present in current list
            IEnumerable<MonthlyLeaveDetail> editedItems = (IEnumerable<MonthlyLeaveDetail>)
                    (from actualItem in details
                     where AgilityHelper.InList(actualItem.Status,
                        "Edited", "Added")
                     select actualItem).Union(
                        from actualItem in originalDetails
                        where !
                        (from newItem in details select newItem.DetailId).Contains(actualItem.DetailId)
                        select actualItem);
            return editedItems.ToList<MonthlyLeaveDetail>();
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion

        #region ICloneable Members
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        #endregion

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            List<ValidationResult> res = new List<ValidationResult>();
            if (DateTo.Value.Date < DateFrom.Value.Date)
            {
                res.Add(new ValidationResult("Date To must always be newer than or equal to Date From", new string[] { "DateTo" }));
            }
            return res;
        }
    }
}