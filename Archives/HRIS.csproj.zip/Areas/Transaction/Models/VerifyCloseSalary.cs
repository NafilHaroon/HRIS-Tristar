﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace HRIS.Areas.Transaction.Models
{
    public class VerifyCloseSalary : IDisposable
    {
        #region private properties
        private static SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public string BranchName { get; set; }
        public string DepartmentName { get; set; }
        public string EmployeeName { get; set; }
        public string Designation { get; set; }
        public string AbsentDays { get; set; }
        public string LeaveDays { get; set; }
        public string GrossSalary { get; set; }
        public string OtherAllowances { get; set; }
        public string PersonalDeduction { get; set; }
        public string AbsentDeduction { get; set; }
        public string OtherDeduction { get; set; }
        public string TotalSalary { get; set; }
        public bool Verified { get; set; }
        public short EmployeeId { get; set; }
        public List<VerifyCloseSalary> Details { get; set; }
        #endregion

        #region constructor
        public VerifyCloseSalary()
        {
        }

        public VerifyCloseSalary(string _BranchName, string _DepartmentName, string _EmployeeName, string _Designation, string _AbsentDays,
            string _LeaveDays, string _GrossSalary, string _OtherAllowances, string _PersonalDeduction, string _AbsentDeduction,
            string _OtherDeduction, string _TotalSalary, bool _Verified, short _EmployeeId)
        {
            BranchName = _BranchName;
            DepartmentName = _DepartmentName;
            EmployeeName = _EmployeeName;
            Designation = _Designation;
            AbsentDays = _AbsentDays;
            LeaveDays = _LeaveDays;
            GrossSalary = _GrossSalary;
            OtherAllowances = _OtherAllowances;
            PersonalDeduction = _PersonalDeduction;
            AbsentDeduction = _AbsentDeduction;
            OtherDeduction = _OtherDeduction;
            TotalSalary = _TotalSalary;
            Verified = _Verified;
            EmployeeId = _EmployeeId;

        }
        #endregion

        #region internal methods

        internal static List<VerifyCloseSalary> GetDTMonthlySalary(string _userId)
        {
            return getMonthlySalary(_userId);
        }
        #endregion

        #region internal methods
        internal static List<VerifyCloseSalary> getMonthlySalary(string _userId)
        {
            List<VerifyCloseSalary> lstdat = new List<VerifyCloseSalary>();

            DbCommand dbCommand = db.GetStoredProcCommand("getMonthlySalarySummary");
            db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, _userId);
            using (DataSet ds = db.ExecuteDataSet(dbCommand))
            {
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        lstdat.Add(new VerifyCloseSalary(
                                dr["BranchName"].ToString(),
                                 dr["DepartmentName"].ToString(),
                                  dr["EmployeeName"].ToString(),
                                   dr["Designation"].ToString(),
                                    Convert.ToInt32(dr["AbsentDays"]).ToString("#,#.00;(#,#.00)"),
                                      Convert.ToInt32(dr["LeaveDays"]).ToString("#,#.00;(#,#.00)"),
                                         Convert.ToDouble(dr["GrossSalary"]).ToString("#,#.00;(#,#.00)"),
                                            Convert.ToDouble(dr["OtherAllowances"]).ToString("#,#.00;(#,#.00)"),
                                              Convert.ToDouble(dr["PersonalDeduction"]).ToString("#,#.00;(#,#.00)"),
                                                Convert.ToDouble(dr["AbsentDeduction"]).ToString("#,#.00;(#,#.00)"),
                                                 Convert.ToDouble(dr["OtherDeduction"]).ToString("#,#.00;(#,#.00)"),
                                                   Convert.ToDouble(dr["TotalSalary"]).ToString("#,#.00;(#,#.00)"),
                                                     Convert.ToBoolean(dr["Verified"]),
                                                      Convert.ToInt16(dr["EmployeeId"])));
                    }
                }
            }
            return lstdat;
        }


        internal static bool CloseMonthSalary(List<VerifyCloseSalary> _details, string _userId)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    foreach (VerifyCloseSalary ms in _details)
                    {
                        using (DbCommand dbCommand = db.GetStoredProcCommand("CloseMonthSalary"))
                        {
                            db.AddInParameter(dbCommand, "EmployeeId", SqlDbType.SmallInt, ms.EmployeeId);
                            db.AddInParameter(dbCommand, "userid", SqlDbType.VarChar, _userId);
                            db.ExecuteNonQuery(dbCommand, transaction);

                           
                        }
                    }
                    transaction.Commit();
                    return true;
                }

                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
            //
        }
        #endregion
    }
}