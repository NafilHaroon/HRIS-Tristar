﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class AdvanceSalaryController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, AdvanceSalary _em)
        {
            return View();
        }
                

        [HttpPost]
        public JsonResult Save(AdvanceSalary e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (AdvanceSalary.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
              

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            AdvanceSalary e = new AdvanceSalary();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

     
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }



        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {

                AdvanceSalary cn = AdvanceSalary.Get(Convert.ToInt16(_keyId));               

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }
                else
                {
                    Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                    msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };
                }                

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }


        public ActionResult GetId(short? _keyId)
        {
            AdvanceSalary _as = new AdvanceSalary();
            _as.ReferenceNo = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }


        //public ActionResult Search()
        //{
        //    var msg = new Object();
        //    Session["searchdata"] = AdvanceSalaryList.GetDTAsalarys(Session["UserId"].ToString());
        //    Session["SearchKey"] = "ReferenceNo";
        //    msg = new { success = true };
        //    return Json(msg, JsonRequestBehavior.AllowGet);
        //}


        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(AdvanceSalaryList.GetDT(Session["UserId"].ToString()), "../Transaction/AdvanceSalary");
            Session["SearchKey"] = "ReferenceId";
            
            return RedirectToAction("Search", AgilityEnums.myFormPath);
             
        }



        #endregion

        #region lookup methods
        private void populateLUSessions()
        {            
         
            Session["lstEmployee"] = EmployeeList.GetAllowed(Session["UserId"].ToString());
        
        }
        #endregion

        #region Json Method
        public JsonResult GetAllowedEmployee()
        {
            return Json((List<EmployeeList>)Session["lstEmployee"], JsonRequestBehavior.AllowGet);
        }
             
        #endregion

        #region private methods

        

        private void clearSessions()
        {
            Session.Remove("lstEmployee");

        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Advance Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        private void validate(AdvanceSalary e)
        {

            if (e.ReferenceNo.HasValue)
                ModelState.AddModelError("Validation", "=> No further changes can be made to this Advance Salary");

            if (!e.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if (!e.ReferenceDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Reference Date"));

            if (string.IsNullOrEmpty(e.Description))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Description"));
            
            if (e.Amount <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Amount"));
        }

        #endregion

    }
}
