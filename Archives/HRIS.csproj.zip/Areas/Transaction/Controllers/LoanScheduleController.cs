﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class LoanScheduleController : Controller
    {
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, LoanSchedule _em)
        {
            return View();
        }
                

        [HttpPost]
        public JsonResult Save(LoanSchedule e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (LoanSchedule.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }


        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {
                LoanSchedule cn = LoanSchedule.Get(_keyId, Session["UserId"].ToString());

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }
              

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            LoanSchedule e = new LoanSchedule();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
     
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }



        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(LoanScheduleList.GetDTLoanSchedules(false, Session["UserId"].ToString()), "../Transaction/LoanSchedule");
            Session["SearchKey"] = "LoanId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(short? _keyId)
        {
            LoanSchedule _as = new LoanSchedule();
            _as.LoanId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }
        


        #region lookup methods
        private void populateLUSessions()
        {          
            
            Session["lstEmployee"] = EmployeeList.GetAllowed(Session["UserId"].ToString());
        
        }
        #endregion

        #region Json Method


        public JsonResult GetAllowedEmployee()
        {
            return Json((List<EmployeeList>)Session["lstEmployee"], JsonRequestBehavior.AllowGet);
        }

             
        #endregion


        #region private methods

        private void clearSessions()
        {
            Session.Remove("lstEmployee");

        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Loan Schedule'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        private void validate(LoanSchedule e)
        {
            if (!e.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if (!e.StartingDate.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Starting Date"));

            if (string.IsNullOrEmpty(e.Remarks))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Remarks"));
            
            if (e.LoanAmount <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Loan Amount"));

            if (!e.LoanPeriod.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Loan Period"));

            if (e.LoanPeriod <= 0)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Loan Period"));
        }

        #endregion

    }
}
