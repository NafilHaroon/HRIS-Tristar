﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;


namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class BankLetterController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, BankLetter _em)
        {
            return View();
        }


        [HttpPost]
        public JsonResult Save(BankLetter e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                //e.Details = e.Details.Where(x => x.Selected == true).ToList();

                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {        
                    if (BankLetter.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }


        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            BankLetter e = new BankLetter();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }



        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {

                BankLetter cn = BankLetter.getBankLetterById(Convert.ToInt16(_keyId), Session["UserId"].ToString());

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }


        public ActionResult Search() 
        {
            TempData["searchdata"] = new SearchModel(BankLetterList.GetDT(),"../Transaction/BankLetter");
            Session["SearchKey"] = "LetterNumber";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(short? _keyId)
        {
            BankLetter _as = new BankLetter();
            _as.LetterNumber = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }
        //short _KeyId, short _bankId, short  _monthnum, short  _year, short _comid, DateTime _ldate
        public JsonResult GetEmployeeDetail(BankLetter bnd )
        {
            var msg = new Object();
            try
            {

                bnd.Details = getEmpDetail(Convert.ToInt16(bnd.LetterNumber), Convert.ToInt16(bnd.BankId), Convert.ToInt16(bnd.SalaryMonth),
                    Convert.ToInt16(bnd.SalaryYear), Convert.ToInt16(bnd.CompanyId), false, Session["UserId"].ToString());

                if (bnd == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Add;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.Add;
                msg = new { success = true, data = bnd, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }
        #endregion

        #region lookup methods
        private void populateLUSessions()
        {
            Session["lstBank"] = BankList.Get(true);
            Session["lstSalaryMonthYear"] = MonthlyAttendanceList.getSalaryMonthYearList();
            Session["lstCompany"] = CompanyList.getCompanies(true, Session["UserId"].ToString());
        } 
        #endregion  

        #region Json Method
        public JsonResult GetBank()
        {
            return Json((List<BankList>)Session["lstBank"], JsonRequestBehavior.AllowGet);
        }

        //public JsonResult GetSalaryMonthYear()
        //{
        //    return Json((List<MonthlyAttendanceList>)Session["lstSalaryMonthYear"], JsonRequestBehavior.AllowGet);
        //}

        public JsonResult GetMonth()
        {
            return Json((List<MonthlyAttendanceList>)Session["lstSalaryMonthYear"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetYear()
        {
            List<MonthlyAttendanceList> mcDetails = new List<MonthlyAttendanceList>();
            mcDetails = (List<MonthlyAttendanceList>)Session["lstSalaryMonthYear"];


            var result = mcDetails.GroupBy(test => test.Year)
                   .Select(grp => grp.First())
                   .ToList();

            return Json((List<MonthlyAttendanceList>)result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCompany()
        {
            return Json((List<CompanyList>)Session["lstCompany"], JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region private methods
        
        private void clearSessions()
        {
            Session.Remove("lstBank");
            Session.Remove("lstSalaryMonthYear");
            Session.Remove("lstCompany");
        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Bank Letter'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }

        private List<BankLetterDetail> getEmpDetail(short _KeyId, short bankId, short monthnum, short years, short comid, bool selected, string _userId)
        {
            return BankLetterDetail.getDetailbyId(_KeyId, monthnum, years, bankId, comid, selected, _userId);
        }


        private void validate(BankLetter e)
        {
            if (!e.BankId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Bank"));

            if (!e.CompanyId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Bank"));

            if (!e.SalaryMonth.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Salary Month"));

            if (!e.SalaryYear.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Salary Year"));

            if (string.IsNullOrEmpty(e.Remarks))
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Remarks"));

            if (e.Details.Count ==0)
                ModelState.AddModelError("Validation", "Please Select atleast one employee  to perform save operation.");

            var blist = e.Details.Where(x => x.Selected == true).ToList();

            if (blist.Where(x => x.StopSalary==true).Any())
                ModelState.AddModelError("Validation", "This salary has been stopped by HR therefore you can't include it in any letter unless it is released by the Authorized User. Please contact your HR or System Admin for further details");

        }

        #endregion

    }
}
