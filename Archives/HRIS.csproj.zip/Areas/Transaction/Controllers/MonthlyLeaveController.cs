﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class MonthlyLeaveController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, MonthlyLeave _em)
        {
            return View();
        }
                

        [HttpPost]
        public JsonResult Save(MonthlyLeave e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (MonthlyLeave.Save(e))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short employeeid)
        {
            var msg = new Object();
            try
            {

                MonthlyLeave cn = MonthlyLeave.getMonthlyLeaveById(Convert.ToInt16(employeeid));
               

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            MonthlyLeave e = new MonthlyLeave();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

     
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(MonthlySalaryList.GetDT(Session["UserId"].ToString()), "../Transaction/MonthlyLeave");
            Session["SearchKey"] = "EmployeeId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(short? _keyId)
        {
            MonthlyLeave _as = new MonthlyLeave();
            _as.EmployeeId = _keyId;
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }
        #endregion

        #region lookup methods
        private void populateLUSessions()
        {  
            Session["lstEmployee"] = EmployeeList.GetAllowed(Session["UserId"].ToString());
            Session["lstLeave"] = LeaveList.Get(true);
        }
        #endregion

        #region Json Method
        public JsonResult GetAllowedEmployee()
        {
            return Json((List<EmployeeList>)Session["lstEmployee"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetLeave()
        {
            return Json((List<LeaveList>)Session["lstLeave"], JsonRequestBehavior.AllowGet);
        }
          
             
        #endregion

        #region private methods

        

        private void clearSessions()
        {
            Session.Remove("lstEmployee");
            Session.Remove("lstLeave");

        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Monthly Leave'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }


        private void validate(MonthlyLeave e)
        {
            if (!e.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if(e.Details.Count>0)
            {
                if (e.Details.Where(x => !x.LeaveId.HasValue).Any())
                    ModelState.AddModelError("Validation", "=> Leave line must have Leave Selected!");

                if (e.Details.Where(x => !x.DateFrom.HasValue & !x.DateTo.HasValue).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Validity From & To"));

                else if (e.Details.Where(x => x.DateFrom.Value.Date > x.DateTo.Value.Date).Any())
                    ModelState.AddModelError("Validation", "=> Date From for  must always be older than Date To");


                if (e.Details.GroupBy(x => new { x.LeaveId, x.DateFrom }).Any(grp => grp.Count() > 1))
                    ModelState.AddModelError("Validation", "=> The combination of Leave & Date From must be unique for each Row");

                //if (e.Details.GroupBy(x => x.LeaveId).Any(grp => grp.Count() > 1))
                //    ModelState.AddModelError("Validation", "=> Leave  used in Monthly Leave must be unique");


                if (e.Details.Where(x => string.IsNullOrWhiteSpace(x.Reason)).Any())
                    ModelState.AddModelError("Validation", AgilityHelper.SuffixRF("Reason"));
            }
        }

        #endregion

    }
}
