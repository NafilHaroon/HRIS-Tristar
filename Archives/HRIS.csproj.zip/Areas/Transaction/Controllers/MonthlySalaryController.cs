﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Master.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;

namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class MonthlySalaryController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {
            clearSessions();
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, Models.MonthlySalary _ms)
        {
            return View();
        }

        [HttpPost]
        public JsonResult Save(Models.MonthlySalary e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (Models.MonthlySalary.Save(e, Session["UserId"].ToString()))
                    {
                        string Success = "Save operation completed successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Get(short _keyId)
        {
            var msg = new Object();
            try
            {

                Models.MonthlySalary cn = Models.MonthlySalary.Get(_keyId);
               

                if (cn == null)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    throw new Exception("The request # doesn't exist or you donot have permission to access it");
                }

                Session["FormMode"] = AgilityEnums.formMode.ReadOnly;
                msg = new { success = true, data = cn, Session = Session["FormMode"].ToString() };

            }

            catch (Exception ex)
            {
                msg = new { success = false, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);

        }

        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();
            ModelState.Clear();
            Models.MonthlySalary e = new Models.MonthlySalary();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

     
        [HttpPost]
        public JsonResult Recall()
        {
            var msg = new Object();
            Session["FormMode"] = AgilityEnums.formMode.Recall;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }


        public ActionResult Search()
        {
            TempData["searchdata"] = new SearchModel(MonthlySalaryList.GetDT(Session["UserId"].ToString()), "../Transaction/MonthlySalary");
            Session["SearchKey"] = "EmployeeId";
            return RedirectToAction("Search", AgilityEnums.myFormPath);
        }

        public ActionResult GetId(short? _keyId)
        {
            Models.MonthlySalary _as = new Models.MonthlySalary();
            _as.EmployeeId = _keyId;
            _as.SessionValue = Convert.ToInt16(Session["AbsentDeductionId"]);
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View("DataForm", _as);
        }


        public JsonResult Delete(string _keyId)
        {
            try
            {
                if (Convert.ToBoolean(Session["AllowDelete"]))
                {
                    if (Models.MonthlySalary.Delete(_keyId))
                    {
                        TempData["alertMessage"] = "Employee Id " + _keyId + " deleted successfully";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;
                    }
                }
                return Json(new { success = true, errorMsg = string.Empty }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, errorMsg = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region lookup methods
        private void populateLUSessions()
        { 
            Session["lstEmployee"] = EmployeeList.GetAllowed(Session["UserId"].ToString());
            Session["lstSalaryHead"] = SalaryHeadList.Get(true, 0);
            Session["lstAsset"] = AssetList.Get();  
        }
        #endregion

        #region Json Method
        public JsonResult GetAllowedEmployee()
        {
            return Json((List<EmployeeList>)Session["lstEmployee"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetSalaryHead()
        {
            return Json((List<SalaryHeadList>)Session["lstSalaryHead"], JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAsset()
        {
            return Json((List<AssetList>)Session["lstAsset"], JsonRequestBehavior.AllowGet);
        }
             
        #endregion

        #region private methods



        private void clearSessions()
        {
            Session.Remove("lstEmployee");
            Session.Remove("lstSalaryHead");
            Session.Remove("lstAsset");
        }

        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Monthly Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
            populateLUSessions();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            Models.MonthlySalary e = new Models.MonthlySalary();
            e.SessionValue = Convert.ToInt16(Session["AbsentDeductionId"]);

            return View(e);
        }


        private void validate(Models.MonthlySalary e)
        {
            if (!e.EmployeeId.HasValue)
                ModelState.AddModelError("Validation", AgilityHelper.SuffixRF(" Employee"));

            if (e.LeavesDays>e.MonthDays)
                ModelState.AddModelError("Validation", "Leave days can't be more than total days in the month");

            if (e.AbsentDays > e.MonthDays)
                ModelState.AddModelError("Validation", "Absent days can't be more than total days in the month");

            else if (e.EmpAssetDetails.Where(x => !x.AssetId.HasValue).Any())
                ModelState.AddModelError("Validation", "=> Employee Asset  must have Aseet Selected!");

            else if (e.EmpSalaryMonthlyDetails.Where(x => !x.HeadId.HasValue).Any())
                ModelState.AddModelError("Validation", "=> Employee Salary  must have Salary Head Selected!");

            else if (e.EmpSalaryMonthlyDetails.Where(x => x.Amount <=0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Amount"));

            else if (e.EmpAssetDetails.Where(x => x.Limit <= 0).Any())
                ModelState.AddModelError("Validation", AgilityHelper.SuffixgtZero("Limit"));

            else if (e.EmpAssetDetails.GroupBy(x => x.AssetId).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Asset  used in  Monthly Company Asset must be unique");

            else if (e.EmpSalaryMonthlyDetails.GroupBy(x => new { x.HeadId, x.LoanId }).Any(grp => grp.Count() > 1))
                ModelState.AddModelError("Validation", "=> Head and Loan  used in  Monthly Salary must be unique");

           
        }

        #endregion

    }
}
