﻿using HRIS.Areas.Common.Models;
using HRIS.Areas.Transaction.Models;
using HRIS.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;


namespace HRIS.Areas.Transaction.Controllers
{
    [NoCache]
    [Authorize]
    public class VerifyCloseSalaryController : Controller
    {
        #region internal methods
        public ActionResult DataForm()
        {          
            return setAccessOption();
        }
        [HttpPost]
        public ActionResult DataForm(string command, VerifyCloseSalary _em)
        {
            return View();
        }


        [HttpPost]
        public JsonResult Save(VerifyCloseSalary e)
        {
            var msg = new Object();
            try
            {
                #region Validation
                validate(e);
                #endregion
                #region save to db
                if (ModelState.IsValid)
                {
                    if (VerifyCloseSalary.CloseMonthSalary(e.Details, Session["UserId"].ToString()))
                    {
                        string Success = "Month Salary is closed and Verified";
                        Session["FormMode"] = AgilityEnums.formMode.Initialize;

                        msg = new { success = true, data = e, Message = Success, Session = Session["FormMode"].ToString() };
                    }
                }

                if (!ModelState.IsValid)
                {
                    Session["FormMode"] = AgilityEnums.formMode.Edit;
                    msg = new
                    {
                        success = false,
                        data = e,
                        Message = ModelState.Keys.SelectMany(k => ModelState[k].Errors).Select(m => m.ErrorMessage).ToArray(),
                        Session = Session["FormMode"].ToString()
                    };
                }
                #endregion
            }

            catch (Exception ex)
            {
                Session["FormMode"] = AgilityEnums.formMode.Edit;
                msg = new { success = false, data = e, Message = ex.Message, Session = Session["FormMode"].ToString() };
                return Json(msg, JsonRequestBehavior.AllowGet);
            }
            return Json(msg, JsonRequestBehavior.AllowGet);
        }


        public JsonResult Undo()
        {
            var msg = new Object();
            ModelState.Clear();
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            msg = new { success = true, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Exit()
        {
            return Json(new { url = Url.Action("Index", "../Common/Common") }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Add()
        {
            var msg = new Object();

            ModelState.Clear();
            VerifyCloseSalary e = new VerifyCloseSalary();
            Session["FormMode"] = AgilityEnums.formMode.Add;
            e.Details = VerifyCloseSalary.GetDTMonthlySalary(Session["UserId"].ToString());
            msg = new { success = true, data = e, Session = Session["FormMode"].ToString() };
            return Json(msg, JsonRequestBehavior.AllowGet);
        }
       
        #endregion
      

        private void validate(VerifyCloseSalary ms)
        {           
            if (ms.Details.Where(x => x.Verified = false).Any())
                ModelState.AddModelError("Validation", "All record must be checked and verified below closing. Please make all record select before saving the entry!");
        }               
      
        private ActionResult setAccessOption()
        {
            DataRow[] dr = ((DataTable)Session["AccessOption"]).Select("OptionName = 'Verify & Close Salary'");
            if (dr.Count() > 0)
            {
                Session["AllowAdd"] = Convert.ToBoolean(dr[0]["canAdd"]);
                Session["AllowDelete"] = Convert.ToBoolean(dr[0]["canDelete"]);
                Session["AllowEdit"] = Convert.ToBoolean(dr[0]["canEdit"]);
            }
            else
            {
                ViewBag.Menu = (List<Menu>)Session["MainMenu"];
                return View("InvalidMenuOption");
            }
           
            Session["FormMode"] = AgilityEnums.formMode.Initialize;
            return View();
        }
       

    }
}
