﻿$(document).ready(function () {    
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
    
    //$('#StartingDate').datepicker();
   
});


function validateNumber() {
    var element = document.getElementById('lpid');
    element.value = element.value.replace(/[^0-9]+/, '');
};

var app = angular.module('HRIS', []);

app.controller('LoanScheduleController', function ($scope, $http, $window) {

    $('#StartingDate').datepicker({
        onSelect: function (date) {
            $scope.LoanSchedule.StartingDate = date;
            $scope.$apply();
        }
    });



    $scope.load = function (res) {

        var id = document.getElementById('txtLId').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/LoanSchedule/Save",
            data: $scope.LoanSchedule
        }).success(function (result) {
            //loaddropdown();
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.LoanSchedule = result.data;
      
            }
            else {
               // $scope.LoanSchedule = result.data;
                alert(result.Message);
                $scope.LoanSchedule = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    }    

   

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/LoanSchedule/Undo"
        }).success(function (result) {
            $scope.LoanSchedule = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/LoanSchedule/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }


    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/LoanSchedule/Add"
        }).success(function (result) {
           // loaddropdown();
            $scope.errors = [];
            $scope.LoanSchedule = result.data;

            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }
   



    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/LoanSchedule/Get",
            data: { _keyId: res },

        }).success(function (result) {
           // loaddropdown();
            $scope.errors = [];
            $scope.LoanSchedule = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                alert($scope.errors);
            }
            else {
                $scope.LoanSchedule = result.data;
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }


    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/LoanSchedule/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }


    function LoadDropDown() {
        $http.get('/LoanSchedule/GetAllowedEmployee').then(function (d) {
            $scope.Employeelist = d.data;
        }, function () {
            alert('failed');
        });
    }

   

  
    function ConvertDate() {

        if ($scope.LoanSchedule.StartingDate != null) {
            $scope.LoanSchedule.StartingDate = formattingdate($scope.LoanSchedule.StartingDate);
        }

        $scope.LoanSchedule.AuditTrail.CreatedOn = formattingDateTime($scope.LoanSchedule.AuditTrail.CreatedOn);
        if ($scope.LoanSchedule.AuditTrail.UpdatedOn != null) {
            $scope.LoanSchedule.AuditTrail.UpdatedOn = formattingDateTime($scope.LoanSchedule.AuditTrail.UpdatedOn);
        }
    }

});