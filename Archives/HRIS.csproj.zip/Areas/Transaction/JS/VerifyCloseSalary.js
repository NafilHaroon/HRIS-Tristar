﻿$(document).ready(function () {      
    
    $('#allcb').change(function () {
        $('tbody tr td input[type="checkbox"]').prop('checked', $(this).prop('checked'));
    });
   
});


var app = angular.module('HRIS', []);

app.controller('VerifyCloseSalaryController', function ($scope, $http, $window) {



    $scope.load = function (res) {

        $http({
            method: "POST",
            url: "/VerifyCloseSalary/Add"
        }).success(function (result) {
            $scope.errors = [];
            $scope.VerifyCloseSalary = result.data;


        }).catch(function (result) {

        });
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/VerifyCloseSalary/Save",
            data: $scope.VerifyCloseSalary
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.VerifyCloseSalary = result.data;
      
            }
            else {
               // $scope.AdvanceSalary = result.data;
                alert(result.Message);
                $scope.VerifyCloseSalary = {};
            }
        }).error(function (result) {
          
        });
    }    

   

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/VerifyCloseSalary/Undo"
        }).success(function (result) {
            $scope.VerifyCloseSalary = {};
            $scope.errors = [];
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/VerifyCloseSalary/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }

   


     
        
});