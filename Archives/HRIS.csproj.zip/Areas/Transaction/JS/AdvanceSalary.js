﻿/// <reference path="../../Common/Views/MyForms/Search.cshtml" />
/// <reference path="../../Common/Views/MyForms/Search.cshtml" />
$(document).ready(function () {    
    $("#btnEdit").click(function () {
        setFormControls("Edit");
        $('#Desc').focus();
    });
    
    //$('#ReferenceDate').datepicker();
    
   
});



var app = angular.module('HRIS', []);

app.controller('AdvanceSalaryController', function ($scope, $http, $window) {

    $('#ReferenceDate').datepicker({
        onSelect: function (date) {
            $scope.AdvanceSalary.ReferenceDate = date;
            $scope.$apply();
        }
    });



    $scope.load = function (res) {

        var id = document.getElementById('txtReferenceNo').value ;
        if (id>0)
            $scope.GetData(id);
        LoadDropDown();
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/AdvanceSalary/Save",
            data: $scope.AdvanceSalary
        }).success(function (result) {
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]

                $scope.AdvanceSalary = result.data;      
            }
            else {
                alert(result.Message);
                $scope.AdvanceSalary = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    }    
    
    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/AdvanceSalary/Undo"
        }).success(function (result) {
            $scope.AdvanceSalary = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/AdvanceSalary/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }
     
    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/AdvanceSalary/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls("Recall");
        }).catch(function (result) {

        });
    }
    
    $scope.Add = function () {
        $http({
            method: "POST",
            url: "/AdvanceSalary/Add"
        }).success(function (result) {
            $scope.errors = [];
            $scope.AdvanceSalary = result.data;
                     
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {

        });
    }

    $scope.loadItems = function (search) {
        $scope.GetData(search);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/AdvanceSalary/Get",
            data: { _keyId: res },
        }).success(function (result) {
            $scope.errors = [];
            $scope.AdvanceSalary = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.AdvanceSalary = result.data;                             
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    function LoadDropDown()
    {
        $http.get('/AdvanceSalary/GetAllowedEmployee').then(function (d) {
            $scope.Employeelist = d.data;
        }, function () {
            alert('failed');
        });
    }
       


        function ConvertDate() {


            if ($scope.AdvanceSalary.ReferenceDate != null) {
                $scope.AdvanceSalary.ReferenceDate = formattingdate($scope.AdvanceSalary.ReferenceDate);
            }
            $scope.AdvanceSalary.AuditTrail.CreatedOn = formattingDateTime($scope.AdvanceSalary.AuditTrail.CreatedOn);
            if ($scope.AdvanceSalary.AuditTrail.UpdatedOn != null) {
                $scope.AdvanceSalary.AuditTrail.UpdatedOn = formattingDateTime($scope.AdvanceSalary.AuditTrail.UpdatedOn);
            }
        }

});