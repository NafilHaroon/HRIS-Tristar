﻿$(document).ready(function () {    
    $("#btnEdit").click(function () {
        setFormControls("Edit");
    });
    
    $('#DateFrom').datepicker();
    $('#DateTo').datepicker();
   
    //$('body').on('focus', ".mydatepicker", function () {
    //    $(this).datepicker();
    //});
});





var app = angular.module('HRIS', []);

app.controller('MonthlyLeaveController', function ($scope, $http, $window) {

    $scope.load = function () {
        var id = document.getElementById('txtEId').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
    };
    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/MonthlyLeave/Save",
            data: $scope.MonthlyLeave
        }).success(function (result) {
            //LoadDropDown();
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.MonthlyLeave = result.data;      
            }
            else {
               // $scope.MonthlyLeave = result.data;
                alert(result.Message);
                $scope.MonthlyLeave = {};
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    } 

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/MonthlyLeave/Undo"
        }).success(function (result) {
            $scope.MonthlyLeave = {};
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/MonthlyLeave/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }   

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/MonthlyLeave/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls(result.Session);
            //LoadDropDown();

        }).catch(function (result) {

        });
    }

   

    $scope.changedValue = function (res) {
        $scope.GetData(res);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/MonthlyLeave/Get",
            data: { employeeid: res },
        }).success(function (result) {
            //LoadDropDown();
            $scope.errors = [];
            $scope.MonthlyLeave = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.MonthlyLeave = result.data;
                                          
            }

            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.AddML = function () {
        
        //Add the new item to the Array.
        var DF = document.getElementById('DateFrom').value;
        var DT = document.getElementById('DateTo').value;
        var LI = document.getElementById('LeaveId').value;
        var DID = document.getElementById('DetailId').value;
        var RS = document.getElementById('Reason').value;
        var HD = document.getElementById("HalfDay").checked;
        var ST = document.getElementById('Status').value;
        var Index = document.getElementById('Row').value;
        DID = (DID === "") ? 0 : DID;
        if (LI != "" && DF != "" && DT != "" && RS != "") {

            var detailid;
            var ma = {};

            //Math.max.apply(Math, $scope.MonthlyLeave.Details.map(function (ques) { detailid = ques.DetailId; }))
            //detailid = (detailid === undefined) ? 0 : detailid;
            if (Index != "")
                $scope.MonthlyLeave.Details.splice(Index, 1);
            ma.Status = DID <= 0 ? "Added" : "Edited";
            if (DID == 0)
                ma.DetailId = -1;
            else {
                ma.DetailId = DID;
            }
            ma.DateFrom = DF;
            ma.DateTo = DT;
            ma.LeaveId = LI;
            ma.Reason = RS;
            ma.HalfDay = HD;
            //if (ST == "UnChanged") {
            //    ma.Status = "Edited";
            //}
            //else {
            //    ma.Status = "Added";
            //}

            //if (DID != 0) {
            //    ma.DetailId = DID;
            //    $scope.MonthlyLeave.Details.splice(Index, 1);
            //}
            //else {
            //    ma.DetailId = detailid + 1;
            //}
            //$scope.MonthlyLeave.Details.push(ma);
            $scope.Clear();
            ma = {};
        }
        else {
            alert("Please Select Valid LeaveId, Dates. Before saving value in Grid. ");
        }
    }
    $scope.Clear = function () {
        //Clear the TextBoxes.
        document.getElementById('DateFrom').value = "";
        document.getElementById('DateTo').value = "";
        document.getElementById('LeaveId').value = "";
        document.getElementById("HalfDay").checked = false;
        document.getElementById('Reason').value = "";
        document.getElementById('DetailId').value = "";
        document.getElementById('Status').value = "";
        document.getElementById('Row').value = "";
    }
    $scope.EditML = function (m, index) {

        document.getElementById('DateFrom').value = m.DateFrom;
        document.getElementById('DateTo').value = m.DateTo;
        document.getElementById('LeaveId').value = m.LeaveId;
        document.getElementById("HalfDay").checked = m.HalfDay;
        document.getElementById("Reason").checked = m.Reason;
        document.getElementById('DetailId').value = m.DetailId;
        document.getElementById('Status').value = m.Status;
        document.getElementById('Row').value = index;
        
    }
    $scope.RemoveML = function (index) {
            //Find the record using Index from Array.
           // var CC = $scope.MonthlyLeave.Details[index].DetailId;
            if ($window.confirm("Do you want to delete: " )) {
                //Remove the item from Array using Index.
                $scope.MonthlyLeave.Details.splice(index, 1);
            }
        }

        function LoadDropDown()
        {
            $http.get('/MonthlyLeave/GetAllowedEmployee').then(function (d) {
                $scope.Employeelist = d.data;
            }, function () {
                alert('failed');
            });

            $http.get('/MonthlyLeave/GetLeave').then(function (d) {
                $scope.Leavelist = d.data;
            }, function () {
                alert('failed');
            });
        }
      

        function ConvertDate() {

            for (i = 0; i < $scope.MonthlyLeave.Details.length; i++) {
                

                if ($scope.MonthlyLeave.Details[i]["DateFrom"] != null)
                    $scope.MonthlyLeave.Details[i]["DateFrom"] = formattingdate($scope.MonthlyLeave.Details[i]["DateFrom"]);

                if ($scope.MonthlyLeave.Details[i]["DateTo"] != null)
                    $scope.MonthlyLeave.Details[i]["DateTo"] = formattingdate($scope.MonthlyLeave.Details[i]["DateTo"]);
            }
            for (i = 0; i < $scope.MonthlyLeave.donotUseDetails.length; i++) {
                if ($scope.MonthlyLeave.donotUseDetails[i]["DateFrom"] != null)
                    $scope.MonthlyLeave.donotUseDetails[i]["DateFrom"] = formattingdate($scope.MonthlyLeave.donotUseDetails[i]["DateFrom"]);

                if ($scope.MonthlyLeave.donotUseDetails[i]["DateTo"] != null)
                    $scope.MonthlyLeave.donotUseDetails[i]["DateTo"] = formattingdate($scope.MonthlyLeave.donotUseDetails[i]["DateTo"]);               
            }

            if ($scope.MonthlyLeave.AuditTrail.CreatedOn != null) {
                $scope.MonthlyLeave.AuditTrail.CreatedOn = formattingDateTime($scope.MonthlyLeave.AuditTrail.CreatedOn);
            }
            if ($scope.MonthlyLeave.AuditTrail.UpdatedOn != null) {
                $scope.MonthlyLeave.AuditTrail.UpdatedOn = formattingDateTime($scope.MonthlyLeave.Employee.AuditTrail.UpdatedOn);
            }
        }

     
        
});