﻿$(document).ready(function () {    
    $("#btnEdit").click(function () {
        setFormControls("Edit");
      
    });

    $("#tbMEmp").tabs({
        collapsible: false
    });

    $("#dialog-delete").dialog({
        autoOpen: false,
        resizable: false,
        height: 250,
        width: 400,
        modal: true,
        class: "DeleteAlert",
        dialogClass: "DeleteAlert",
        title: "Confirm Delete Action",
        buttons: [
            {
                id: "btnDelete",
                text: "Delete",
                width: 120,
                class: "delete",
                click: function () {
                    $(this).dialog('close');
                    var employeeid = document.getElementById("ddEmployeeId").value;
                    deleteRequest(employeeid);
                }
            },
            {
                id: "btnCancel",
                text: "Go Back!",
                width: 120,
                click: function () {
                    $(this).dialog('close');
                }
            }
        ],
        open: function () {
            //this special part is just done because delete and cancel were appearing in this form for unknown reason
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').prop('disabled', false);
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(0)').prop('disabled', false);
            //end of this special part
            $(this).siblings('.ui-dialog-buttonpane').find('button:eq(1)').focus();
        }

    });

    
});


//function AbsentDays()
//{
//    var LI = document.getElementById('MonthDays').value;
//    var RM = document.getElementById('txtabsent').value;
//    LI - parseInt(LI);
//    RM = parseInt(RM);

//    if (RM > LI) {
//        alert("Leave days can't be more than total days in the month");
//        document.getElementById('txtabsent').value = 0;
//    }
//    else
//    {
//        var DID = parseInt(LI) - parseInt(RM);
//        document.getElementById('SalaryDays').value = DID;
       
//    }

//}

//function LeaveDays() {
//    var LI = document.getElementById('MonthDays').value;
//    var RM = document.getElementById('txtleave').value;
//    LI - parseInt(LI);
//    RM = parseInt(RM);

//    if (RM > LI) {
//        alert("Leave days can't be more than total days in the month");
//        document.getElementById('txtleave').value = 0;
//    }
//    else {
//        var DID = parseInt(LI) - parseInt(RM);
//        document.getElementById('SalaryDays').value = DID;
//    }

//}


var app = angular.module('HRIS', []);

app.controller('MonthlySalaryController', function ($scope, $http, $window) {

    $scope.load = function (res) {

        var id = document.getElementById('txtEId').value;
        if (id > 0)
            $scope.GetData(id);
        LoadDropDown();
    };

    $scope.savedata = function (res) {
        $http({
            method: "POST",
            url: "/MonthlySalary/Save",
            data: $scope.MonthlySalary
        }).success(function (result) {
            //loaddropdown();
            $scope.errors = [];
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
                $scope.MonthlySalary = result.data;      
            }
            else {
               // $scope.MonthlySalary = result.data;
                alert(result.Message);
                $scope.MonthlySalary = {};
                Document.getElementById("Total").innerText = "";
            }
            setFormControls(result.Session);
            ConvertDate();
        }).error(function (result) {
            alert(result);
        });
    } 

    $scope.UndoData = function () {
        $http({
            method: "POST",
            url: "/MonthlySalary/Undo"
        }).success(function (result) {
            $scope.MonthlySalary = {};
            $scope.errors = [];
            setFormControls(result.Session);
            Document.getElementById("Total").innerText = "";
        }).catch(function (result) {

        });
    }   

    $scope.Exit = function () {
        $http({
            method: "POST",
            url: "/MonthlySalary/Exit",
        }).success(function (result) {
            $scope.errors = [];
            window.location.href = result.url;
        }).catch(function (result) {

        });
    }   

    $scope.Recall = function () {
        $http({
            method: "POST",
            url: "/MonthlySalary/Recall"
        }).success(function (result) {
            $scope.errors = [];
            setFormControls(result.Session);
        }).catch(function (result) {

        });
    }
    

    $scope.changedValue = function (res) {
        $scope.GetData(res);
    }

    $scope.GetData = function (res) {
        $http({
            method: "POST",
            url: "/MonthlySalary/Get",
            data: { _keyId: res },
        }).success(function (result) {
           // loaddropdown();
            $scope.errors = [];
            $scope.MonthlySalary = {};
            if (result.success == false) {
                $scope.errors = [
                   result.Message]
            }
            else {
                $scope.MonthlySalary = result.data;
                Calculate_TotalSalary();
                Calculate_Salary();
            }
            setFormControls(result.Session);
            ConvertDate();
        }).catch(function (result) {
            alert(result);
        });
    }

    $scope.AbsentDays = function  () {
        var LI = document.getElementById('MonthDays').value;
        var RM = document.getElementById('txtabsent').value;
        LI = parseInt(LI);
        RM = parseInt(RM);

        if (RM > LI) {
            alert("Leave days can't be more than total days in the month");
            document.getElementById('txtabsent').value = 0;
        }
        else {
            var DID = parseInt(LI) - parseInt(RM);
            document.getElementById('SalaryDays').value = DID;            
             Calculate_Salary();
           
           
        }

    }

    $scope.LeaveDays = function (){
        var LI = document.getElementById('MonthDays').value;
        var RM = document.getElementById('txtleave').value;
        LI = parseInt(LI);
        RM = parseInt(RM);

        if (RM > LI) {
            alert("Leave days can't be more than total days in the month");
            document.getElementById('txtleave').value = 0;
        }
        else {
            var DID = parseInt(LI) - parseInt(RM);
            document.getElementById('SalaryDays').value = DID;
           
                Calculate_Salary();
        }

    }
       

        //$scope.toggleEdit = function (m) {
        //    m.showEdit = m.showEdit ? false : true;
        //}


        $scope.AddSM = function () {
            var HI = document.getElementById('HeadId').value;
            var AM = document.getElementById('Amount').value;
            var LI = document.getElementById('Referenceno').value;
            var RM = document.getElementById('Remarks').value;
            var DID = document.getElementById('DetailId').value;
            var ST = document.getElementById('Status').value;
            var Index = document.getElementById('Row').value;
            DID = (DID === "") ? 0 : DID;
            if (HI != "" && AM > 0) {

                var detailid;
                var ma = {};

                //Math.max.apply(Math, $scope.MonthlySalary.EmpSalaryMonthlyDetails.map(function (ques) { detailid = ques.DetailId; }))
                //detailid = (detailid === undefined) ? 0 : detailid;
                if (Index != "")
                    $scope.MonthlySalary.EmpSalaryMonthlyDetails.splice(Index, 1);
                ma.Status = DID <= 0 ? "Added" : "Edited";
                if (DID == 0)
                    ma.DetailId = -1;
                else {
                    ma.DetailId = DID;
                }
                ma.HeadId = HI;
                ma.Amount = parseFloat(AM).toFixed(2);
                ma.LoanId = LI;
                ma.Remarks = RM;
                //if (ST == "UnChanged") {
                //    ma.Status = "Edited";
                //}
                //else {
                //    ma.Status = "Added";
                //}

                //if (DID != 0) {
                //    ma.DetailId = DID;
                //    $scope.MonthlySalary.EmpSalaryMonthlyDetails.splice(Index, 1);
                //}
                //else {
                //    ma.DetailId = detailid + 1;
                //}
                $scope.MonthlySalary.EmpSalaryMonthlyDetails.push(ma);
                $scope.ClearSM();
                Calculate_TotalSalary();
                ma = {};
            }
            else {
                alert("Please Selct Valid Salary Head and Amount should be greater then zero. Before saving value in Grid. ");
            }

        }
        $scope.ClearSM = function () {
            document.getElementById('HeadId').value = "";
            document.getElementById('Amount').value = 0.00;
            document.getElementById('Referenceno').value = 0;
            document.getElementById('Remarks').value = "";
            document.getElementById('DetailId').value;
            document.getElementById('Status').value;
            document.getElementById('Row').value;
        }
        $scope.EditSM = function (m, index) {

            document.getElementById('HeadId').value = m.HeadId;
            document.getElementById('Amount').value = m.Amount;
            document.getElementById('Referenceno').value = m.LoanId;
            document.getElementById('Remarks').value = m.Remarks;
            document.getElementById('DetailId').value = m.DetailId;
            document.getElementById('Status').value = m.Status;
            document.getElementById('Row').value = index;

        }
        $scope.RemoveSM = function (index) {
            //Find the record using Index from Array.
            //var CC = $scope.MonthlySalary.EmpSalaryMonthlyDetails[index].DetailId;
            if ($window.confirm("Do you want to delete: " )) {
                //Remove the item from Array using Index.
                $scope.MonthlySalary.EmpSalaryMonthlyDetails.splice(index, 1);
            }
            Calculate_TotalSalary();
        }

        $scope.AddAsset = function () {
          

            var HI = document.getElementById('AssetId').value;
            var AM = document.getElementById('Limit').value;
            var RM = document.getElementById('Remarks').value;
            var DID = document.getElementById('DetailId').value;
            var ST = document.getElementById('Status').value;
            var Index = document.getElementById('Row').value;
            DID = (DID === "") ? 0 : DID;
            if (HI != "" && AM > 0) {

                var detailid;
                var ma = {};

                //Math.max.apply(Math, $scope.MonthlySalary.EmpAssetDetails.map(function (ques) { detailid = ques.DetailId; }))
                //detailid = (detailid === undefined) ? 0 : detailid;
                if (Index != "")
                    $scope.MonthlySalary.EmpAssetDetails.splice(Index, 1);
                ma.Status = DID <= 0 ? "Added" : "Edited";
                if (DID == 0)
                    ma.DetailId = -1;
                else {
                    ma.DetailId = DID;
                }
                ma.AssetId = HI;
                ma.Limit = parseFloat(AM).toFixed(2);
                ma.Remarks = RM;
                //if (ST == "UnChanged") {
                //    ma.Status = "Edited";
                //}
                //else {
                //    ma.Status = "Added";
                //}

                //if (DID != 0) {
                //    ma.DetailId = DID;
                //    $scope.MonthlySalary.EmpAssetDetails.splice(Index, 1);
                //}
                //else {
                //    ma.DetailId = detailid + 1;
                //}
                $scope.MonthlySalary.EmpAssetDetails.push(ma);
                $scope.ClearAsset();
                ma = {};
            }
            else {
                alert("Please Selct Valid Asset and Limit should be greater then zero. Before saving value in Grid. ");
            }


        }
        $scope.ClearAsset = function () {
            document.getElementById('AssetId').value = "";
            document.getElementById('Limit').value = 0.00;
            document.getElementById('Remarks').value = "";
            document.getElementById('DetailId').value;
            document.getElementById('Status').value;
            document.getElementById('Row').value;
        }
        $scope.EditAsset = function (m, index) {

            document.getElementById('AssetId').value = m.AssetId;
            document.getElementById('Limit').value = m.Limit;
            document.getElementById('Remarks').value = m.Remarks;
            document.getElementById('DetailId').value = m.DetailId;
            document.getElementById('Status').value = m.Status;
            document.getElementById('Row').value = index;

        }
        $scope.RemoveAsset = function (index) {
            //Find the record using Index from Array.
           // var CC = $scope.MonthlySalary.EmpAssetDetails[index].DetailId;
            if ($window.confirm("Do you want to delete: " )) {
                //Remove the item from Array using Index.
                $scope.MonthlySalary.EmpAssetDetails.splice(index, 1);
            }
        }
    
        function Calculate_Salary() {
            var dblGrossSalary = 0;
            var AbsentDeductId = document.getElementById('txtSId').value;
            var MD = document.getElementById('MonthDays').value;
            var AB = document.getElementById('txtabsent').value;
            MD = parseInt(MD);
            AB = parseInt(AB);
            AbsentDeductId = parseInt(AbsentDeductId);
            if (AB >= 1)
            {
                $scope.MonthlySalary.EmpSalaryMonthlyDetails.forEach(function (element) {
                    var ST1 = $scope.Headlist.filter(function (a) { return a.HeadId == element.HeadId })[0]["Symbol"]
                    var ABS = $scope.Headlist.filter(function (a) { return a.HeadId == element.HeadId })[0]["AbsentDeduction"]
                    if (ABS = true) {
                        dblGrossSalary = parseFloat(dblGrossSalary) + parseFloat(element.Amount) * ST1;
                    }
                });
                var ma = {};
                    var dr = $scope.MonthlySalary.EmpSalaryMonthlyDetails.filter(function (a) { return a.HeadId == AbsentDeductId })[0]
                    if (dr != undefined) {
                        
                        angular.forEach($scope.MonthlySalary.EmpSalaryMonthlyDetails, function (cb, index) {
                            if (cb.HeadId == dr.HeadId) {
                                $scope.MonthlySalary.EmpSalaryMonthlyDetails.splice(index, 1);
                            }
                        });
                      
                        ma.HeadId = dr.HeadId;
                        ma.Amount = parseFloat((dblGrossSalary / MD) * AB).toFixed(2);
                        ma.LoanId = dr.LoanId;
                        ma.Remarks = dr.Remarks;
                        ma.AutoCalculated = 1;
                        ma.Status = "Added";
                        ma.DetailId = dr.DetailId;
                        $scope.MonthlySalary.EmpSalaryMonthlyDetails.push(ma);

                    }
                    else {
                        var detailid;


                        Math.max.apply(Math, $scope.MonthlySalary.EmpSalaryMonthlyDetails.map(function (ques) { detailid = ques.DetailId; }))
                        detailid = (detailid === undefined) ? 0 : detailid;
                        ma.HeadId = AbsentDeductId;
                        ma.Amount = parseFloat((dblGrossSalary / MD) * AB).toFixed(2);
                        ma.LoanId = 0;
                        ma.Remarks = "";
                        ma.AutoCalculated = 1;
                        ma.Status = "Added";
                        ma.DetailId = detailid + 1;
                        $scope.MonthlySalary.EmpSalaryMonthlyDetails.push(ma);
                    }
                    Calculate_TotalSalary();
            }
           


           
        }


        function Calculate_TotalSalary() {
            var total = 0;
            $scope.MonthlySalary.EmpSalaryMonthlyDetails.forEach(function (element) {
                var ST1 = $scope.Headlist.filter(function (a) { return a.HeadId == element.HeadId })[0]["Symbol"]
                total = total + parseFloat(element.Amount) * ST1;
            });

            document.getElementById("Total").innerText = formatNumbers(total);
        }

        function LoadDropDown()
        {
            $http.get('/MonthlySalary/GetAllowedEmployee').then(function (d) {
                $scope.Employeelist = d.data;
            }, function () {
                alert('failed');
            });

            $http.get('/MonthlySalary/GetSalaryHead').then(function (d) {
                $scope.Headlist = d.data;
            }, function () {
                alert('failed');
            });

            $http.get('/MonthlySalary/GetAsset').then(function (d) {
                $scope.Assetlist = d.data;
            }, function () {
                alert('failed');
            });
        }

      

        function ConvertDate() {
            if ($scope.MonthlySalary.AuditTrail.CreatedOn != null) {
                $scope.MonthlySalary.AuditTrail.CreatedOn = formattingDateTime($scope.MonthlySalary.AuditTrail.CreatedOn);
            }
            if ($scope.MonthlySalary.AuditTrail.UpdatedOn != null) {
                $scope.MonthlySalary.AuditTrail.UpdatedOn = formattingDateTime($scope.MonthlySalary.AuditTrail.UpdatedOn);
            }

            if ($scope.MonthlySalary.VerifiedOn != null) {
                $scope.MonthlySalary.VerifiedOn = formattingDateTime($scope.MonthlySalary.VerifiedOn);
            }
        }

     
        
});